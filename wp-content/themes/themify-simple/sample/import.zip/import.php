<?php

function themify_do_demo_import() {
$term = array (
  'term_id' => 2,
  'name' => 'Fashion',
  'slug' => 'fashion',
  'term_group' => 0,
  'taxonomy' => 'category',
  'description' => 'All About Fashion',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 4,
  'name' => 'Technology',
  'slug' => 'technology',
  'term_group' => 0,
  'taxonomy' => 'category',
  'description' => 'All About Tech News',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 5,
  'name' => 'Accessories',
  'slug' => 'accessories',
  'term_group' => 0,
  'taxonomy' => 'category',
  'description' => 'Fashion Accessories For Women',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 6,
  'name' => 'Fashion Event',
  'slug' => 'fashion-event',
  'term_group' => 0,
  'taxonomy' => 'category',
  'description' => 'Fashion Event Info',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 3,
  'name' => 'Fashion',
  'slug' => 'fashion',
  'term_group' => 0,
  'taxonomy' => 'post_tag',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 8,
  'name' => 'Event',
  'slug' => 'event',
  'term_group' => 0,
  'taxonomy' => 'post_tag',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 9,
  'name' => 'Exhibition',
  'slug' => 'exhibition',
  'term_group' => 0,
  'taxonomy' => 'post_tag',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 10,
  'name' => 'Trend',
  'slug' => 'trend',
  'term_group' => 0,
  'taxonomy' => 'post_tag',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 11,
  'name' => 'Mode',
  'slug' => 'mode',
  'term_group' => 0,
  'taxonomy' => 'post_tag',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 12,
  'name' => 'Eyeglass',
  'slug' => 'eyeglass',
  'term_group' => 0,
  'taxonomy' => 'post_tag',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 13,
  'name' => 'Accessories',
  'slug' => 'accessories',
  'term_group' => 0,
  'taxonomy' => 'post_tag',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 14,
  'name' => 'Technology',
  'slug' => 'technology',
  'term_group' => 0,
  'taxonomy' => 'post_tag',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 15,
  'name' => 'Photography',
  'slug' => 'photography',
  'term_group' => 0,
  'taxonomy' => 'post_tag',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 16,
  'name' => 'gadget',
  'slug' => 'gadget',
  'term_group' => 0,
  'taxonomy' => 'post_tag',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 17,
  'name' => 'Apple',
  'slug' => 'apple',
  'term_group' => 0,
  'taxonomy' => 'post_tag',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 18,
  'name' => 'iMac',
  'slug' => 'imac',
  'term_group' => 0,
  'taxonomy' => 'post_tag',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 19,
  'name' => 'Gadgets',
  'slug' => 'gadgets',
  'term_group' => 0,
  'taxonomy' => 'post_tag',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 20,
  'name' => 'Collection',
  'slug' => 'collection',
  'term_group' => 0,
  'taxonomy' => 'post_tag',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 21,
  'name' => 'Designer',
  'slug' => 'designer',
  'term_group' => 0,
  'taxonomy' => 'post_tag',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$term = array (
  'term_id' => 7,
  'name' => 'Main Menu',
  'slug' => 'main-menu',
  'term_group' => 0,
  'taxonomy' => 'nav_menu',
  'description' => '',
  'parent' => 0,
);
Themify_Import_Helper::process_import_term( $term );

$post = array (
  'ID' => 66,
  'post_date' => '2016-02-19 06:49:58',
  'post_date_gmt' => '2016-02-19 06:49:58',
  'post_content' => 'At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.',
  'post_title' => 'Summer Fashion Exhibition',
  'post_excerpt' => '',
  'post_name' => 'summer-fashion-exhibition',
  'post_modified' => '2017-08-23 03:12:08',
  'post_modified_gmt' => '2017-08-23 03:12:08',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/simple/?p=66',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'layout' => 'sidebar-none',
    'content_width' => 'default_width',
    'hide_post_title' => 'default',
    'unlink_post_title' => 'default',
    'hide_post_date' => 'default',
    'hide_post_image' => 'default',
    'unlink_post_image' => 'default',
    'header_wrap' => 'solid',
    'background_repeat' => 'fullcover',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
    'category' => 'fashion-event',
    'post_tag' => 'event, exhibition',
  ),
  'thumb' => 'https://themify.me/demo/themes/simple/files/2016/02/148512749.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 64,
  'post_date' => '2016-02-19 06:33:30',
  'post_date_gmt' => '2016-02-19 06:33:30',
  'post_content' => 'Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat',
  'post_title' => 'Spring Fashion Event',
  'post_excerpt' => '',
  'post_name' => 'spring-fashion-event',
  'post_modified' => '2017-08-23 03:12:05',
  'post_modified_gmt' => '2017-08-23 03:12:05',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/simple/?p=64',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'layout' => 'sidebar-none',
    'content_width' => 'default_width',
    'hide_post_title' => 'default',
    'unlink_post_title' => 'default',
    'hide_post_date' => 'default',
    'hide_post_image' => 'default',
    'unlink_post_image' => 'default',
    'header_wrap' => 'solid',
    'background_repeat' => 'fullcover',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
    'category' => 'fashion-event',
    'post_tag' => 'event',
  ),
  'thumb' => 'https://themify.me/demo/themes/simple/files/2016/02/54153043.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 17,
  'post_date' => '2016-02-19 06:28:47',
  'post_date_gmt' => '2016-02-19 06:28:47',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
  'post_title' => '2106 Fashion Trends for Teen',
  'post_excerpt' => '',
  'post_name' => '2106-fashion-trends-for-teen',
  'post_modified' => '2017-08-23 03:12:10',
  'post_modified_gmt' => '2017-08-23 03:12:10',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/simple/?p=17',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'layout' => 'sidebar-none',
    'content_width' => 'default_width',
    'hide_post_title' => 'default',
    'unlink_post_title' => 'default',
    'hide_post_date' => 'default',
    'hide_post_image' => 'default',
    'unlink_post_image' => 'default',
    'header_wrap' => 'solid',
    'background_repeat' => 'fullcover',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
    'category' => 'fashion',
    'post_tag' => 'event, exhibition, trend',
  ),
  'thumb' => 'https://themify.me/demo/themes/simple/files/2016/02/179211281.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 57,
  'post_date' => '2016-02-19 06:24:02',
  'post_date_gmt' => '2016-02-19 06:24:02',
  'post_content' => 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?',
  'post_title' => 'NYC Fashion Event',
  'post_excerpt' => '',
  'post_name' => 'nyc-fashion-event',
  'post_modified' => '2017-08-23 03:12:12',
  'post_modified_gmt' => '2017-08-23 03:12:12',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/simple/?p=57',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'layout' => 'sidebar-none',
    'content_width' => 'default_width',
    'hide_post_title' => 'default',
    'unlink_post_title' => 'default',
    'hide_post_date' => 'default',
    'hide_post_image' => 'default',
    'unlink_post_image' => 'default',
    'header_wrap' => 'solid',
    'background_repeat' => 'fullcover',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
    'category' => 'fashion-event',
    'post_tag' => 'exhibition',
  ),
  'thumb' => 'https://themify.me/demo/themes/simple/files/2016/02/99449315.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 54,
  'post_date' => '2016-02-19 04:50:05',
  'post_date_gmt' => '2016-02-19 04:50:05',
  'post_content' => 'Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.',
  'post_title' => '80\' Collection',
  'post_excerpt' => '',
  'post_name' => '80-collection',
  'post_modified' => '2017-08-23 03:12:13',
  'post_modified_gmt' => '2017-08-23 03:12:13',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/simple/?p=54',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'layout' => 'sidebar-none',
    'content_width' => 'default_width',
    'hide_post_title' => 'default',
    'unlink_post_title' => 'default',
    'hide_post_date' => 'default',
    'hide_post_image' => 'default',
    'unlink_post_image' => 'default',
    'header_wrap' => 'solid',
    'background_repeat' => 'fullcover',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
    'category' => 'accessories',
    'post_tag' => 'mode, trend',
  ),
  'thumb' => 'https://themify.me/demo/themes/simple/files/2016/02/59553262.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 45,
  'post_date' => '2016-02-19 04:33:05',
  'post_date_gmt' => '2016-02-19 04:33:05',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum',
  'post_title' => 'Eyeglass For Girls',
  'post_excerpt' => '',
  'post_name' => 'eyeglass-collection',
  'post_modified' => '2017-08-23 03:12:15',
  'post_modified_gmt' => '2017-08-23 03:12:15',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/simple/?p=45',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'layout' => 'sidebar-none',
    'content_width' => 'default_width',
    'hide_post_title' => 'default',
    'unlink_post_title' => 'default',
    'hide_post_date' => 'default',
    'hide_post_image' => 'default',
    'unlink_post_image' => 'default',
    'header_wrap' => 'solid',
    'background_repeat' => 'fullcover',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
    'category' => 'accessories',
    'post_tag' => 'eyeglass, mode, trend',
  ),
  'thumb' => 'https://themify.me/demo/themes/simple/files/2016/02/194510450.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 40,
  'post_date' => '2016-02-19 04:28:38',
  'post_date_gmt' => '2016-02-19 04:28:38',
  'post_content' => 'Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur',
  'post_title' => 'Pearl Necklace',
  'post_excerpt' => '',
  'post_name' => 'pearl-necklace',
  'post_modified' => '2017-08-23 03:12:17',
  'post_modified_gmt' => '2017-08-23 03:12:17',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/simple/?p=40',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'layout' => 'sidebar-none',
    'content_width' => 'default_width',
    'hide_post_title' => 'default',
    'unlink_post_title' => 'default',
    'hide_post_date' => 'default',
    'hide_post_image' => 'default',
    'unlink_post_image' => 'default',
    'header_wrap' => 'solid',
    'background_repeat' => 'fullcover',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
    'category' => 'accessories',
    'post_tag' => 'accessories, mode',
  ),
  'thumb' => 'https://themify.me/demo/themes/simple/files/2016/02/69030349.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 37,
  'post_date' => '2016-02-19 04:21:44',
  'post_date_gmt' => '2016-02-19 04:21:44',
  'post_content' => 'Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.',
  'post_title' => 'Super Computer With Super Specs',
  'post_excerpt' => '',
  'post_name' => 'super-computer-with-super-specs',
  'post_modified' => '2017-08-23 03:12:18',
  'post_modified_gmt' => '2017-08-23 03:12:18',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/simple/?p=37',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'layout' => 'sidebar-none',
    'content_width' => 'default_width',
    'hide_post_title' => 'default',
    'unlink_post_title' => 'default',
    'hide_post_date' => 'default',
    'hide_post_image' => 'default',
    'unlink_post_image' => 'default',
    'header_wrap' => 'solid',
    'background_repeat' => 'fullcover',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
    'category' => 'technology',
    'post_tag' => 'technology',
  ),
  'thumb' => 'https://themify.me/demo/themes/simple/files/2016/02/comingsoon.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 30,
  'post_date' => '2016-02-19 04:18:38',
  'post_date_gmt' => '2016-02-19 04:18:38',
  'post_content' => 'Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur.',
  'post_title' => 'Spring Photography',
  'post_excerpt' => '',
  'post_name' => 'spring-photography',
  'post_modified' => '2017-08-23 03:12:20',
  'post_modified_gmt' => '2017-08-23 03:12:20',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/simple/?p=30',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'layout' => 'sidebar-none',
    'content_width' => 'default_width',
    'hide_post_title' => 'default',
    'unlink_post_title' => 'default',
    'hide_post_date' => 'default',
    'hide_post_image' => 'default',
    'unlink_post_image' => 'default',
    'header_wrap' => 'solid',
    'background_repeat' => 'fullcover',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
    'category' => 'fashion',
    'post_tag' => 'mode, photography',
  ),
  'thumb' => 'https://themify.me/demo/themes/simple/files/2016/02/67088788.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 26,
  'post_date' => '2016-02-19 04:17:38',
  'post_date_gmt' => '2016-02-19 04:17:38',
  'post_content' => 'At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus.',
  'post_title' => 'Smart Watch Released',
  'post_excerpt' => '',
  'post_name' => 'smart-watch-new-color',
  'post_modified' => '2017-08-23 03:12:22',
  'post_modified_gmt' => '2017-08-23 03:12:22',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/simple/?p=26',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'layout' => 'sidebar-none',
    'content_width' => 'default_width',
    'hide_post_title' => 'default',
    'unlink_post_title' => 'default',
    'hide_post_date' => 'default',
    'hide_post_image' => 'default',
    'unlink_post_image' => 'default',
    'header_wrap' => 'solid',
    'background_repeat' => 'fullcover',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
    'category' => 'technology',
    'post_tag' => 'gadget, technology',
  ),
  'thumb' => 'https://themify.me/demo/themes/simple/files/2016/02/product-page-6.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 23,
  'post_date' => '2016-02-19 02:44:22',
  'post_date_gmt' => '2016-02-19 02:44:22',
  'post_content' => 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?',
  'post_title' => 'iMac 27-inch sizes Now Available',
  'post_excerpt' => '',
  'post_name' => 'imac',
  'post_modified' => '2017-08-23 03:12:23',
  'post_modified_gmt' => '2017-08-23 03:12:23',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/simple/?p=23',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'layout' => 'sidebar-none',
    'content_width' => 'default_width',
    'hide_post_title' => 'default',
    'unlink_post_title' => 'default',
    'hide_post_date' => 'default',
    'hide_post_image' => 'default',
    'unlink_post_image' => 'default',
    'header_wrap' => 'solid',
    'background_repeat' => 'fullcover',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
    'category' => 'technology',
    'post_tag' => 'apple, imac, technology',
  ),
  'thumb' => 'https://themify.me/demo/themes/simple/files/2016/02/og_image.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 20,
  'post_date' => '2016-02-19 02:40:18',
  'post_date_gmt' => '2016-02-19 02:40:18',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
  'post_title' => 'Must Have Gadgets',
  'post_excerpt' => '',
  'post_name' => 'must-have-gadgets',
  'post_modified' => '2017-08-23 03:12:25',
  'post_modified_gmt' => '2017-08-23 03:12:25',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/simple/?p=20',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'layout' => 'sidebar-none',
    'content_width' => 'default_width',
    'hide_post_title' => 'default',
    'unlink_post_title' => 'default',
    'hide_post_date' => 'default',
    'hide_post_image' => 'default',
    'unlink_post_image' => 'default',
    'header_wrap' => 'solid',
    'background_repeat' => 'fullcover',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
    'category' => 'technology',
    'post_tag' => 'gadgets, technology',
  ),
  'thumb' => 'https://themify.me/demo/themes/simple/files/2016/02/iPad-Air-2.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 14,
  'post_date' => '2016-02-19 02:23:24',
  'post_date_gmt' => '2016-02-19 02:23:24',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
  'post_title' => '7 Things We Learned About Spring Dressing',
  'post_excerpt' => '',
  'post_name' => '7-things-we-learned-about-spring-dressing',
  'post_modified' => '2017-08-23 03:12:27',
  'post_modified_gmt' => '2017-08-23 03:12:27',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/simple/?p=14',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'layout' => 'sidebar-none',
    'content_width' => 'default_width',
    'hide_post_title' => 'default',
    'unlink_post_title' => 'default',
    'hide_post_date' => 'default',
    'hide_post_image' => 'default',
    'unlink_post_image' => 'default',
    'header_wrap' => 'solid',
    'background_repeat' => 'fullcover',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
    'category' => 'fashion',
    'post_tag' => 'mode, trend',
  ),
  'thumb' => 'https://themify.me/demo/themes/simple/files/2016/02/148328327.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 11,
  'post_date' => '2016-02-19 02:14:06',
  'post_date_gmt' => '2016-02-19 02:14:06',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
  'post_title' => 'Casual Outfits',
  'post_excerpt' => '',
  'post_name' => 'casual-outfits',
  'post_modified' => '2017-08-23 03:12:29',
  'post_modified_gmt' => '2017-08-23 03:12:29',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/simple/?p=11',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'layout' => 'sidebar-none',
    'content_width' => 'default_width',
    'hide_post_title' => 'default',
    'unlink_post_title' => 'default',
    'hide_post_date' => 'default',
    'hide_post_image' => 'default',
    'unlink_post_image' => 'default',
    'header_wrap' => 'solid',
    'background_repeat' => 'fullcover',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
    'category' => 'fashion',
    'post_tag' => 'fashion, trend',
  ),
  'thumb' => 'https://themify.me/demo/themes/simple/files/2016/02/girl-410334_1920.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 7,
  'post_date' => '2016-02-19 01:28:30',
  'post_date_gmt' => '2016-02-19 01:28:30',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
  'post_title' => 'Summer Collection',
  'post_excerpt' => '',
  'post_name' => 'summer-collection',
  'post_modified' => '2017-08-23 03:12:30',
  'post_modified_gmt' => '2017-08-23 03:12:30',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/simple/?p=7',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'layout' => 'default',
    'content_width' => 'default_width',
    'hide_post_title' => 'default',
    'unlink_post_title' => 'default',
    'hide_post_date' => 'default',
    'hide_post_image' => 'default',
    'unlink_post_image' => 'default',
    'header_wrap' => 'solid',
    'background_repeat' => 'fullcover',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
    'category' => 'fashion',
    'post_tag' => 'mode, trend',
  ),
  'thumb' => 'https://themify.me/demo/themes/simple/files/2016/02/95135980.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 4,
  'post_date' => '2016-02-19 01:26:35',
  'post_date_gmt' => '2016-02-19 01:26:35',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
  'post_title' => 'Red Carpet Fashion',
  'post_excerpt' => '',
  'post_name' => 'fashion',
  'post_modified' => '2017-08-23 03:12:32',
  'post_modified_gmt' => '2017-08-23 03:12:32',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/simple/?p=4',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'layout' => 'sidebar1',
    'content_width' => 'default_width',
    'hide_post_title' => 'default',
    'unlink_post_title' => 'default',
    'hide_post_date' => 'default',
    'hide_post_image' => 'default',
    'unlink_post_image' => 'default',
    'header_wrap' => 'solid',
    'background_repeat' => 'fullcover',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
    'category' => 'fashion',
    'post_tag' => 'fashion, trend',
  ),
  'thumb' => 'https://themify.me/demo/themes/simple/files/2016/02/57284001.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 69,
  'post_date' => '2016-02-17 07:11:58',
  'post_date_gmt' => '2016-02-17 07:11:58',
  'post_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
  'post_title' => 'Retro Fashion Week',
  'post_excerpt' => '',
  'post_name' => 'retro-fashion-week',
  'post_modified' => '2017-08-23 03:12:33',
  'post_modified_gmt' => '2017-08-23 03:12:33',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/simple/?p=69',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'layout' => 'sidebar-none',
    'content_width' => 'default_width',
    'hide_post_title' => 'default',
    'unlink_post_title' => 'default',
    'hide_post_date' => 'default',
    'hide_post_image' => 'default',
    'unlink_post_image' => 'default',
    'header_wrap' => 'solid',
    'background_repeat' => 'fullcover',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
    'category' => 'fashion-event',
    'post_tag' => 'event',
  ),
  'thumb' => 'https://themify.me/demo/themes/simple/files/2016/02/147293620.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 61,
  'post_date' => '2016-01-02 06:25:55',
  'post_date_gmt' => '2016-01-02 06:25:55',
  'post_content' => 'At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque',
  'post_title' => 'Winter Collection By Top Designers',
  'post_excerpt' => '',
  'post_name' => 'winter-collection-by-top-designers',
  'post_modified' => '2017-08-23 03:12:35',
  'post_modified_gmt' => '2017-08-23 03:12:35',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/simple/?p=61',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'layout' => 'sidebar-none',
    'content_width' => 'default_width',
    'hide_post_title' => 'default',
    'unlink_post_title' => 'default',
    'hide_post_date' => 'default',
    'hide_post_image' => 'default',
    'unlink_post_image' => 'default',
    'header_wrap' => 'solid',
    'background_repeat' => 'fullcover',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
    'category' => 'fashion-event',
    'post_tag' => 'collection, designer, mode',
  ),
  'thumb' => 'https://themify.me/demo/themes/simple/files/2016/02/93501982.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 48,
  'post_date' => '2015-12-19 04:38:20',
  'post_date_gmt' => '2015-12-19 04:38:20',
  'post_content' => 'At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.',
  'post_title' => 'Ultimate Woman Bags Collections',
  'post_excerpt' => '',
  'post_name' => 'ultimate-woman-bags-collections',
  'post_modified' => '2017-08-23 03:12:37',
  'post_modified_gmt' => '2017-08-23 03:12:37',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/simple/?p=48',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'layout' => 'sidebar-none',
    'content_width' => 'default_width',
    'hide_post_title' => 'default',
    'unlink_post_title' => 'default',
    'hide_post_date' => 'default',
    'hide_post_image' => 'default',
    'unlink_post_image' => 'default',
    'header_wrap' => 'solid',
    'background_repeat' => 'fullcover',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
    'category' => 'accessories',
    'post_tag' => 'accessories, mode',
  ),
  'thumb' => 'https://themify.me/demo/themes/simple/files/2016/02/leather-1175154_1920.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 51,
  'post_date' => '2015-11-14 04:43:16',
  'post_date_gmt' => '2015-11-14 04:43:16',
  'post_content' => 'Qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?',
  'post_title' => 'Must Have Accessories',
  'post_excerpt' => '',
  'post_name' => 'must-have-accessories',
  'post_modified' => '2017-08-23 03:12:38',
  'post_modified_gmt' => '2017-08-23 03:12:38',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/simple/?p=51',
  'menu_order' => 0,
  'post_type' => 'post',
  'meta_input' => 
  array (
    'layout' => 'sidebar-none',
    'content_width' => 'default_width',
    'hide_post_title' => 'default',
    'unlink_post_title' => 'default',
    'hide_post_date' => 'default',
    'hide_post_image' => 'default',
    'unlink_post_image' => 'default',
    'header_wrap' => 'solid',
    'background_repeat' => 'fullcover',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
    'category' => 'accessories',
    'post_tag' => 'accessories, mode',
  ),
  'thumb' => 'https://themify.me/demo/themes/simple/files/2016/02/beads-776102_1920.jpg',
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 154,
  'post_date' => '2016-02-23 19:02:38',
  'post_date_gmt' => '2016-02-23 19:02:38',
  'post_content' => '<!--themify_builder_static--><p>Simple comes with a drag &amp; drop layout Builder which allows you to design any responsive layout. The Customize panel gives you full control of overall font styling, site logo, header, sidebar, and footer.</p>
<a href="https://themify.me/themes/simple" >
 Download
 </a>
<img loading="lazy" width="316" height="272" src="https://themify.me/demo/themes/simple/files/2016/02/smartwatch.png" title="smartwatch" alt="smartwatch" srcset="https://themify.me/demo/themes/simple/files/2016/02/smartwatch.png 316w, https://themify.me/demo/themes/simple/files/2016/02/smartwatch-300x258.png 300w, https://themify.me/demo/themes/simple/files/2016/02/smartwatch-315x271.png 315w, https://themify.me/demo/themes/simple/files/2016/02/smartwatch-445x383.png 445w" sizes="(max-width: 316px) 100vw, 316px" />
<h3 style="text-align: left;">WooCommerce Compitable</h3> <p style="text-align: left;">Sell anything online with WooCommerce plugin.</p><!--/themify_builder_static-->',
  'post_title' => 'About',
  'post_excerpt' => '',
  'post_name' => 'about',
  'post_modified' => '2020-09-17 20:17:34',
  'post_modified_gmt' => '2020-09-17 20:17:34',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/simple/?page_id=154',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_sub_heading' => 'Simple is a free theme to make fast loading sites with WordPress.',
    'page_layout' => 'sidebar-none',
    'content_width' => 'default_width',
    'header_wrap' => 'transparent',
    'background_repeat' => 'fullcover',
    'page_title_background_color' => '#5630c9',
    'order' => 'desc',
    'orderby' => 'date',
    'layout' => 'list-post',
    'display_content' => 'content',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"2sr0955\\",\\"cols\\":[{\\"element_id\\":\\"0ktp958\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"x1yv959\\",\\"mod_settings\\":{\\"content_text\\":\\"<p>Simple comes with a drag &amp; drop layout Builder which allows you to design any responsive layout. The Customize panel gives you full control of overall font styling, site logo, header, sidebar, and footer.<\\\\/p>\\",\\"font_size\\":\\"1.5\\",\\"font_size_unit\\":\\"em\\",\\"line_height\\":\\"1.8\\",\\"line_height_unit\\":\\"em\\",\\"text_align_left\\":\\"left\\",\\"text_align_center\\":\\"center\\",\\"text_align_right\\":\\"right\\",\\"text_align_justify\\":\\"justify\\",\\"padding_right\\":\\"7\\",\\"padding_right_unit\\":\\"%\\",\\"padding_left\\":\\"7\\",\\"padding_left_unit\\":\\"%\\"}},{\\"mod_name\\":\\"buttons\\",\\"element_id\\":\\"aj4i158\\",\\"mod_settings\\":{\\"content_button\\":[{\\"label\\":\\"Download\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/themes\\\\/simple\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\",\\"button_color_bg\\":\\"green\\",\\"icon_alignment\\":\\"left\\"}],\\"display\\":\\"buttons-horizontal\\",\\"buttons_style\\":\\"solid\\",\\"buttons_shape\\":\\"circle\\",\\"buttons_size\\":\\"large\\",\\"checkbox_padding_link_apply_all\\":false,\\"padding_link_left_unit\\":\\"px\\",\\"padding_link_opp_left\\":false,\\"padding_link_bottom_unit\\":\\"px\\",\\"padding_link_bottom\\":\\"20\\",\\"padding_link_right_unit\\":\\"px\\",\\"padding_link_opp_top\\":false,\\"padding_link_top_unit\\":\\"px\\",\\"padding_link_top\\":\\"15\\",\\"b_p\\":\\"50,50\\",\\"b_r\\":\\"repeat\\",\\"b_i-circle-radial\\":false,\\"b_i-gradient-angle\\":\\"180\\",\\"b_i-gradient-type\\":\\"linear\\",\\"b_i-type\\":\\"image\\",\\"checkbox_margin_apply_all\\":false,\\"margin_left_unit\\":\\"px\\",\\"margin_opp_left\\":false,\\"margin_bottom_unit\\":\\"px\\",\\"margin_bottom\\":\\"30\\",\\"margin_right_unit\\":\\"px\\",\\"margin_opp_top\\":false,\\"margin_top_unit\\":\\"px\\",\\"text-shadow_blur_unit\\":\\"px\\",\\"text-shadow_vShadow_unit\\":\\"px\\",\\"text-shadow_hShadow_unit\\":\\"px\\",\\"letter_spacing_unit\\":\\"px\\",\\"line_height_unit\\":\\"px\\",\\"line_height\\":\\"1\\",\\"font_size_unit\\":\\"px\\",\\"font_gradient_color-circle-radial\\":false,\\"font_gradient_color-gradient-angle\\":\\"180\\",\\"font_gradient_color-gradient-type\\":\\"linear\\",\\"font_color_type\\":\\"font_color_solid\\"}}]}],\\"styling\\":{\\"text_align\\":\\"center\\"}},{\\"element_id\\":\\"tcth955\\",\\"cols\\":[{\\"element_id\\":\\"53je963\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"element_id\\":\\"to2z963\\",\\"cols\\":[{\\"element_id\\":\\"aa7y964\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"tbxy964\\",\\"mod_settings\\":{\\"style_image\\":\\"image-center\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/simple\\\\/files\\\\/2016\\\\/02\\\\/smartwatch.png\\",\\"text_align_left\\":\\"left\\",\\"text_align_center\\":\\"center\\",\\"text_align_right\\":\\"right\\",\\"text_align_justify\\":\\"justify\\",\\"animation_effect\\":\\"fadeIn\\"}}]},{\\"element_id\\":\\"bq67964\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"ageg964\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3 style=\\\\\\"text-align: left;\\\\\\">WooCommerce Compitable<\\\\/h3>\\\\n<p style=\\\\\\"text-align: left;\\\\\\">Sell anything online with WooCommerce plugin.<\\\\/p>\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"text_align\\":\\"left\\",\\"text_align_left\\":\\"left\\",\\"text_align_center\\":\\"center\\",\\"text_align_right\\":\\"right\\",\\"text_align_justify\\":\\"justify\\",\\"padding_top\\":\\"7\\",\\"padding_top_unit\\":\\"%\\",\\"padding_right\\":\\"10\\",\\"padding_right_unit\\":\\"%\\",\\"padding_left_unit\\":\\"%\\",\\"checkbox_padding_apply_all_padding\\":\\"padding\\",\\"checkbox_margin_apply_all_margin\\":\\"margin\\",\\"checkbox_border_apply_all_border\\":\\"border\\"}}]}],\\"column_alignment\\":\\"col_align_middle\\"}]}],\\"styling\\":{\\"text_align\\":\\"left\\",\\"padding_top\\":\\"30\\",\\"padding_top_unit\\":\\"px\\",\\"margin_top\\":\\"60\\",\\"margin_top_unit\\":\\"px\\",\\"border_top_color\\":\\"eeeeee\\",\\"border_top_width\\":\\"1\\"}}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 144,
  'post_date' => '2016-02-20 02:54:33',
  'post_date_gmt' => '2016-02-20 02:54:33',
  'post_content' => '',
  'post_title' => 'Blog',
  'post_excerpt' => '',
  'post_name' => 'blog',
  'post_modified' => '2017-08-23 03:13:26',
  'post_modified_gmt' => '2017-08-23 03:13:26',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/simple/?page_id=144',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'content_width' => 'default_width',
    'hide_page_title' => 'default',
    'header_wrap' => 'solid',
    'background_repeat' => 'fullcover',
    'page_title_background_image' => 'https://themify.me/demo/themes/simple/files/2016/02/blog.jpg',
    'query_category' => '0',
    'order' => 'desc',
    'orderby' => 'date',
    'layout' => 'list-post',
    'posts_per_page' => '6',
    'display_content' => 'content',
    'hide_title' => 'default',
    'unlink_title' => 'default',
    'hide_date' => 'default',
    'media_position' => 'default',
    'hide_image' => 'default',
    'unlink_image' => 'default',
    'hide_navigation' => 'default',
    'builder_switch_frontend' => '0',
  ),
  'tax_input' => 
  array (
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 2458,
  'post_date' => '2020-06-22 17:39:24',
  'post_date_gmt' => '2020-06-22 17:39:24',
  'post_content' => '<p>This page is used by LoginPress to preview the login page in the Customizer.</p>',
  'post_title' => 'LoginPress',
  'post_excerpt' => '',
  'post_name' => 'loginpress',
  'post_modified' => '2020-06-22 17:39:24',
  'post_modified_gmt' => '2020-06-22 17:39:24',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/simple/loginpress/',
  'menu_order' => 0,
  'post_type' => 'page',
  'tax_input' => 
  array (
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 90,
  'post_date' => '2016-02-19 13:55:54',
  'post_date_gmt' => '2016-02-19 13:55:54',
  'post_content' => '<!--themify_builder_static--><h1>Themify Simple</h1> <p>Simple is a free theme to make fast sites with WordPress.</p>
<a href="https://themify.me/themes/simple" >
 Download
 </a>
<a href="#products">
 <i><svg><use href="#tf-fas-angle-double-down"></use></svg></i>
 </a>
<img loading="lazy" src="https://themify.me/demo/themes/simple/files/2016/02/ripped-jeans-445x348.png" width="445" height="348" title="ripped jeans" alt="ripped jeans" srcset="https://themify.me/demo/themes/simple/files/2016/02/ripped-jeans.png 445w, https://themify.me/demo/themes/simple/files/2016/02/ripped-jeans-300x235.png 300w" sizes="(max-width: 445px) 100vw, 445px" />
<h2 style="text-align: left;">Ripped Jeans</h2> <p style="text-align: left;">Cras non ultricies nulla, quis varius orci. Nulla ac pellentesque eros, eu interdum leo. Phasellus non dui viverra, consectetur mauris ac, pharetra massa.</p>
<img loading="lazy" src="https://themify.me/demo/themes/simple/files/2016/02/smartwatch-315x271.png" width="315" height="271" title="smartwatch" alt="smartwatch" srcset="https://themify.me/demo/themes/simple/files/2016/02/smartwatch-315x271.png 315w, https://themify.me/demo/themes/simple/files/2016/02/smartwatch-300x258.png 300w, https://themify.me/demo/themes/simple/files/2016/02/smartwatch-445x383.png 445w, https://themify.me/demo/themes/simple/files/2016/02/smartwatch.png 316w" sizes="(max-width: 315px) 100vw, 315px" />
<h2>Smart Watch</h2> <p>Epretium condimentum tiam fermentum condimentum elit ac accumsan. Proin cursus, lectus malesuada , quam malesuada purus, et sodales diam erat velest.</p>
<img loading="lazy" src="https://themify.me/demo/themes/simple/files/2016/02/iMac-3-315x281.png" width="315" height="281" title="iMac 3" alt="iMac 3" srcset="https://themify.me/demo/themes/simple/files/2016/02/iMac-3-315x281.png 315w, https://themify.me/demo/themes/simple/files/2016/02/iMac-3-300x268.png 300w, https://themify.me/demo/themes/simple/files/2016/02/iMac-3.png 313w" sizes="(max-width: 315px) 100vw, 315px" />
<h2>iMac</h2> <p>Epretium condimentum tiam fermentum condimentumquam odio malesuada purus, elit ac accumsan. Proin cursus, lectus malesuada, et sodales diam erat velest.</p>
<img loading="lazy" src="https://themify.me/demo/themes/simple/files/2016/02/leather-shoes-400x285.png" width="400" height="285" title="leather shoes" alt="leather shoes" srcset="https://themify.me/demo/themes/simple/files/2016/02/leather-shoes-400x285.png 400w, https://themify.me/demo/themes/simple/files/2016/02/leather-shoes-300x214.png 300w, https://themify.me/demo/themes/simple/files/2016/02/leather-shoes-315x225.png 315w, https://themify.me/demo/themes/simple/files/2016/02/leather-shoes.png 382w" sizes="(max-width: 400px) 100vw, 400px" />
<h2>Leather Shoes</h2> <p>Cras non ultricies nulla, quis varius orci. Nulla ac pellentesque eros, eu interdum leo. Phasellus non dui viverra, consectetur mauris ac, pharetra massa. Curabitur posuere posuere dolor.</p>
<img loading="lazy" src="https://themify.me/demo/themes/simple/files/2016/02/iphone-175x276.png" width="175" height="276" title="iphone" alt="iphone" srcset="https://themify.me/demo/themes/simple/files/2016/02/iphone-175x276.png 175w, https://themify.me/demo/themes/simple/files/2016/02/iphone.png 173w" sizes="(max-width: 175px) 100vw, 175px" />
<h2>iPhone</h2>
<a href="https://themify.me/demo/themes/simple/files/2016/02/iphone-6-658844_1280-1-1024x682.jpg"
 >
 <img loading="lazy" src="https://themify.me/demo/themes/simple/files/2016/03/iphone-6-658844_1280-1-230x230.png" width="230" height="230" title="iphone-6-658844_1280-1" alt="iphone-6-658844_1280-1" srcset="https://themify.me/demo/themes/simple/files/2016/03/iphone-6-658844_1280-1.png 230w, https://themify.me/demo/themes/simple/files/2016/03/iphone-6-658844_1280-1-150x150.png 150w" sizes="(max-width: 230px) 100vw, 230px" /> </a>
<a href="https://themify.me/demo/themes/simple/files/2016/02/iphone-926118_1280-1-1024x682.jpg"
 >
 <img src="https://themify.me/demo/themes/simple/files/2016/03/iphone-926118_1280-1-230x230-230x230.png" width="230" height="230" title="" alt=""> </a>
<a href="https://themify.me/demo/themes/simple/files/2016/02/mobile-791164_1280-1024x682.jpg"
 >
 <img src="https://themify.me/demo/themes/simple/files/2016/03/mobile-791164_1280-230x230-230x230.png" width="230" height="230" title="" alt=""> </a>
<a href="https://themify.me/demo/themes/simple/files/2016/02/iphone-1067989_1280-1024x768.jpg"
 >
 <img src="https://themify.me/demo/themes/simple/files/2016/03/iphone-1067989_1280-230x230-230x230.png" width="230" height="230" title="" alt=""> </a>
<a href="https://themify.me/demo/themes/simple/files/2016/02/apple-1034304_1280-1024x768.jpg"
 >
 <img src="https://themify.me/demo/themes/simple/files/2016/03/apple-1034304_1280-230x230-230x230.png" width="230" height="230" title="" alt=""> </a>
<a href="https://themify.me/demo/themes/simple/files/2016/02/iphone-518101_1280-1-1024x682.jpg"
 >
 <img src="https://themify.me/demo/themes/simple/files/2016/03/iphone-518101_1280-1-230x230-230x230.png" width="230" height="230" title="" alt=""> </a>
<a href="https://themify.me/demo/themes/simple/files/2016/02/girl-925284_1280-1024x682.jpg"
 >
 <img src="https://themify.me/demo/themes/simple/files/2016/03/girl-925284_1280-230x230-230x230.png" width="230" height="230" title="" alt=""> </a>
<a href="https://themify.me/demo/themes/simple/files/2016/02/phone-762550_1280-1024x682.jpg"
 >
 <img src="https://themify.me/demo/themes/simple/files/2016/03/phone-762550_1280-230x230-230x230.png" width="230" height="230" title="" alt=""> </a>
<a href="https://themify.me/demo/themes/simple/files/2016/02/table-1100265_1280-1024x767.jpg"
 >
 <img src="https://themify.me/demo/themes/simple/files/2016/03/table-1100265_1280-230x230-230x230.png" width="230" height="230" title="" alt=""> </a><!--/themify_builder_static-->',
  'post_title' => 'Shop',
  'post_excerpt' => '',
  'post_name' => 'home',
  'post_modified' => '2020-09-17 20:21:09',
  'post_modified_gmt' => '2020-09-17 20:21:09',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/simple/?page_id=90',
  'menu_order' => 0,
  'post_type' => 'page',
  'meta_input' => 
  array (
    'page_layout' => 'sidebar-none',
    'content_width' => 'full_width',
    'hide_page_title' => 'yes',
    'header_wrap' => 'transparent',
    'background_repeat' => 'fullcover',
    'order' => 'desc',
    'orderby' => 'date',
    'layout' => 'list-post',
    'display_content' => 'content',
    'hide_title' => 'default',
    'unlink_title' => 'default',
    'hide_date' => 'default',
    'media_position' => 'default',
    'hide_image' => 'default',
    'unlink_image' => 'default',
    'hide_navigation' => 'default',
    '_themify_builder_settings_json' => '[{\\"element_id\\":\\"d274b7c\\",\\"cols\\":[{\\"element_id\\":\\"39b7897\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"3d23286\\",\\"mod_settings\\":{\\"content_text\\":\\"<h1>Themify Simple<\\\\/h1>\\\\n<p>Simple is a free theme to make fast sites with WordPress.<\\\\/p>\\",\\"font_color\\":\\"ffffff_1.00\\",\\"font_size\\":\\"1.1\\",\\"font_size_unit\\":\\"em\\",\\"padding_top_unit\\":\\"%\\",\\"padding_right\\":\\"15\\",\\"padding_right_unit\\":\\"%\\",\\"padding_left\\":\\"15\\",\\"padding_left_unit\\":\\"%\\",\\"animation_effect\\":\\"fadeInUp\\"}},{\\"mod_name\\":\\"buttons\\",\\"element_id\\":\\"dkd0647\\",\\"mod_settings\\":{\\"content_button\\":[{\\"label\\":\\"Download\\",\\"link\\":\\"https:\\\\/\\\\/themify.me\\\\/themes\\\\/simple\\",\\"link_options\\":\\"regular\\",\\"lightbox_width_unit\\":\\"px\\",\\"lightbox_height_unit\\":\\"px\\",\\"icon_alignment\\":\\"left\\",\\"button_color_bg\\":\\"tb_default_color\\"}],\\"display\\":\\"buttons-horizontal\\",\\"buttons_style\\":\\"outline\\",\\"buttons_shape\\":\\"circle\\",\\"buttons_size\\":\\"large\\",\\"animation_effect\\":\\"fadeInUp\\"}},{\\"mod_name\\":\\"icon\\",\\"element_id\\":\\"c546d70\\",\\"mod_settings\\":{\\"background_repeat\\":\\"repeat\\",\\"padding_top\\":7,\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"0\\",\\"padding_bottom_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"1\\",\\"checkbox_border_apply_all\\":\\"1\\",\\"icon_size\\":\\"xlarge\\",\\"icon_style\\":\\"none\\",\\"icon_arrangement\\":\\"icon_horizontal\\",\\"content_icon\\":[{\\"icon\\":\\"fa-angle-double-down\\",\\"link\\":\\"#products\\",\\"link_options\\":\\"regular\\",\\"icon_color_bg\\":\\"tb_default_color\\"}],\\"animation_effect\\":\\"bounce\\",\\"animation_effect_repeat\\":\\"5\\",\\"icon_position\\":\\"icon_position_left\\"}}]}],\\"column_alignment\\":\\"col_align_middle\\",\\"styling\\":{\\"row_height\\":\\"fullheight\\",\\"custom_css_row\\":\\"full-height\\",\\"background_video\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/wp-content\\\\/blogs.dir\\\\/83\\\\/files\\\\/2016\\\\/02\\\\/girl-street.mp4\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/simple\\\\/files\\\\/2016\\\\/02\\\\/model-600238_1920-1024x683.jpg\\",\\"background_repeat\\":\\"fullcover\\",\\"background_position\\":\\"center-center\\",\\"background_color\\":\\"000000_1.00\\",\\"cover_color-type\\":\\"color\\",\\"cover_color\\":\\"000000_0.38\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"cover_color_hover\\":\\"000000_0.69\\",\\"text_align\\":\\"center\\",\\"link_color\\":\\"ffffff_1.00\\",\\"padding_top_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\",\\"padding_opp_left\\":false,\\"padding_opp_top\\":false}},{\\"element_id\\":\\"a7adc75\\",\\"cols\\":[{\\"element_id\\":\\"c83034e\\",\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"element_id\\":\\"d7d9dbb\\",\\"cols\\":[{\\"element_id\\":\\"96cfef1\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"2a721ad\\",\\"mod_settings\\":{\\"style_image\\":\\"image-center\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/simple\\\\/files\\\\/2016\\\\/02\\\\/ripped-jeans.png\\",\\"width_image\\":\\"445\\",\\"animation_effect\\":\\"fadeIn\\"}}]},{\\"element_id\\":\\"6f4a4da\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"c9f6e91\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2 style=\\\\\\"text-align: left;\\\\\\">Ripped Jeans<\\\\/h2>\\\\n<p style=\\\\\\"text-align: left;\\\\\\">Cras non ultricies nulla, quis varius orci. Nulla ac pellentesque eros, eu interdum leo. Phasellus non dui viverra, consectetur mauris ac, pharetra massa.<\\\\/p>\\",\\"font_color\\":\\"ffffff\\",\\"text_align\\":\\"left\\",\\"padding_top\\":\\"5\\",\\"padding_top_unit\\":\\"%\\",\\"padding_right\\":\\"10\\",\\"padding_right_unit\\":\\"%\\",\\"padding_left\\":\\"5\\",\\"padding_left_unit\\":\\"%\\"}}]}],\\"column_alignment\\":\\"col_align_middle\\"}]}],\\"styling\\":{\\"row_anchor\\":\\"products\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/simple\\\\/files\\\\/2016\\\\/02\\\\/jeans-1024x478.jpg\\",\\"background_repeat\\":\\"builder-parallax-scrolling\\",\\"background_position\\":\\"center-center\\",\\"padding_top\\":\\"10\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"10\\",\\"padding_bottom_unit\\":\\"%\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\"}},{\\"element_id\\":\\"347d708\\",\\"cols\\":[{\\"element_id\\":\\"fcb3a4b\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"2207602\\",\\"mod_settings\\":{\\"style_image\\":\\"image-left\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/simple\\\\/files\\\\/2016\\\\/02\\\\/smartwatch.png\\",\\"width_image\\":\\"315\\",\\"padding_top\\":\\"20\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"5\\",\\"padding_bottom_unit\\":\\"%\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"0dd051a\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Smart Watch<\\\\/h2>\\\\n<p>Epretium condimentum tiam fermentum condimentum elit ac accumsan. Proin cursus, lectus malesuada , quam malesuada purus, et sodales diam erat velest.<\\\\/p>\\",\\"text_align\\":\\"left\\",\\"padding_bottom\\":\\"17\\",\\"padding_bottom_unit\\":\\"%\\"}}],\\"styling\\":{\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/simple\\\\/files\\\\/2016\\\\/02\\\\/smartwatch-bg-1.jpg\\",\\"background_repeat\\":\\"fullcover\\",\\"text_align\\":\\"center\\",\\"padding_right\\":\\"10\\",\\"padding_right_unit\\":\\"%\\",\\"padding_left\\":\\"10\\",\\"padding_left_unit\\":\\"%\\"}},{\\"element_id\\":\\"a8baf90\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"46614dc\\",\\"mod_settings\\":{\\"style_image\\":\\"image-left\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/simple\\\\/files\\\\/2016\\\\/02\\\\/iMac-3.png\\",\\"width_image\\":\\"315\\",\\"padding_top\\":\\"19\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"5\\",\\"padding_bottom_unit\\":\\"%\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"31d8efb\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>iMac<\\\\/h2>\\\\n<p>Epretium condimentum tiam fermentum condimentumquam odio malesuada purus, elit ac accumsan. Proin cursus, lectus malesuada, et sodales diam erat velest.<\\\\/p>\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\",\\"text_align\\":\\"left\\",\\"padding_bottom\\":\\"17\\",\\"padding_bottom_unit\\":\\"%\\"}}],\\"styling\\":{\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/simple\\\\/files\\\\/2016\\\\/02\\\\/imac-bg.jpg\\",\\"background_repeat\\":\\"fullcover\\",\\"text_align\\":\\"center\\",\\"padding_right\\":\\"10\\",\\"padding_right_unit\\":\\"%\\",\\"padding_left\\":\\"10\\",\\"padding_left_unit\\":\\"%\\"}}],\\"gutter\\":\\"gutter-none\\",\\"styling\\":{\\"row_width\\":\\"fullwidth-content\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"font_color\\":\\"ffffff_1.00\\",\\"link_color\\":\\"ffffff_1.00\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\"}},{\\"element_id\\":\\"63fae3e\\",\\"cols\\":[{\\"element_id\\":\\"b085f58\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"c8a7089\\",\\"mod_settings\\":{\\"style_image\\":\\"image-center\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/simple\\\\/files\\\\/2016\\\\/02\\\\/leather-shoes.png\\",\\"width_image\\":\\"400\\",\\"padding_top\\":\\"35\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"20\\",\\"padding_bottom_unit\\":\\"%\\",\\"margin_bottom\\":\\"10\\",\\"margin_bottom_unit\\":\\"%\\"}}],\\"styling\\":{\\"cover_color\\":\\"000000_0.59\\",\\"text_align\\":\\"center\\",\\"padding_right\\":\\"5\\",\\"padding_right_unit\\":\\"%\\",\\"padding_left\\":\\"5\\",\\"padding_left_unit\\":\\"%\\"}},{\\"element_id\\":\\"b531919\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"28922ca\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>Leather Shoes<\\\\/h2>\\\\n<p>Cras non ultricies nulla, quis varius orci. Nulla ac pellentesque eros, eu interdum leo. Phasellus non dui viverra, consectetur mauris ac, pharetra massa. Curabitur posuere posuere dolor.<\\\\/p>\\",\\"text_align\\":\\"left\\",\\"padding_top\\":\\"35\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"20\\",\\"padding_bottom_unit\\":\\"%\\"}}],\\"styling\\":{\\"text_align\\":\\"left\\",\\"padding_right\\":\\"5\\",\\"padding_right_unit\\":\\"%\\",\\"padding_left\\":\\"5\\",\\"padding_left_unit\\":\\"%\\"}}],\\"gutter\\":\\"gutter-none\\",\\"styling\\":{\\"row_width\\":\\"fullwidth\\",\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/simple\\\\/files\\\\/2016\\\\/02\\\\/leather-shoes-bg-1024x479.jpg\\",\\"background_repeat\\":\\"fullcover\\",\\"background_position\\":\\"center-center\\",\\"font_color\\":\\"ffffff\\",\\"text_align\\":\\"center\\",\\"link_color\\":\\"ffffff\\",\\"padding_bottom_unit\\":\\"%\\"}},{\\"element_id\\":\\"b4c72dc\\",\\"cols\\":[{\\"element_id\\":\\"2c30976\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"3241606\\",\\"mod_settings\\":{\\"style_image\\":\\"image-left\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/simple\\\\/files\\\\/2016\\\\/02\\\\/iphone.png\\",\\"width_image\\":\\"175\\",\\"padding_top\\":\\"20\\",\\"padding_top_unit\\":\\"%\\",\\"padding_bottom\\":\\"5\\",\\"padding_bottom_unit\\":\\"%\\"}},{\\"mod_name\\":\\"text\\",\\"element_id\\":\\"ef7aa7e\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2>iPhone<\\\\/h2>\\",\\"text_align\\":\\"left\\",\\"padding_bottom\\":\\"10\\",\\"padding_bottom_unit\\":\\"%\\"}}],\\"styling\\":{\\"background_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/simple\\\\/files\\\\/2016\\\\/03\\\\/iphonebg.jpg\\",\\"background_repeat\\":\\"fullcover\\",\\"text_align\\":\\"center\\",\\"padding_right\\":\\"10\\",\\"padding_right_unit\\":\\"%\\",\\"padding_left\\":\\"10\\",\\"padding_left_unit\\":\\"%\\"}},{\\"element_id\\":\\"1f80f18\\",\\"grid_class\\":\\"col4-2\\",\\"modules\\":[{\\"element_id\\":\\"ee9a703\\",\\"cols\\":[{\\"element_id\\":\\"de1f325\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"5ab0acd\\",\\"mod_settings\\":{\\"style_image\\":\\"image-top\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/simple\\\\/files\\\\/2016\\\\/03\\\\/iphone-6-658844_1280-1.png\\",\\"width_image\\":\\"230\\",\\"auto_fullwidth\\":\\"1\\",\\"height_image\\":\\"230\\",\\"link_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/simple\\\\/files\\\\/2016\\\\/02\\\\/iphone-6-658844_1280-1-1024x682.jpg\\",\\"param_image\\":\\"lightbox\\"}},{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"8148060\\",\\"mod_settings\\":{\\"style_image\\":\\"image-top\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/simple\\\\/files\\\\/2016\\\\/03\\\\/iphone-926118_1280-1-230x230.png\\",\\"width_image\\":\\"230\\",\\"auto_fullwidth\\":\\"1\\",\\"height_image\\":\\"230\\",\\"link_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/simple\\\\/files\\\\/2016\\\\/02\\\\/iphone-926118_1280-1-1024x682.jpg\\",\\"param_image\\":\\"lightbox\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\"}},{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"49862b2\\",\\"mod_settings\\":{\\"style_image\\":\\"image-top\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/simple\\\\/files\\\\/2016\\\\/03\\\\/mobile-791164_1280-230x230.png\\",\\"width_image\\":\\"230\\",\\"auto_fullwidth\\":\\"1\\",\\"height_image\\":\\"230\\",\\"link_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/simple\\\\/files\\\\/2016\\\\/02\\\\/mobile-791164_1280-1024x682.jpg\\",\\"param_image\\":\\"lightbox\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\"}}]},{\\"element_id\\":\\"ea91ac4\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"b2a8de2\\",\\"mod_settings\\":{\\"style_image\\":\\"image-top\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/simple\\\\/files\\\\/2016\\\\/03\\\\/iphone-1067989_1280-230x230.png\\",\\"width_image\\":\\"230\\",\\"auto_fullwidth\\":\\"1\\",\\"height_image\\":\\"230\\",\\"link_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/simple\\\\/files\\\\/2016\\\\/02\\\\/iphone-1067989_1280-1024x768.jpg\\",\\"param_image\\":\\"lightbox\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\"}},{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"9f29fd8\\",\\"mod_settings\\":{\\"style_image\\":\\"image-top\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/simple\\\\/files\\\\/2016\\\\/03\\\\/apple-1034304_1280-230x230.png\\",\\"width_image\\":\\"230\\",\\"auto_fullwidth\\":\\"1\\",\\"height_image\\":\\"230\\",\\"link_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/simple\\\\/files\\\\/2016\\\\/02\\\\/apple-1034304_1280-1024x768.jpg\\",\\"param_image\\":\\"lightbox\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\"}},{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"845e335\\",\\"mod_settings\\":{\\"style_image\\":\\"image-top\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/simple\\\\/files\\\\/2016\\\\/03\\\\/iphone-518101_1280-1-230x230.png\\",\\"width_image\\":\\"230\\",\\"auto_fullwidth\\":\\"1\\",\\"height_image\\":\\"230\\",\\"link_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/simple\\\\/files\\\\/2016\\\\/02\\\\/iphone-518101_1280-1-1024x682.jpg\\",\\"param_image\\":\\"lightbox\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\"}}]},{\\"element_id\\":\\"80fe313\\",\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"bb30777\\",\\"mod_settings\\":{\\"style_image\\":\\"image-top\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/simple\\\\/files\\\\/2016\\\\/03\\\\/girl-925284_1280-230x230.png\\",\\"width_image\\":\\"230\\",\\"auto_fullwidth\\":\\"1\\",\\"height_image\\":\\"230\\",\\"link_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/simple\\\\/files\\\\/2016\\\\/02\\\\/girl-925284_1280-1024x682.jpg\\",\\"param_image\\":\\"lightbox\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\"}},{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"3b6bf00\\",\\"mod_settings\\":{\\"style_image\\":\\"image-top\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/simple\\\\/files\\\\/2016\\\\/03\\\\/phone-762550_1280-230x230.png\\",\\"width_image\\":\\"230\\",\\"auto_fullwidth\\":\\"1\\",\\"height_image\\":\\"230\\",\\"link_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/simple\\\\/files\\\\/2016\\\\/02\\\\/phone-762550_1280-1024x682.jpg\\",\\"param_image\\":\\"lightbox\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\"}},{\\"mod_name\\":\\"image\\",\\"element_id\\":\\"f12ef2e\\",\\"mod_settings\\":{\\"style_image\\":\\"image-top\\",\\"url_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/simple\\\\/files\\\\/2016\\\\/03\\\\/table-1100265_1280-230x230.png\\",\\"width_image\\":\\"230\\",\\"auto_fullwidth\\":\\"1\\",\\"height_image\\":\\"230\\",\\"link_image\\":\\"https:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/simple\\\\/files\\\\/2016\\\\/02\\\\/table-1100265_1280-1024x767.jpg\\",\\"param_image\\":\\"lightbox\\",\\"visibility_desktop_hide\\":\\"hide\\",\\"visibility_tablet_hide\\":\\"hide\\",\\"visibility_mobile_hide\\":\\"hide\\"}}]}],\\"gutter\\":\\"gutter-none\\"}],\\"styling\\":{\\"background_repeat\\":\\"fullcover\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"text_align\\":\\"center\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\"}}],\\"gutter\\":\\"gutter-none\\",\\"styling\\":{\\"row_width\\":\\"fullwidth-content\\",\\"cover_color-type\\":\\"color\\",\\"cover_color_hover-type\\":\\"hover_color\\",\\"font_color\\":\\"ffffff_1.00\\",\\"text_align\\":\\"center\\",\\"link_color\\":\\"ffffff_1.00\\",\\"checkbox_padding_apply_all\\":\\"padding\\",\\"checkbox_margin_apply_all\\":\\"margin\\",\\"checkbox_border_apply_all\\":\\"border\\"}}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 2339,
  'post_date' => '2014-06-24 01:28:36',
  'post_date_gmt' => '2014-06-24 01:28:36',
  'post_content' => '',
  'post_title' => 'News',
  'post_excerpt' => '',
  'post_name' => 'news',
  'post_modified' => '2014-06-24 01:28:36',
  'post_modified_gmt' => '2014-06-24 01:28:36',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'http://themify.me/demo/themes/builder-layouts/?post_type=tbuilder_layout&amp;p=2339',
  'menu_order' => 0,
  'post_type' => 'tbuilder_layout',
  'meta_input' => 
  array (
    '_themify_builder_settings_json' => '[{\\"row_order\\":\\"0\\",\\"cols\\":[{\\"grid_class\\":\\"col-full first\\",\\"modules\\":[{\\"mod_name\\":\\"slider\\",\\"mod_settings\\":{\\"layout_display_slider\\":\\"blog\\",\\"blog_category_slider\\":\\"0|multiple\\",\\"slider_category_slider\\":\\"|single\\",\\"portfolio_category_slider\\":\\"|single\\",\\"testimonial_category_slider\\":\\"|single\\",\\"posts_per_page_slider\\":\\"6\\",\\"display_slider\\":\\"none\\",\\"layout_slider\\":\\"slider-default\\",\\"img_w_slider\\":\\"300\\",\\"img_h_slider\\":\\"150\\",\\"visible_opt_slider\\":\\"4\\",\\"auto_scroll_opt_slider\\":\\"4\\",\\"scroll_opt_slider\\":\\"1\\",\\"speed_opt_slider\\":\\"normal\\",\\"effect_slider\\":\\"scroll\\",\\"pause_on_hover_slider\\":\\"resume\\",\\"wrap_slider\\":\\"yes\\",\\"show_nav_slider\\":\\"yes\\",\\"show_arrow_slider\\":\\"yes\\",\\"left_margin_slider\\":\\"10\\",\\"right_margin_slider\\":\\"10\\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"eom5823\\"},{\\"mod_name\\":\\"text\\",\\"mod_settings\\":{\\"content_text\\":\\"<p><a href=\\\\\\\\\\\\\\"http:\\\\/\\\\/themify.me\\\\\\\\\\\\\\"><img class=\\\\\\\\\\\\\\"aligncenter\\\\\\\\\\\\\\" src=\\\\\\\\\\\\\\"http:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/magazine\\\\/files\\\\/2013\\\\/08\\\\/728x90.png\\\\\\\\\\\\\\" alt=\\\\\\\\\\\\\\"\\\\\\\\\\\\\\" \\\\/><\\\\/a><\\\\/p>\\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"xv5i009\\"},{\\"mod_name\\":\\"divider\\",\\"mod_settings\\":{\\"style_divider\\":\\"solid\\",\\"stroke_w_divider\\":\\"3\\",\\"color_divider\\":\\"000000\\",\\"top_margin_divider\\":\\"40\\",\\"bottom_margin_divider\\":\\"20\\"},\\"element_id\\":\\"0ej9593\\"}],\\"element_id\\":\\"1cqs600\\"}],\\"element_id\\":\\"8b0w053\\"},{\\"row_order\\":\\"1\\",\\"cols\\":[{\\"grid_class\\":\\"col3-1 first\\",\\"modules\\":[{\\"mod_name\\":\\"post\\",\\"mod_settings\\":{\\"mod_title_post\\":\\"Top Stories\\",\\"layout_post\\":\\"grid2\\",\\"category_post\\":\\"0|multiple\\",\\"post_per_page_post\\":\\"4\\",\\"order_post\\":\\"desc\\",\\"orderby_post\\":\\"date\\",\\"display_post\\":\\"none\\",\\"img_width_post\\":\\"200\\",\\"img_height_post\\":\\"100\\",\\"hide_post_date_post\\":\\"yes\\",\\"hide_post_meta_post\\":\\"yes\\",\\"hide_page_nav_post\\":\\"yes\\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"rd59027\\"},{\\"mod_name\\":\\"text\\",\\"mod_settings\\":{\\"content_text\\":\\"<p><a href=\\\\\\\\\\\\\\"#\\\\\\\\\\\\\\"><img alt=\\\\\\\\\\\\\\"\\\\\\\\\\\\\\" src=\\\\\\\\\\\\\\"http:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/magazine\\\\/files\\\\/2013\\\\/08\\\\/300x250.png\\\\\\\\\\\\\\"><\\\\/a><\\\\/p>\\\\n\\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"tymp890\\"},{\\"mod_name\\":\\"box\\",\\"mod_settings\\":{\\"content_box\\":\\"<h3>Subscribe Now<\\\\/h3><div><p>Sign up for a monthly subscription. Pay for the first month and you\\\\\\\\\\\'ll get the next one free.<\\\\/p><\\\\/div>\\",\\"color_box\\":\\"yellow\\"},\\"element_id\\":\\"p99v003\\"},{\\"mod_name\\":\\"divider\\",\\"mod_settings\\":{\\"style_divider\\":\\"solid\\",\\"stroke_w_divider\\":\\"3\\",\\"color_divider\\":\\"000000\\",\\"top_margin_divider\\":\\"40\\",\\"bottom_margin_divider\\":\\"20\\"},\\"element_id\\":\\"8s1s200\\"},{\\"mod_name\\":\\"post\\",\\"mod_settings\\":{\\"mod_title_post\\":\\"Sports\\",\\"layout_post\\":\\"list-post\\",\\"category_post\\":\\"0|multiple\\",\\"post_per_page_post\\":\\"3\\",\\"order_post\\":\\"desc\\",\\"orderby_post\\":\\"date\\",\\"display_post\\":\\"excerpt\\",\\"img_width_post\\":\\"400\\",\\"img_height_post\\":\\"200\\",\\"hide_post_meta_post\\":\\"yes\\",\\"hide_page_nav_post\\":\\"yes\\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"1dnd501\\"}],\\"element_id\\":\\"febx032\\"},{\\"grid_class\\":\\"col3-2 last\\",\\"modules\\":[{\\"mod_name\\":\\"post\\",\\"mod_settings\\":{\\"mod_title_post\\":\\"Today\\\\\\\\\\\'s\\",\\"layout_post\\":\\"list-post\\",\\"category_post\\":\\"0|multiple\\",\\"post_per_page_post\\":\\"1\\",\\"order_post\\":\\"desc\\",\\"orderby_post\\":\\"date\\",\\"display_post\\":\\"excerpt\\",\\"img_width_post\\":\\"760\\",\\"img_height_post\\":\\"300\\",\\"hide_post_date_post\\":\\"yes\\",\\"hide_post_meta_post\\":\\"yes\\",\\"hide_page_nav_post\\":\\"yes\\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"c916010\\"},{\\"mod_name\\":\\"text\\",\\"mod_settings\\":{\\"content_text\\":\\"<p><a href=\\\\\\\\\\\\\\"#\\\\\\\\\\\\\\"><img src=\\\\\\\\\\\\\\"http:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/magazine\\\\/files\\\\/2013\\\\/08\\\\/468x60.png\\\\\\\\\\\\\\" alt=\\\\\\\\\\\\\\"\\\\\\\\\\\\\\" \\\\/><\\\\/a><\\\\/p>\\\\n\\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"8ani305\\"},{\\"mod_name\\":\\"divider\\",\\"mod_settings\\":{\\"style_divider\\":\\"solid\\",\\"stroke_w_divider\\":\\"3\\",\\"color_divider\\":\\"000000\\",\\"top_margin_divider\\":\\"40\\",\\"bottom_margin_divider\\":\\"20\\"},\\"element_id\\":\\"61y7000\\"},{\\"mod_name\\":\\"post\\",\\"mod_settings\\":{\\"mod_title_post\\":\\"Culture\\",\\"layout_post\\":\\"grid3\\",\\"category_post\\":\\"0|multiple\\",\\"post_per_page_post\\":\\"3\\",\\"order_post\\":\\"desc\\",\\"orderby_post\\":\\"date\\",\\"display_post\\":\\"excerpt\\",\\"img_width_post\\":\\"300\\",\\"img_height_post\\":\\"150\\",\\"hide_post_meta_post\\":\\"yes\\",\\"hide_page_nav_post\\":\\"yes\\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"p7ai000\\"},{\\"mod_name\\":\\"divider\\",\\"mod_settings\\":{\\"style_divider\\":\\"solid\\",\\"stroke_w_divider\\":\\"3\\",\\"color_divider\\":\\"000000\\",\\"top_margin_divider\\":\\"40\\",\\"bottom_margin_divider\\":\\"20\\"},\\"element_id\\":\\"7qpl513\\"},{\\"mod_name\\":\\"slider\\",\\"mod_settings\\":{\\"mod_title_slider\\":\\"World\\",\\"layout_display_slider\\":\\"blog\\",\\"blog_category_slider\\":\\"world|multiple\\",\\"slider_category_slider\\":\\"|single\\",\\"portfolio_category_slider\\":\\"|single\\",\\"posts_per_page_slider\\":\\"3\\",\\"display_slider\\":\\"excerpt\\",\\"layout_slider\\":\\"slider-caption-overlay\\",\\"img_w_slider\\":\\"642\\",\\"img_h_slider\\":\\"321\\",\\"visible_opt_slider\\":\\"1\\",\\"auto_scroll_opt_slider\\":\\"4\\",\\"scroll_opt_slider\\":\\"1\\",\\"speed_opt_slider\\":\\"normal\\",\\"effect_slider\\":\\"scroll\\",\\"wrap_slider\\":\\"yes\\",\\"show_nav_slider\\":\\"no\\",\\"show_arrow_slider\\":\\"no\\"},\\"element_id\\":\\"1to4052\\"},{\\"mod_name\\":\\"post\\",\\"mod_settings\\":{\\"layout_post\\":\\"grid3\\",\\"category_post\\":\\"world|multiple\\",\\"post_per_page_post\\":\\"3\\",\\"order_post\\":\\"desc\\",\\"orderby_post\\":\\"date\\",\\"display_post\\":\\"excerpt\\",\\"img_width_post\\":\\"200\\",\\"img_height_post\\":\\"150\\",\\"hide_post_meta_post\\":\\"yes\\",\\"hide_page_nav_post\\":\\"yes\\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"x9vw122\\"},{\\"mod_name\\":\\"divider\\",\\"mod_settings\\":{\\"style_divider\\":\\"solid\\",\\"stroke_w_divider\\":\\"3\\",\\"color_divider\\":\\"000000\\",\\"top_margin_divider\\":\\"40\\",\\"bottom_margin_divider\\":\\"20\\"},\\"element_id\\":\\"pg5t030\\"},{\\"mod_name\\":\\"post\\",\\"mod_settings\\":{\\"mod_title_post\\":\\"Lifestyle\\",\\"layout_post\\":\\"list-thumb-image\\",\\"category_post\\":\\"0|multiple\\",\\"post_per_page_post\\":\\"3\\",\\"order_post\\":\\"desc\\",\\"orderby_post\\":\\"date\\",\\"display_post\\":\\"excerpt\\",\\"img_width_post\\":\\"150\\",\\"img_height_post\\":\\"150\\",\\"hide_page_nav_post\\":\\"yes\\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"elmi611\\"}],\\"element_id\\":\\"ye85040\\"}],\\"element_id\\":\\"438s555\\"}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
  ),
  'thumb' => false,
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 2337,
  'post_date' => '2014-06-24 01:02:31',
  'post_date_gmt' => '2014-06-24 01:02:31',
  'post_content' => '<!--themify_builder_static--><ul data-id="tb_hg68000" data-visible="4" data-mob-visible="" data-scroll="1" data-auto-scroll="4" data-speed="1" data-wrap="yes" data-arrow="no" data-pagination="no" data-effect="continuously" data-height="variable" data-pause-on-hover="resume" data-play-controller="no" data-horizontal="" > </ul>
<h2 style="text-align: center;">Hello, welcome.</h2><h3 style="text-align: center;">I\'m a web designer and developer</h3>
<ul data-id="tb_rx21300" data-visible="1" data-mob-visible="" data-scroll="1" data-auto-scroll="4" data-speed="1" data-wrap="yes" data-arrow="yes" data-pagination="yes" data-effect="scroll" data-height="variable" data-pause-on-hover="resume" data-play-controller="no" data-horizontal="" > </ul><!--/themify_builder_static-->',
  'post_title' => 'Portfolio',
  'post_excerpt' => '',
  'post_name' => 'portfolio',
  'post_modified' => '2020-02-08 17:33:16',
  'post_modified_gmt' => '2020-02-08 17:33:16',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'http://themify.me/demo/themes/builder-layouts/?post_type=tbuilder_layout&amp;p=2337',
  'menu_order' => 0,
  'post_type' => 'tbuilder_layout',
  'meta_input' => 
  array (
    '_themify_builder_settings_json' => '[{\\"cols\\":[{\\"grid_class\\":\\"col-full first\\",\\"modules\\":[{\\"mod_name\\":\\"slider\\",\\"mod_settings\\":{\\"layout_display_slider\\":\\"portfolio\\",\\"blog_category_slider\\":\\"|single\\",\\"slider_category_slider\\":\\"|single\\",\\"portfolio_category_slider\\":\\"0|multiple\\",\\"testimonial_category_slider\\":\\"|single\\",\\"posts_per_page_slider\\":\\"5\\",\\"display_slider\\":\\"none\\",\\"layout_slider\\":\\"slider-overlay\\",\\"img_w_slider\\":\\"300\\",\\"img_h_slider\\":\\"200\\",\\"visible_opt_slider\\":\\"4\\",\\"auto_scroll_opt_slider\\":\\"4\\",\\"scroll_opt_slider\\":\\"1\\",\\"speed_opt_slider\\":\\"normal\\",\\"effect_slider\\":\\"continuously\\",\\"pause_on_hover_slider\\":\\"resume\\",\\"wrap_slider\\":\\"yes\\",\\"show_nav_slider\\":\\"no\\",\\"show_arrow_slider\\":\\"no\\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"hg68000\\"},{\\"mod_name\\":\\"text\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2 style=\\\\\\"text-align: center;\\\\\\">Hello, welcome.<\\\\/h2><h3 style=\\\\\\"text-align: center;\\\\\\">I\\\'m a web designer and developer<\\\\/h3>\\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"t2y0023\\"},{\\"mod_name\\":\\"slider\\",\\"mod_settings\\":{\\"layout_display_slider\\":\\"portfolio\\",\\"blog_category_slider\\":\\"|single\\",\\"slider_category_slider\\":\\"|single\\",\\"portfolio_category_slider\\":\\"0|multiple\\",\\"testimonial_category_slider\\":\\"|single\\",\\"posts_per_page_slider\\":\\"4\\",\\"display_slider\\":\\"excerpt\\",\\"layout_slider\\":\\"slider-overlay\\",\\"img_w_slider\\":\\"978\\",\\"img_h_slider\\":\\"400\\",\\"visible_opt_slider\\":\\"1\\",\\"auto_scroll_opt_slider\\":\\"4\\",\\"scroll_opt_slider\\":\\"1\\",\\"speed_opt_slider\\":\\"normal\\",\\"effect_slider\\":\\"scroll\\",\\"pause_on_hover_slider\\":\\"resume\\",\\"wrap_slider\\":\\"yes\\",\\"show_nav_slider\\":\\"yes\\",\\"show_arrow_slider\\":\\"yes\\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"rx21300\\"},{\\"mod_name\\":\\"portfolio\\",\\"mod_settings\\":{\\"layout_portfolio\\":\\"grid4\\",\\"category_portfolio\\":\\"0|multiple\\",\\"post_per_page_portfolio\\":\\"8\\",\\"order_portfolio\\":\\"desc\\",\\"orderby_portfolio\\":\\"date\\",\\"display_portfolio\\":\\"none\\",\\"img_width_portfolio\\":\\"300\\",\\"img_height_portfolio\\":\\"200\\",\\"hide_post_date_portfolio\\":\\"yes\\",\\"hide_post_meta_portfolio\\":\\"yes\\",\\"hide_page_nav_portfolio\\":\\"yes\\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"bgj4308\\"}],\\"element_id\\":\\"cw6i001\\"}],\\"element_id\\":\\"k213010\\"}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
  ),
  'thumb' => false,
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 2336,
  'post_date' => '2014-06-24 00:47:41',
  'post_date_gmt' => '2014-06-24 00:47:41',
  'post_content' => '<!--themify_builder_static--><a href="http://themify.me/demo/themes/builder/files/2013/06/126802541.jpg" > <img src="http://themify.me/demo/themes/builder/files/2013/06/126802541.jpg" width="300" alt="Product Single" /> </a>
[gallery link="file" columns="6" ids="2264,2265,2266"]
<h1>Product Title</h1><h3>Price: $15</h3><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur felis risus, elementum sed consequat a, convallis at mi. Vestibulum eu pretium odio. Mauris eu sem orci.</p><p>Vivamus eu libero porttitor, aliquam lacus non, venenatis nisi. Sed magna lorem, scelerisque ut justo non, euismod euismod quam.</p><p>[button style=\'large rounded green flat\' link=\'http://themify.me/themes\' ]Buy Now[/button]</p>
<ul><li><h4>Description</h4><h2>Product Description</h2>
Donec fermentum, urna sit amet ultrices ultrices, nulla ipsum pretium nisl, at consequat turpis risus ac purus. Lorem ipsum dolor sit amet, consectetur adipiscing elit. </li><li><h4>Reviews</h4><h2>Reviews</h2> Mauris porttitor venenatis nulla sed feugiat. Nulla sagittis mi sem, nec egestas arcu <a href=\'http://themify.me/\'>adipiscing eu</a></li></ul><!--/themify_builder_static-->',
  'post_title' => 'Product Single',
  'post_excerpt' => '',
  'post_name' => 'product-single',
  'post_modified' => '2019-11-25 19:36:14',
  'post_modified_gmt' => '2019-11-25 19:36:14',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'http://themify.me/demo/themes/builder-layouts/?post_type=tbuilder_layout&amp;p=2336',
  'menu_order' => 0,
  'post_type' => 'tbuilder_layout',
  'meta_input' => 
  array (
    '_themify_builder_settings_json' => '[{\\"row_order\\":\\"0\\",\\"cols\\":[{\\"grid_class\\":\\"col4-2 first\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"mod_settings\\":{\\"style_image\\":\\"image-top\\",\\"url_image\\":\\"http:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/builder\\\\/files\\\\/2013\\\\/06\\\\/126802541.jpg\\",\\"appearance_image\\":\\"rounded\\",\\"width_image\\":\\"300\\",\\"link_image\\":\\"http:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/builder\\\\/files\\\\/2013\\\\/06\\\\/126802541.jpg\\",\\"param_image\\":\\"lightbox\\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"y051810\\"},{\\"mod_name\\":\\"gallery\\",\\"mod_settings\\":{\\"shortcode_gallery\\":\\"[gallery link=\\\\\\"file\\\\\\" columns=\\\\\\"6\\\\\\" ids=\\\\\\"2264,2265,2266\\\\\\"]\\",\\"thumb_w_gallery\\":\\"60\\",\\"appearance_gallery\\":\\"|\\"},\\"element_id\\":\\"6atz011\\"}],\\"element_id\\":\\"35af091\\"},{\\"grid_class\\":\\"col4-2 last\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"mod_settings\\":{\\"content_text\\":\\"<h1>Product Title<\\\\/h1><h3>Price: $15<\\\\/h3><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur felis risus, elementum sed consequat a, convallis at mi. Vestibulum eu pretium odio. Mauris eu sem orci.<\\\\/p><p>Vivamus eu libero porttitor, aliquam lacus non, venenatis nisi. Sed magna lorem, scelerisque ut justo non, euismod euismod quam.<\\\\/p><p>[button style=\\\'large rounded green flat\\\' link=\\\'http:\\\\/\\\\/themify.me\\\\/themes\\\' ]Buy Now[\\\\/button]<\\\\/p>\\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"yfks815\\"}],\\"element_id\\":\\"78vd108\\"}],\\"styling\\":{\\"row_width\\":\\"\\",\\"animation_effect\\":\\"\\",\\"background_image\\":\\"\\",\\"background_repeat\\":\\"\\",\\"background_video\\":\\"\\",\\"background_color\\":\\"\\",\\"font_family\\":\\"default\\",\\"font_color\\":\\"\\",\\"font_size\\":\\"\\",\\"font_size_unit\\":\\"\\",\\"line_height\\":\\"\\",\\"line_height_unit\\":\\"\\",\\"link_color\\":\\"\\",\\"text_decoration\\":\\"\\",\\"padding_top\\":\\"\\",\\"padding_right\\":\\"\\",\\"padding_bottom\\":\\"\\",\\"padding_left\\":\\"\\",\\"margin_top\\":\\"\\",\\"margin_right\\":\\"\\",\\"margin_bottom\\":\\"50\\",\\"margin_left\\":\\"\\",\\"border_top_color\\":\\"\\",\\"border_top_width\\":\\"\\",\\"border_top_style\\":\\"\\",\\"border_right_color\\":\\"\\",\\"border_right_width\\":\\"\\",\\"border_right_style\\":\\"\\",\\"border_bottom_color\\":\\"\\",\\"border_bottom_width\\":\\"\\",\\"border_bottom_style\\":\\"\\",\\"border_left_color\\":\\"\\",\\"border_left_width\\":\\"\\",\\"border_left_style\\":\\"\\",\\"custom_css_row\\":\\"\\"},\\"element_id\\":\\"gjmj710\\"},{\\"row_order\\":\\"1\\",\\"cols\\":[{\\"grid_class\\":\\"col-full first last\\",\\"modules\\":[{\\"mod_name\\":\\"tab\\",\\"mod_settings\\":{\\"layout_tab\\":\\"minimal\\",\\"color_tab\\":\\"default\\",\\"tab_content_tab\\":[{\\"title_tab\\":\\"Description\\",\\"text_tab\\":\\"<h2>Product Description<\\\\/h2>\\\\n\\\\nDonec fermentum, urna sit amet ultrices ultrices, nulla ipsum pretium nisl, at consequat turpis risus ac purus. Lorem ipsum dolor sit amet, consectetur adipiscing elit.\\\\n\\"},{\\"title_tab\\":\\"Reviews\\",\\"text_tab\\":\\"<h2>Reviews<\\\\/h2>\\\\nMauris porttitor venenatis nulla sed feugiat. Nulla sagittis mi sem, nec egestas arcu <a href=\\\'http:\\\\/\\\\/themify.me\\\\/\\\'>adipiscing eu<\\\\/a>\\"}]},\\"element_id\\":\\"5n12110\\"}],\\"element_id\\":\\"8bk5805\\"}],\\"element_id\\":\\"848x408\\"}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
  ),
  'thumb' => false,
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 2333,
  'post_date' => '2014-06-24 00:03:16',
  'post_date_gmt' => '2014-06-24 00:03:16',
  'post_content' => '<!--themify_builder_static--><h1 style="text-align: center;">Welcome</h1><h4 style="text-align: center;">Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero. Nam risus velit, rhoncus eget consectetur id, posuere at ligula.</h4>
<ul data-id="tb_4rwa088" data-visible="1" data-mob-visible="" data-scroll="1" data-auto-scroll="4" data-speed="1" data-wrap="yes" data-arrow="no" data-pagination="yes" data-effect="scroll" data-height="variable" data-pause-on-hover="resume" data-horizontal="" > 
 <li> <img src="http://themify.me/demo/themes/builder-layouts/files/2013/08/57284001.jpg" width="900" height="400" alt="Slide One" /> 
 <h3> Slide One </h3> </li> <li> <img src="http://themify.me/demo/themes/builder-layouts/files/2014/06/123528979.jpg" width="900" height="400" alt="Slide Two" /> 
 <h3> Slide Two </h3> </li> <li> <img src="http://themify.me/demo/themes/builder-layouts/files/2014/06/122935597.jpg" width="900" height="400" alt="Slide Three" /> 
 <h3> Slide Three </h3> </li> </ul>
<h2 style="text-align: center;">Call of Action</h2><h3 style="text-align: center;">Hire our team now!</h3><p style="text-align: center;">[themify_button link="http://themify.me" style="large blue outline rounded"]More Info[/themify_button] [themify_button link="http://themify.me" style="large blue outline rounded"]Buy Now[/themify_button]</p>
<h2 style="text-align: center;">Services</h2><h3 style="text-align: center;">We do design and development</h3>
<img src="http://themify.me/demo/themes/builder-layouts/files/2014/06/icon-map.png" width="60" height="60" title="Local" alt="Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero." /> <h3> Local </h3> Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero.
<img src="http://themify.me/demo/themes/builder-layouts/files/2014/06/icon-video.png" width="60" height="60" title="Video" alt="Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero." /> <h3> Video </h3> Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero.
<img src="http://themify.me/demo/themes/builder-layouts/files/2014/06/icon-callout.png" width="60" height="60" title="Marketing" alt="Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero." /> <h3> Marketing </h3> Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero.
<img src="http://themify.me/demo/themes/builder-layouts/files/2014/06/icon-slider.png" width="60" height="60" title="Presentation" alt="Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero." /> <h3> Presentation </h3> Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero.
<img src="http://themify.me/demo/themes/builder-layouts/files/2014/06/icon-portfolio.png" width="60" height="60" title="Design" alt="Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero." /> <h3> Design </h3> Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero.
<img src="http://themify.me/demo/themes/builder-layouts/files/2014/06/icon-image.png" width="60" height="60" title="Photography" alt="Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero." /> <h3> Photography </h3> Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero.
<h2 style="text-align: center;">Our Clients</h2><h3 style="text-align: center;">Some of our clients include</h3>
<ul data-id="tb_1ddk977" data-visible="5" data-mob-visible="" data-scroll="1" data-auto-scroll="4" data-speed="1" data-wrap="yes" data-arrow="no" data-pagination="no" data-effect="continuously" data-height="variable" data-pause-on-hover="resume" data-horizontal="" > 
 <li> <img src="http://themify.me/demo/themes/builder-layouts/files/2014/06/logo1.png" width="140" alt="Agency" /> </li> <li> <img src="http://themify.me/demo/themes/builder-layouts/files/2014/06/logo2.png" width="140" alt="Agency" /> </li> <li> <img src="http://themify.me/demo/themes/builder-layouts/files/2014/06/logo3.png" width="140" alt="Agency" /> </li> <li> <img src="http://themify.me/demo/themes/builder-layouts/files/2014/06/logo4.png" width="140" alt="Agency" /> </li> <li> <img src="http://themify.me/demo/themes/builder-layouts/files/2014/06/logo5.png" width="140" alt="Agency" /> </li> <li> <img src="http://themify.me/demo/themes/builder-layouts/files/2014/06/logo6.png" width="140" alt="Agency" /> </li> </ul>
<h2 style="text-align: center;">Testimonials</h2><h3 style="text-align: center;">What do people say?</h3>
<h2 style="text-align: center;">Our Team</h2><h3 style="text-align: center;">Meet us now</h3>
<img src="http://themify.me/demo/themes/builder-layouts/files/2014/06/112268515.jpg" width="90" height="90" title="Sarah, Designer" alt="Fusce augue velit, vulputate elementum semper congue, rhoncus adipiscing nisl. Curabitur vel risus eros, sed eleifend arcu. Donec porttitor hendrerit diam et blandit. Curabitur vitae velit ligula, vitae lobortis massa." /> <h3> Sarah, Designer </h3> Fusce augue velit, vulputate elementum semper congue, rhoncus adipiscing nisl. Curabitur vel risus eros, sed eleifend arcu. Donec porttitor hendrerit diam et blandit. Curabitur vitae velit ligula, vitae lobortis massa.
<img src="http://themify.me/demo/themes/builder-layouts/files/2014/06/92825420.jpg" width="90" height="90" title="John, CEO" alt="Donec porttitor hendrerit diam et blandit. Curabitur vitae velit ligula, vitae lobortis massa. Fusce augue velit, vulputate elementum semper congue, rhoncus adipiscing nisl. Curabitur vel risus eros, sed eleifend arcu." /> <h3> John, CEO </h3> Donec porttitor hendrerit diam et blandit. Curabitur vitae velit ligula, vitae lobortis massa. Fusce augue velit, vulputate elementum semper congue, rhoncus adipiscing nisl. Curabitur vel risus eros, sed eleifend arcu.
<img src="http://themify.me/demo/themes/builder-layouts/files/2014/06/135544689.jpg" width="90" height="90" title="Jen, COO" alt="Donec porttitor hendrerit diam et blandit. Curabitur vitae velit ligula, vitae lobortis massa. Fusce augue velit, vulputate elementum semper congue, rhoncus adipiscing nisl. Curabitur vel risus eros, sed eleifend arcu." /> <h3> Jen, COO </h3> Donec porttitor hendrerit diam et blandit. Curabitur vitae velit ligula, vitae lobortis massa. Fusce augue velit, vulputate elementum semper congue, rhoncus adipiscing nisl. Curabitur vel risus eros, sed eleifend arcu.
<h2 style="text-align: center;">Contact Us</h2><h3 style="text-align: center;">Wanna work with us?</h3>
<h3></h3><iframe frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?q=1+Yonge+Street%2C+Toronto%2C+ON&amp;t=m&amp;z=15&amp;output=embed&amp;iwloc=near"></iframe>
<h3>Our Address</h3><p>1 Yonge Street<br />Toronto, On<br />Canada</p>
<h3>Phone</h3><p>123-345-6789</p>
<h3>Email</h3><p>email@address.com</p><!--/themify_builder_static-->',
  'post_title' => 'Agency',
  'post_excerpt' => '',
  'post_name' => 'agency',
  'post_modified' => '2019-11-22 11:43:17',
  'post_modified_gmt' => '2019-11-22 11:43:17',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'http://themify.me/demo/themes/builder-layouts/tbuilder-layout/product-landing-copy/',
  'menu_order' => 0,
  'post_type' => 'tbuilder_layout',
  'meta_input' => 
  array (
    '_themify_builder_settings_json' => '[{\\"row_order\\":\\"0\\",\\"cols\\":[{\\"grid_class\\":\\"col-full first last\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"mod_settings\\":{\\"content_text\\":\\"<h1 style=\\\\\\"text-align: center;\\\\\\">Welcome<\\\\/h1><h4 style=\\\\\\"text-align: center;\\\\\\">Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero. Nam risus velit, rhoncus eget consectetur id, posuere at ligula.<\\\\/h4>\\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"x5w5919\\"},{\\"mod_name\\":\\"slider\\",\\"mod_settings\\":{\\"layout_display_slider\\":\\"image\\",\\"blog_category_slider\\":\\"|single\\",\\"slider_category_slider\\":\\"|single\\",\\"portfolio_category_slider\\":\\"|single\\",\\"testimonial_category_slider\\":\\"|single\\",\\"display_slider\\":\\"content\\",\\"img_content_slider\\":[{\\"img_url_slider\\":\\"http:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/builder-layouts\\\\/files\\\\/2013\\\\/08\\\\/57284001.jpg\\",\\"img_title_slider\\":\\"Slide One\\"},{\\"img_url_slider\\":\\"http:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/builder-layouts\\\\/files\\\\/2014\\\\/06\\\\/123528979.jpg\\",\\"img_title_slider\\":\\"Slide Two\\"},{\\"img_url_slider\\":\\"http:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/builder-layouts\\\\/files\\\\/2014\\\\/06\\\\/122935597.jpg\\",\\"img_title_slider\\":\\"Slide Three\\"}],\\"layout_slider\\":\\"slider-default\\",\\"img_w_slider\\":\\"900\\",\\"img_h_slider\\":\\"400\\",\\"visible_opt_slider\\":\\"1\\",\\"auto_scroll_opt_slider\\":\\"4\\",\\"scroll_opt_slider\\":\\"1\\",\\"speed_opt_slider\\":\\"normal\\",\\"effect_slider\\":\\"scroll\\",\\"pause_on_hover_slider\\":\\"resume\\",\\"wrap_slider\\":\\"yes\\",\\"show_nav_slider\\":\\"yes\\",\\"show_arrow_slider\\":\\"no\\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"4rwa088\\"}],\\"element_id\\":\\"r6ui928\\"}],\\"styling\\":{\\"row_width\\":\\"\\",\\"animation_effect\\":\\"slide-up\\",\\"background_image\\":\\"http:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/builder-layouts\\\\/files\\\\/2014\\\\/06\\\\/city.jpg\\",\\"background_repeat\\":\\"builder-parallax-scrolling\\",\\"background_video\\":\\"\\",\\"background_color\\":\\"ffffff\\",\\"font_family\\":\\"default\\",\\"font_color\\":\\"000000\\",\\"font_size\\":\\"\\",\\"font_size_unit\\":\\"\\",\\"line_height\\":\\"\\",\\"line_height_unit\\":\\"\\",\\"link_color\\":\\"000000\\",\\"text_decoration\\":\\"\\",\\"padding_top\\":\\"80\\",\\"padding_right\\":\\"\\",\\"padding_bottom\\":\\"20\\",\\"padding_left\\":\\"\\",\\"margin_top\\":\\"\\",\\"margin_right\\":\\"\\",\\"margin_bottom\\":\\"\\",\\"margin_left\\":\\"\\",\\"border_top_color\\":\\"\\",\\"border_top_width\\":\\"\\",\\"border_top_style\\":\\"\\",\\"border_right_color\\":\\"\\",\\"border_right_width\\":\\"\\",\\"border_right_style\\":\\"\\",\\"border_bottom_color\\":\\"\\",\\"border_bottom_width\\":\\"\\",\\"border_bottom_style\\":\\"\\",\\"border_left_color\\":\\"\\",\\"border_left_width\\":\\"\\",\\"border_left_style\\":\\"\\",\\"custom_css_row\\":\\"\\"},\\"element_id\\":\\"yl19008\\"},{\\"row_order\\":\\"1\\",\\"cols\\":[{\\"grid_class\\":\\"col-full first\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2 style=\\\\\\"text-align: center;\\\\\\">Call of Action<\\\\/h2><h3 style=\\\\\\"text-align: center;\\\\\\">Hire our team now!<\\\\/h3><p style=\\\\\\"text-align: center;\\\\\\">[themify_button link=\\\\\\"http:\\\\/\\\\/themify.me\\\\\\" style=\\\\\\"large blue outline rounded\\\\\\"]More Info[\\\\/themify_button] [themify_button link=\\\\\\"http:\\\\/\\\\/themify.me\\\\\\" style=\\\\\\"large blue outline rounded\\\\\\"]Buy Now[\\\\/themify_button]<\\\\/p>\\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"08xa800\\"}],\\"element_id\\":\\"0atc009\\"}],\\"styling\\":{\\"row_width\\":\\"\\",\\"animation_effect\\":\\"\\",\\"background_image\\":\\"\\",\\"background_repeat\\":\\"\\",\\"background_video\\":\\"\\",\\"background_color\\":\\"\\",\\"font_family\\":\\"default\\",\\"font_color\\":\\"\\",\\"font_size\\":\\"\\",\\"font_size_unit\\":\\"\\",\\"line_height\\":\\"\\",\\"line_height_unit\\":\\"\\",\\"link_color\\":\\"\\",\\"text_decoration\\":\\"\\",\\"padding_top\\":\\"40\\",\\"padding_right\\":\\"\\",\\"padding_bottom\\":\\"\\",\\"padding_left\\":\\"\\",\\"margin_top\\":\\"\\",\\"margin_right\\":\\"\\",\\"margin_bottom\\":\\"\\",\\"margin_left\\":\\"\\",\\"border_top_color\\":\\"000000\\",\\"border_top_width\\":\\"3\\",\\"border_top_style\\":\\"solid\\",\\"border_right_color\\":\\"\\",\\"border_right_width\\":\\"\\",\\"border_right_style\\":\\"\\",\\"border_bottom_color\\":\\"\\",\\"border_bottom_width\\":\\"\\",\\"border_bottom_style\\":\\"\\",\\"border_left_color\\":\\"\\",\\"border_left_width\\":\\"\\",\\"border_left_style\\":\\"\\",\\"custom_css_row\\":\\"\\"},\\"element_id\\":\\"reqg080\\"},{\\"row_order\\":\\"2\\",\\"cols\\":[{\\"grid_class\\":\\"col-full first\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2 style=\\\\\\"text-align: center;\\\\\\">Services<\\\\/h2><h3 style=\\\\\\"text-align: center;\\\\\\">We do design and development<\\\\/h3>\\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"86pi991\\"}],\\"element_id\\":\\"xgsp929\\"}],\\"styling\\":{\\"row_width\\":\\"\\",\\"animation_effect\\":\\"\\",\\"background_image\\":\\"\\",\\"background_repeat\\":\\"\\",\\"background_video\\":\\"\\",\\"background_color\\":\\"\\",\\"font_family\\":\\"default\\",\\"font_color\\":\\"\\",\\"font_size\\":\\"\\",\\"font_size_unit\\":\\"\\",\\"line_height\\":\\"\\",\\"line_height_unit\\":\\"\\",\\"link_color\\":\\"\\",\\"text_decoration\\":\\"\\",\\"padding_top\\":\\"40\\",\\"padding_right\\":\\"\\",\\"padding_bottom\\":\\"\\",\\"padding_left\\":\\"\\",\\"margin_top\\":\\"50\\",\\"margin_right\\":\\"\\",\\"margin_bottom\\":\\"\\",\\"margin_left\\":\\"\\",\\"border_top_color\\":\\"000000\\",\\"border_top_width\\":\\"3\\",\\"border_top_style\\":\\"solid\\",\\"border_right_color\\":\\"\\",\\"border_right_width\\":\\"\\",\\"border_right_style\\":\\"\\",\\"border_bottom_color\\":\\"\\",\\"border_bottom_width\\":\\"\\",\\"border_bottom_style\\":\\"\\",\\"border_left_color\\":\\"\\",\\"border_left_width\\":\\"\\",\\"border_left_style\\":\\"\\",\\"custom_css_row\\":\\"\\"},\\"element_id\\":\\"zat6808\\"},{\\"row_order\\":\\"3\\",\\"cols\\":[{\\"grid_class\\":\\"col3-1 first\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"mod_settings\\":{\\"style_image\\":\\"image-left\\",\\"url_image\\":\\"http:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/builder-layouts\\\\/files\\\\/2014\\\\/06\\\\/icon-map.png\\",\\"appearance_image\\":\\"|\\",\\"width_image\\":\\"60\\",\\"height_image\\":\\"60\\",\\"title_image\\":\\"Local\\",\\"param_image\\":\\"|\\",\\"caption_image\\":\\"Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero. \\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"auq7898\\"},{\\"mod_name\\":\\"image\\",\\"mod_settings\\":{\\"style_image\\":\\"image-left\\",\\"url_image\\":\\"http:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/builder-layouts\\\\/files\\\\/2014\\\\/06\\\\/icon-video.png\\",\\"appearance_image\\":\\"|\\",\\"width_image\\":\\"60\\",\\"height_image\\":\\"60\\",\\"title_image\\":\\"Video\\",\\"param_image\\":\\"|\\",\\"caption_image\\":\\"Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero. \\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"l6nu062\\"}],\\"element_id\\":\\"y5ts932\\"},{\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"mod_settings\\":{\\"style_image\\":\\"image-left\\",\\"url_image\\":\\"http:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/builder-layouts\\\\/files\\\\/2014\\\\/06\\\\/icon-callout.png\\",\\"appearance_image\\":\\"|\\",\\"width_image\\":\\"60\\",\\"height_image\\":\\"60\\",\\"title_image\\":\\"Marketing\\",\\"param_image\\":\\"|\\",\\"caption_image\\":\\"Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero. \\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"izcl880\\"},{\\"mod_name\\":\\"image\\",\\"mod_settings\\":{\\"style_image\\":\\"image-left\\",\\"url_image\\":\\"http:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/builder-layouts\\\\/files\\\\/2014\\\\/06\\\\/icon-slider.png\\",\\"appearance_image\\":\\"|\\",\\"width_image\\":\\"60\\",\\"height_image\\":\\"60\\",\\"title_image\\":\\"Presentation\\",\\"param_image\\":\\"|\\",\\"caption_image\\":\\"Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero. \\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"x5tz992\\"}],\\"element_id\\":\\"appl909\\"},{\\"grid_class\\":\\"col3-1 last\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"mod_settings\\":{\\"style_image\\":\\"image-left\\",\\"url_image\\":\\"http:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/builder-layouts\\\\/files\\\\/2014\\\\/06\\\\/icon-portfolio.png\\",\\"appearance_image\\":\\"|\\",\\"width_image\\":\\"60\\",\\"height_image\\":\\"60\\",\\"title_image\\":\\"Design\\",\\"param_image\\":\\"|\\",\\"caption_image\\":\\"Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero. \\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"1o25220\\"},{\\"mod_name\\":\\"image\\",\\"mod_settings\\":{\\"style_image\\":\\"image-left\\",\\"url_image\\":\\"http:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/builder-layouts\\\\/files\\\\/2014\\\\/06\\\\/icon-image.png\\",\\"appearance_image\\":\\"|\\",\\"width_image\\":\\"60\\",\\"height_image\\":\\"60\\",\\"title_image\\":\\"Photography\\",\\"param_image\\":\\"|\\",\\"caption_image\\":\\"Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero. \\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"msid889\\"}],\\"element_id\\":\\"7fql999\\"}],\\"styling\\":{\\"row_width\\":\\"\\",\\"animation_effect\\":\\"\\",\\"background_image\\":\\"\\",\\"background_repeat\\":\\"\\",\\"background_video\\":\\"\\",\\"background_color\\":\\"\\",\\"font_family\\":\\"default\\",\\"font_color\\":\\"\\",\\"font_size\\":\\"\\",\\"font_size_unit\\":\\"\\",\\"line_height\\":\\"\\",\\"line_height_unit\\":\\"\\",\\"link_color\\":\\"\\",\\"text_decoration\\":\\"\\",\\"padding_top\\":\\"0\\",\\"padding_right\\":\\"\\",\\"padding_bottom\\":\\"\\",\\"padding_left\\":\\"\\",\\"margin_top\\":\\"\\",\\"margin_right\\":\\"\\",\\"margin_bottom\\":\\"\\",\\"margin_left\\":\\"\\",\\"border_top_color\\":\\"\\",\\"border_top_width\\":\\"\\",\\"border_top_style\\":\\"\\",\\"border_right_color\\":\\"\\",\\"border_right_width\\":\\"\\",\\"border_right_style\\":\\"\\",\\"border_bottom_color\\":\\"\\",\\"border_bottom_width\\":\\"\\",\\"border_bottom_style\\":\\"\\",\\"border_left_color\\":\\"\\",\\"border_left_width\\":\\"\\",\\"border_left_style\\":\\"\\",\\"custom_css_row\\":\\"\\"},\\"element_id\\":\\"vj80908\\"},{\\"row_order\\":\\"4\\",\\"cols\\":[{\\"grid_class\\":\\"col-full first\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2 style=\\\\\\"text-align: center;\\\\\\">Our Clients<\\\\/h2><h3 style=\\\\\\"text-align: center;\\\\\\">Some of our clients include<\\\\/h3>\\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"gyo2209\\"},{\\"mod_name\\":\\"slider\\",\\"mod_settings\\":{\\"layout_display_slider\\":\\"image\\",\\"blog_category_slider\\":\\"|single\\",\\"slider_category_slider\\":\\"|single\\",\\"portfolio_category_slider\\":\\"|single\\",\\"testimonial_category_slider\\":\\"|single\\",\\"display_slider\\":\\"content\\",\\"img_content_slider\\":[{\\"img_url_slider\\":\\"http:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/builder-layouts\\\\/files\\\\/2014\\\\/06\\\\/logo1.png\\"},{\\"img_url_slider\\":\\"http:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/builder-layouts\\\\/files\\\\/2014\\\\/06\\\\/logo2.png\\"},{\\"img_url_slider\\":\\"http:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/builder-layouts\\\\/files\\\\/2014\\\\/06\\\\/logo3.png\\"},{\\"img_url_slider\\":\\"http:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/builder-layouts\\\\/files\\\\/2014\\\\/06\\\\/logo4.png\\"},{\\"img_url_slider\\":\\"http:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/builder-layouts\\\\/files\\\\/2014\\\\/06\\\\/logo5.png\\"},{\\"img_url_slider\\":\\"http:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/builder-layouts\\\\/files\\\\/2014\\\\/06\\\\/logo6.png\\"}],\\"layout_slider\\":\\"slider-default\\",\\"img_w_slider\\":\\"140\\",\\"visible_opt_slider\\":\\"5\\",\\"auto_scroll_opt_slider\\":\\"4\\",\\"scroll_opt_slider\\":\\"1\\",\\"speed_opt_slider\\":\\"normal\\",\\"effect_slider\\":\\"continuously\\",\\"pause_on_hover_slider\\":\\"resume\\",\\"wrap_slider\\":\\"yes\\",\\"show_nav_slider\\":\\"no\\",\\"show_arrow_slider\\":\\"no\\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"1ddk977\\"}],\\"element_id\\":\\"oqhw990\\"}],\\"styling\\":{\\"animation_effect\\":\\"\\",\\"background_image\\":\\"\\",\\"background_repeat\\":\\"\\",\\"background_video\\":\\"\\",\\"background_color\\":\\"\\",\\"font_family\\":\\"default\\",\\"font_color\\":\\"\\",\\"font_size\\":\\"\\",\\"font_size_unit\\":\\"\\",\\"line_height\\":\\"\\",\\"line_height_unit\\":\\"\\",\\"link_color\\":\\"\\",\\"text_decoration\\":\\"\\",\\"padding_top\\":\\"40\\",\\"padding_right\\":\\"\\",\\"padding_bottom\\":\\"\\",\\"padding_left\\":\\"\\",\\"margin_top\\":\\"50\\",\\"margin_right\\":\\"\\",\\"margin_bottom\\":\\"\\",\\"margin_left\\":\\"\\",\\"border_top_color\\":\\"000000\\",\\"border_top_width\\":\\"3\\",\\"border_top_style\\":\\"solid\\",\\"border_right_color\\":\\"\\",\\"border_right_width\\":\\"\\",\\"border_right_style\\":\\"\\",\\"border_bottom_color\\":\\"\\",\\"border_bottom_width\\":\\"\\",\\"border_bottom_style\\":\\"\\",\\"border_left_color\\":\\"\\",\\"border_left_width\\":\\"\\",\\"border_left_style\\":\\"\\",\\"custom_css_row\\":\\"\\"},\\"element_id\\":\\"dzzd400\\"},{\\"row_order\\":\\"5\\",\\"cols\\":[{\\"grid_class\\":\\"col-full first\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2 style=\\\\\\"text-align: center;\\\\\\">Testimonials<\\\\/h2><h3 style=\\\\\\"text-align: center;\\\\\\">What do people say?<\\\\/h3>\\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"bwzt198\\"},{\\"mod_name\\":\\"testimonial\\",\\"mod_settings\\":{\\"layout_testimonial\\":\\"grid2\\",\\"category_testimonial\\":\\"0|single\\",\\"post_per_page_testimonial\\":\\"4\\",\\"order_testimonial\\":\\"desc\\",\\"orderby_testimonial\\":\\"date\\",\\"display_testimonial\\":\\"content\\",\\"hide_page_nav_testimonial\\":\\"yes\\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"2p7e020\\"}],\\"element_id\\":\\"io0a900\\"}],\\"styling\\":{\\"row_width\\":\\"\\",\\"animation_effect\\":\\"\\",\\"background_image\\":\\"\\",\\"background_repeat\\":\\"\\",\\"background_video\\":\\"\\",\\"background_color\\":\\"\\",\\"font_family\\":\\"default\\",\\"font_color\\":\\"\\",\\"font_size\\":\\"\\",\\"font_size_unit\\":\\"\\",\\"line_height\\":\\"\\",\\"line_height_unit\\":\\"\\",\\"link_color\\":\\"\\",\\"text_decoration\\":\\"\\",\\"padding_top\\":\\"40\\",\\"padding_right\\":\\"\\",\\"padding_bottom\\":\\"0\\",\\"padding_left\\":\\"\\",\\"margin_top\\":\\"50\\",\\"margin_right\\":\\"\\",\\"margin_bottom\\":\\"\\",\\"margin_left\\":\\"\\",\\"border_top_color\\":\\"000000\\",\\"border_top_width\\":\\"3\\",\\"border_top_style\\":\\"solid\\",\\"border_right_color\\":\\"\\",\\"border_right_width\\":\\"\\",\\"border_right_style\\":\\"\\",\\"border_bottom_color\\":\\"\\",\\"border_bottom_width\\":\\"\\",\\"border_bottom_style\\":\\"\\",\\"border_left_color\\":\\"\\",\\"border_left_width\\":\\"\\",\\"border_left_style\\":\\"\\",\\"custom_css_row\\":\\"\\"},\\"element_id\\":\\"yo6k909\\"},{\\"row_order\\":\\"6\\",\\"cols\\":[{\\"grid_class\\":\\"col-full first\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2 style=\\\\\\"text-align: center;\\\\\\">Our Team<\\\\/h2><h3 style=\\\\\\"text-align: center;\\\\\\">Meet us now<\\\\/h3>\\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"qh8j996\\"}],\\"element_id\\":\\"pbco009\\"}],\\"styling\\":{\\"row_width\\":\\"\\",\\"animation_effect\\":\\"\\",\\"background_image\\":\\"\\",\\"background_repeat\\":\\"\\",\\"background_video\\":\\"\\",\\"background_color\\":\\"\\",\\"font_family\\":\\"default\\",\\"font_color\\":\\"\\",\\"font_size\\":\\"\\",\\"font_size_unit\\":\\"\\",\\"line_height\\":\\"\\",\\"line_height_unit\\":\\"\\",\\"link_color\\":\\"\\",\\"text_decoration\\":\\"\\",\\"padding_top\\":\\"40\\",\\"padding_right\\":\\"\\",\\"padding_bottom\\":\\"0\\",\\"padding_left\\":\\"\\",\\"margin_top\\":\\"50\\",\\"margin_right\\":\\"\\",\\"margin_bottom\\":\\"\\",\\"margin_left\\":\\"\\",\\"border_top_color\\":\\"000000\\",\\"border_top_width\\":\\"3\\",\\"border_top_style\\":\\"solid\\",\\"border_right_color\\":\\"\\",\\"border_right_width\\":\\"\\",\\"border_right_style\\":\\"\\",\\"border_bottom_color\\":\\"\\",\\"border_bottom_width\\":\\"\\",\\"border_bottom_style\\":\\"\\",\\"border_left_color\\":\\"\\",\\"border_left_width\\":\\"\\",\\"border_left_style\\":\\"\\",\\"custom_css_row\\":\\"\\"},\\"element_id\\":\\"bku7329\\"},{\\"row_order\\":\\"7\\",\\"cols\\":[{\\"grid_class\\":\\"col3-1 first\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"mod_settings\\":{\\"style_image\\":\\"image-left\\",\\"url_image\\":\\"http:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/builder-layouts\\\\/files\\\\/2014\\\\/06\\\\/112268515.jpg\\",\\"appearance_image\\":\\"circle\\",\\"width_image\\":\\"90\\",\\"height_image\\":\\"90\\",\\"title_image\\":\\"Sarah, Designer\\",\\"param_image\\":\\"|\\",\\"caption_image\\":\\"Fusce augue velit, vulputate elementum semper congue, rhoncus adipiscing nisl. Curabitur vel risus eros, sed eleifend arcu. Donec porttitor hendrerit diam et blandit. Curabitur vitae velit ligula, vitae lobortis massa.\\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"6rk7992\\"}],\\"element_id\\":\\"lnja822\\"},{\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"mod_settings\\":{\\"style_image\\":\\"image-left\\",\\"url_image\\":\\"http:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/builder-layouts\\\\/files\\\\/2014\\\\/06\\\\/92825420.jpg\\",\\"appearance_image\\":\\"circle\\",\\"width_image\\":\\"90\\",\\"height_image\\":\\"90\\",\\"title_image\\":\\"John, CEO\\",\\"param_image\\":\\"|\\",\\"caption_image\\":\\"Donec porttitor hendrerit diam et blandit. Curabitur vitae velit ligula, vitae lobortis massa. Fusce augue velit, vulputate elementum semper congue, rhoncus adipiscing nisl. Curabitur vel risus eros, sed eleifend arcu.\\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"ovkj011\\"}],\\"element_id\\":\\"3w3y990\\"},{\\"grid_class\\":\\"col3-1 last\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"mod_settings\\":{\\"style_image\\":\\"image-left\\",\\"url_image\\":\\"http:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/builder-layouts\\\\/files\\\\/2014\\\\/06\\\\/135544689.jpg\\",\\"appearance_image\\":\\"circle\\",\\"width_image\\":\\"90\\",\\"height_image\\":\\"90\\",\\"title_image\\":\\"Jen, COO\\",\\"param_image\\":\\"|\\",\\"caption_image\\":\\"Donec porttitor hendrerit diam et blandit. Curabitur vitae velit ligula, vitae lobortis massa. Fusce augue velit, vulputate elementum semper congue, rhoncus adipiscing nisl. Curabitur vel risus eros, sed eleifend arcu.\\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"zt6s494\\"}],\\"element_id\\":\\"l5tq902\\"}],\\"element_id\\":\\"86ag973\\"},{\\"row_order\\":\\"8\\",\\"cols\\":[{\\"grid_class\\":\\"col-full first\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2 style=\\\\\\"text-align: center;\\\\\\">Contact Us<\\\\/h2><h3 style=\\\\\\"text-align: center;\\\\\\">Wanna work with us?<\\\\/h3>\\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"l5ox492\\"}],\\"element_id\\":\\"d1km604\\"}],\\"styling\\":{\\"row_width\\":\\"\\",\\"animation_effect\\":\\"\\",\\"background_image\\":\\"\\",\\"background_repeat\\":\\"\\",\\"background_video\\":\\"\\",\\"background_color\\":\\"\\",\\"font_family\\":\\"default\\",\\"font_color\\":\\"\\",\\"font_size\\":\\"\\",\\"font_size_unit\\":\\"\\",\\"line_height\\":\\"\\",\\"line_height_unit\\":\\"\\",\\"link_color\\":\\"\\",\\"text_decoration\\":\\"\\",\\"padding_top\\":\\"40\\",\\"padding_right\\":\\"\\",\\"padding_bottom\\":\\"0\\",\\"padding_left\\":\\"\\",\\"margin_top\\":\\"50\\",\\"margin_right\\":\\"\\",\\"margin_bottom\\":\\"\\",\\"margin_left\\":\\"\\",\\"border_top_color\\":\\"000000\\",\\"border_top_width\\":\\"3\\",\\"border_top_style\\":\\"solid\\",\\"border_right_color\\":\\"\\",\\"border_right_width\\":\\"\\",\\"border_right_style\\":\\"\\",\\"border_bottom_color\\":\\"\\",\\"border_bottom_width\\":\\"\\",\\"border_bottom_style\\":\\"\\",\\"border_left_color\\":\\"\\",\\"border_left_width\\":\\"\\",\\"border_left_style\\":\\"\\",\\"custom_css_row\\":\\"\\"},\\"element_id\\":\\"jrul850\\"},{\\"row_order\\":\\"9\\",\\"cols\\":[{\\"grid_class\\":\\"col-full first\\",\\"modules\\":[{\\"mod_name\\":\\"map\\",\\"mod_settings\\":{\\"address_map\\":\\"1 Yonge Street, Toronto, ON\\",\\"zoom_map\\":\\"15\\",\\"w_map\\":\\"100\\",\\"unit_w\\":\\"%\\",\\"h_map\\":\\"500\\",\\"unit_h\\":\\"px\\",\\"b_style_map\\":\\"solid\\",\\"type_map\\":\\"ROADMAP\\",\\"scrollwheel_map\\":\\"enable\\",\\"draggable_map\\":\\"enable\\"},\\"element_id\\":\\"dvvx905\\"}],\\"element_id\\":\\"2i81224\\"}],\\"element_id\\":\\"7k64804\\"},{\\"row_order\\":\\"10\\",\\"cols\\":[{\\"grid_class\\":\\"col3-1 first\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>Our Address<\\\\/h3><p>1 Yonge Street<br \\\\/>Toronto, On<br \\\\/>Canada<\\\\/p>\\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"5792592\\"}],\\"element_id\\":\\"4kdp055\\"},{\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>Phone<\\\\/h3><p>123-345-6789<\\\\/p>\\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"t7wr256\\"}],\\"element_id\\":\\"6vr8099\\"},{\\"grid_class\\":\\"col3-1 last\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>Email<\\\\/h3><p>email@address.com<\\\\/p>\\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"90sn929\\"}],\\"element_id\\":\\"050d220\\"}],\\"element_id\\":\\"i7o8080\\"}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
  ),
  'thumb' => false,
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 315,
  'post_date' => '2014-06-23 23:39:39',
  'post_date_gmt' => '2014-06-23 23:39:39',
  'post_content' => '',
  'post_title' => 'Magazine',
  'post_excerpt' => '',
  'post_name' => 'magazine',
  'post_modified' => '2014-06-23 23:39:39',
  'post_modified_gmt' => '2014-06-23 23:39:39',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'http://themify.me/demo/themes/builder-layouts/?post_type=tbuilder_layout&amp;p=79',
  'menu_order' => 0,
  'post_type' => 'tbuilder_layout',
  'meta_input' => 
  array (
    '_themify_builder_settings_json' => '[{\\"row_order\\":\\"0\\",\\"cols\\":[{\\"grid_class\\":\\"col-full first\\",\\"modules\\":[{\\"mod_name\\":\\"slider\\",\\"mod_settings\\":{\\"layout_display_slider\\":\\"blog\\",\\"blog_category_slider\\":\\"0|multiple\\",\\"slider_category_slider\\":\\"|single\\",\\"portfolio_category_slider\\":\\"|single\\",\\"testimonial_category_slider\\":\\"|single\\",\\"display_slider\\":\\"none\\",\\"hide_post_title_slider\\":\\"no\\",\\"unlink_post_title_slider\\":\\"no\\",\\"hide_feat_img_slider\\":\\"no\\",\\"unlink_feat_img_slider\\":\\"no\\",\\"layout_slider\\":\\"slider-overlay\\",\\"img_w_slider\\":\\"600\\",\\"img_h_slider\\":\\"350\\",\\"visible_opt_slider\\":\\"1\\",\\"auto_scroll_opt_slider\\":\\"4\\",\\"scroll_opt_slider\\":\\"1\\",\\"speed_opt_slider\\":\\"normal\\",\\"effect_slider\\":\\"scroll\\",\\"pause_on_hover_slider\\":\\"resume\\",\\"wrap_slider\\":\\"yes\\",\\"show_nav_slider\\":\\"yes\\",\\"show_arrow_slider\\":\\"yes\\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"a2qg079\\"},{\\"mod_name\\":\\"text\\",\\"mod_settings\\":{\\"content_text\\":\\"<p><a href=\\\\\\\\\\\\\\"#\\\\\\\\\\\\\\"><img class=\\\\\\\\\\\\\\"aligncenter\\\\\\\\\\\\\\" src=\\\\\\\\\\\\\\"http:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/magazine\\\\/files\\\\/2013\\\\/08\\\\/468x60.png\\\\\\\\\\\\\\" alt=\\\\\\\\\\\\\\"\\\\\\\\\\\\\\" \\\\/><\\\\/a><\\\\/p>\\\\n\\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"ppig701\\"},{\\"mod_name\\":\\"divider\\",\\"mod_settings\\":{\\"style_divider\\":\\"solid\\",\\"stroke_w_divider\\":\\"3\\",\\"color_divider\\":\\"000000\\",\\"top_margin_divider\\":\\"40\\",\\"bottom_margin_divider\\":\\"30\\"},\\"element_id\\":\\"tj6a807\\"}],\\"element_id\\":\\"svzd979\\"}],\\"element_id\\":\\"20su007\\"},{\\"row_order\\":\\"1\\",\\"cols\\":[{\\"grid_class\\":\\"col-full first\\",\\"modules\\":[{\\"mod_name\\":\\"post\\",\\"mod_settings\\":{\\"layout_post\\":\\"grid3\\",\\"category_post\\":\\"0|multiple\\",\\"post_per_page_post\\":\\"3\\",\\"order_post\\":\\"desc\\",\\"orderby_post\\":\\"date\\",\\"display_post\\":\\"none\\",\\"img_width_post\\":\\"400\\",\\"img_height_post\\":\\"200\\",\\"hide_post_title_post\\":\\"no\\",\\"hide_post_date_post\\":\\"yes\\",\\"hide_post_meta_post\\":\\"yes\\",\\"hide_page_nav_post\\":\\"yes\\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"6wef966\\"}],\\"element_id\\":\\"w27f090\\"}],\\"element_id\\":\\"och9744\\"},{\\"row_order\\":\\"2\\",\\"cols\\":[{\\"grid_class\\":\\"col4-2 first\\",\\"modules\\":[{\\"mod_name\\":\\"divider\\",\\"mod_settings\\":{\\"style_divider\\":\\"solid\\",\\"stroke_w_divider\\":\\"3\\",\\"color_divider\\":\\"000000\\",\\"top_margin_divider\\":\\"40\\",\\"bottom_margin_divider\\":\\"30\\"},\\"element_id\\":\\"61nv777\\"},{\\"mod_name\\":\\"post\\",\\"mod_settings\\":{\\"mod_title_post\\":\\"Category\\",\\"layout_post\\":\\"list-post\\",\\"category_post\\":\\"0|multiple\\",\\"post_per_page_post\\":\\"1\\",\\"order_post\\":\\"desc\\",\\"orderby_post\\":\\"date\\",\\"display_post\\":\\"excerpt\\",\\"img_width_post\\":\\"600\\",\\"img_height_post\\":\\"300\\",\\"hide_post_date_post\\":\\"yes\\",\\"hide_post_meta_post\\":\\"yes\\",\\"hide_page_nav_post\\":\\"yes\\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"3bxj927\\"}],\\"element_id\\":\\"ghdf087\\"},{\\"grid_class\\":\\"col4-2 last\\",\\"modules\\":[{\\"mod_name\\":\\"divider\\",\\"mod_settings\\":{\\"style_divider\\":\\"solid\\",\\"stroke_w_divider\\":\\"3\\",\\"color_divider\\":\\"000000\\",\\"top_margin_divider\\":\\"40\\",\\"bottom_margin_divider\\":\\"30\\"},\\"element_id\\":\\"dwck097\\"},{\\"mod_name\\":\\"post\\",\\"mod_settings\\":{\\"mod_title_post\\":\\"Category\\",\\"layout_post\\":\\"list-post\\",\\"category_post\\":\\"0|multiple\\",\\"post_per_page_post\\":\\"1\\",\\"order_post\\":\\"desc\\",\\"orderby_post\\":\\"date\\",\\"display_post\\":\\"excerpt\\",\\"img_width_post\\":\\"600\\",\\"img_height_post\\":\\"300\\",\\"hide_post_date_post\\":\\"yes\\",\\"hide_post_meta_post\\":\\"yes\\",\\"hide_page_nav_post\\":\\"yes\\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"sxyq999\\"}],\\"element_id\\":\\"fa42777\\"}],\\"element_id\\":\\"mvbz077\\"},{\\"row_order\\":\\"3\\",\\"cols\\":[{\\"grid_class\\":\\"col4-2 first\\",\\"modules\\":[{\\"mod_name\\":\\"post\\",\\"mod_settings\\":{\\"layout_post\\":\\"list-thumb-image\\",\\"category_post\\":\\"0|multiple\\",\\"post_per_page_post\\":\\"3\\",\\"offset_post\\":\\"1\\",\\"order_post\\":\\"desc\\",\\"orderby_post\\":\\"date\\",\\"display_post\\":\\"none\\",\\"img_width_post\\":\\"80\\",\\"img_height_post\\":\\"80\\",\\"hide_post_date_post\\":\\"yes\\",\\"hide_post_meta_post\\":\\"yes\\",\\"hide_page_nav_post\\":\\"yes\\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"2k2w077\\"}],\\"element_id\\":\\"ts42979\\"},{\\"grid_class\\":\\"col4-2 last\\",\\"modules\\":[{\\"mod_name\\":\\"post\\",\\"mod_settings\\":{\\"layout_post\\":\\"list-thumb-image\\",\\"category_post\\":\\"0|multiple\\",\\"post_per_page_post\\":\\"3\\",\\"offset_post\\":\\"1\\",\\"order_post\\":\\"desc\\",\\"orderby_post\\":\\"date\\",\\"display_post\\":\\"none\\",\\"img_width_post\\":\\"80\\",\\"img_height_post\\":\\"80\\",\\"hide_post_date_post\\":\\"yes\\",\\"hide_post_meta_post\\":\\"yes\\",\\"hide_page_nav_post\\":\\"yes\\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"0555799\\"}],\\"element_id\\":\\"s8ua007\\"}],\\"element_id\\":\\"s4ba797\\"},{\\"row_order\\":\\"4\\",\\"cols\\":[{\\"grid_class\\":\\"col-full\\",\\"modules\\":[{\\"mod_name\\":\\"divider\\",\\"mod_settings\\":{\\"style_divider\\":\\"solid\\",\\"stroke_w_divider\\":\\"3\\",\\"color_divider\\":\\"000000\\",\\"top_margin_divider\\":\\"40\\",\\"bottom_margin_divider\\":\\"30\\"},\\"element_id\\":\\"n25j975\\"},{\\"mod_name\\":\\"post\\",\\"mod_settings\\":{\\"mod_title_post\\":\\"Category\\",\\"layout_post\\":\\"grid2\\",\\"category_post\\":\\"0|multiple\\",\\"post_per_page_post\\":\\"2\\",\\"order_post\\":\\"desc\\",\\"orderby_post\\":\\"date\\",\\"display_post\\":\\"none\\",\\"img_width_post\\":\\"600\\",\\"img_height_post\\":\\"300\\",\\"hide_post_date_post\\":\\"yes\\",\\"hide_post_meta_post\\":\\"yes\\",\\"hide_page_nav_post\\":\\"yes\\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"ol8w806\\"}],\\"element_id\\":\\"115g770\\"}],\\"element_id\\":\\"wid7070\\"},{\\"row_order\\":\\"5\\",\\"cols\\":[{\\"grid_class\\":\\"col-full first\\",\\"modules\\":[{\\"mod_name\\":\\"tab\\",\\"mod_settings\\":{\\"layout_tab\\":\\"minimal\\",\\"color_tab\\":\\"default\\",\\"tab_appearance_tab\\":\\"|\\",\\"tab_content_tab\\":[{\\"title_tab\\":\\"Tab One\\",\\"text_tab\\":\\"<p>Curabitur at arcu id turpis posuere bibendum. Sed commodo mauris eget diam pretium cursus. In sagittis feugiat mauris, in ultrices mauris lacinia eu. Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero. Nam risus velit, rhoncus eget consectetur id, posuere at ligula. Vivamus imperdiet diam ac tortor tempus posuere.<\\\\/p>\\"},{\\"title_tab\\":\\"Tab Two \\",\\"text_tab\\":\\"<p>Vivamus imperdiet diam ac tortor tempus posuere. Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero. Nam risus velit, rhoncus eget consectetur id, posuere at ligula. Curabitur at arcu id turpis posuere bibendum. Sed commodo mauris eget diam pretium cursus. In sagittis feugiat mauris, in ultrices mauris lacinia eu.<\\\\/p>\\"},{\\"title_tab\\":\\"Tab Three\\",\\"text_tab\\":\\"<p>Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero. Nam risus velit, rhoncus eget consectetur id, posuere at ligula. Vivamus imperdiet diam ac tortor tempus posuere. Curabitur at arcu id turpis posuere bibendum. Sed commodo mauris eget diam pretium cursus. In sagittis feugiat mauris, in ultrices mauris lacinia eu.<\\\\/p>\\"}],\\"font_family\\":\\"default\\"},\\"element_id\\":\\"0dx6700\\"}],\\"element_id\\":\\"xebg700\\"}],\\"element_id\\":\\"02ol989\\"}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
  ),
  'thumb' => false,
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 314,
  'post_date' => '2014-06-21 00:06:16',
  'post_date_gmt' => '2014-06-21 00:06:16',
  'post_content' => '<!--themify_builder_static--><h1 style="text-align: center;">Photo Page</h1><h4 style="text-align: center;">Vivamus imperdiet diam ac tortor tempus posuere. Curabitur at arcu id turpis posuere bibendum.</h4>
[gallery columns="5" link="file" ids="69,70,71,72,73,74,75,76,77,78"]
<img src="http://themify.me/demo/themes/builder-layouts/files/2014/06/130178327.jpg" width="600" height="600" title="Image Caption" alt="Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero. Nam risus velit, rhoncus eget consectetur id, posuere at ligula. Vivamus imperdiet diam ac tortor tempus posuere. Curabitur at arcu id turpis posuere bibendum. Sed commodo mauris eget diam pretium cursus." /> <h3> Image Caption </h3> Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero. Nam risus velit, rhoncus eget consectetur id, posuere at ligula. Vivamus imperdiet diam ac tortor tempus posuere. Curabitur at arcu id turpis posuere bibendum. Sed commodo mauris eget diam pretium cursus.
<img src="http://themify.me/demo/themes/builder-layouts/files/2014/06/125312654.jpg" width="300" height="300" alt="Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus." /> Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus.
<img src="http://themify.me/demo/themes/builder-layouts/files/2014/06/123528979.jpg" width="300" height="220" alt="Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero." /> Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero.
<img src="http://themify.me/demo/themes/builder-layouts/files/2014/06/134399270.jpg" width="300" height="240" alt="Sed sagittis, elit egestas rutrum vehicula." /> Sed sagittis, elit egestas rutrum vehicula.
<img src="http://themify.me/demo/themes/builder-layouts/files/2014/06/123612559.jpg" width="300" height="240" alt="Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero." /> Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero.
<h2 style="text-align: center;">Hire Me</h2> <h3 style="text-align: center;">I\'m available for hire</h3> <p style="text-align: center;">[themify_button link="http://themify.me" style="large yellow rounded flat"]More Info[/themify_button]</p>
<h2 style="text-align: center;">Services</h2><h3 style="text-align: center;">Get in touch now</h3>
<img src="http://themify.me/demo/themes/builder-layouts/files/2014/06/icon-video.png" width="60" height="60" title="Video" alt="Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero." /> <h3> Video </h3> Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero.
<img src="http://themify.me/demo/themes/builder-layouts/files/2014/06/icon-slider.png" width="60" height="60" title="Slideshow" alt="Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero." /> <h3> Slideshow </h3> Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero.
<img src="http://themify.me/demo/themes/builder-layouts/files/2014/06/icon-image.png" width="60" height="60" title="Gallery" alt="Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero." /> <h3> Gallery </h3> Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero.
<img src="http://themify.me/demo/themes/builder-layouts/files/2014/06/icon-map.png" width="60" height="60" title="Location" alt="Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero." /> <h3> Location </h3> Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero.
<img src="http://themify.me/demo/themes/builder-layouts/files/2014/06/icon-portfolio.png" width="60" height="60" title="Portfolio" alt="Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero." /> <h3> Portfolio </h3> Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero.
<img src="http://themify.me/demo/themes/builder-layouts/files/2014/06/icon-callout.png" width="60" height="60" title="Callout" alt="Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero." /> <h3> Callout </h3> Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero.
<p style="text-align: center;">[themify_button link="http://themify.me" style="large blue rounded flat"]More Info[/themify_button] [themify_button link="http://themify.me" style="large blue rounded flat"]Buy Now[/themify_button]</p><!--/themify_builder_static-->',
  'post_title' => 'Photo Page',
  'post_excerpt' => '',
  'post_name' => 'photo-page',
  'post_modified' => '2020-02-10 22:53:02',
  'post_modified_gmt' => '2020-02-10 22:53:02',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'http://themify.me/demo/themes/builder-layouts/tbuilder-layout/product-landing-2-copy/',
  'menu_order' => 0,
  'post_type' => 'tbuilder_layout',
  'meta_input' => 
  array (
    '_themify_builder_settings_json' => '[{\\"cols\\":[{\\"grid_class\\":\\"col-full first\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"mod_settings\\":{\\"content_text\\":\\"<h1 style=\\\\\\"text-align: center;\\\\\\">Photo Page<\\\\/h1><h4 style=\\\\\\"text-align: center;\\\\\\">Vivamus imperdiet diam ac tortor tempus posuere. Curabitur at arcu id turpis posuere bibendum.<\\\\/h4>\\",\\"font_family\\":\\"default\\",\\"padding_bottom\\":\\"30\\"},\\"element_id\\":\\"ajgs377\\"},{\\"mod_name\\":\\"gallery\\",\\"mod_settings\\":{\\"shortcode_gallery\\":\\"[gallery columns=\\\\\\"5\\\\\\" link=\\\\\\"file\\\\\\" ids=\\\\\\"69,70,71,72,73,74,75,76,77,78\\\\\\"]\\",\\"appearance_gallery\\":\\"|\\"},\\"element_id\\":\\"d5up953\\"}],\\"element_id\\":\\"2gw0034\\"}],\\"styling\\":{\\"row_width\\":\\"\\",\\"animation_effect\\":\\"fade-in\\",\\"background_image\\":\\"http:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/builder-layouts\\\\/files\\\\/2014\\\\/06\\\\/t1.jpg\\",\\"background_repeat\\":\\"builder-parallax-scrolling\\",\\"background_video\\":\\"\\",\\"background_color\\":\\"ffffff\\",\\"font_family\\":\\"default\\",\\"font_color\\":\\"ffffff\\",\\"font_size\\":\\"\\",\\"font_size_unit\\":\\"\\",\\"line_height\\":\\"\\",\\"line_height_unit\\":\\"\\",\\"link_color\\":\\"ffffff\\",\\"text_decoration\\":\\"\\",\\"padding_top\\":\\"\\",\\"padding_right\\":\\"\\",\\"padding_bottom\\":\\"0\\",\\"padding_left\\":\\"\\",\\"margin_top\\":\\"\\",\\"margin_right\\":\\"\\",\\"margin_bottom\\":\\"\\",\\"margin_left\\":\\"\\",\\"border_top_color\\":\\"\\",\\"border_top_width\\":\\"\\",\\"border_top_style\\":\\"\\",\\"border_right_color\\":\\"\\",\\"border_right_width\\":\\"\\",\\"border_right_style\\":\\"\\",\\"border_bottom_color\\":\\"\\",\\"border_bottom_width\\":\\"\\",\\"border_bottom_style\\":\\"\\",\\"border_left_color\\":\\"\\",\\"border_left_width\\":\\"\\",\\"border_left_style\\":\\"\\",\\"custom_css_row\\":\\"\\"},\\"element_id\\":\\"eus3008\\"},{\\"cols\\":[{\\"grid_class\\":\\"col4-2 first\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"mod_settings\\":{\\"style_image\\":\\"image-top\\",\\"url_image\\":\\"http:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/builder-layouts\\\\/files\\\\/2014\\\\/06\\\\/130178327.jpg\\",\\"appearance_image\\":\\"rounded\\",\\"width_image\\":\\"600\\",\\"height_image\\":\\"600\\",\\"title_image\\":\\"Image Caption\\",\\"param_image\\":\\"|\\",\\"caption_image\\":\\"Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero. Nam risus velit, rhoncus eget consectetur id, posuere at ligula. Vivamus imperdiet diam ac tortor tempus posuere. Curabitur at arcu id turpis posuere bibendum. Sed commodo mauris eget diam pretium cursus. \\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"3sur335\\"}],\\"element_id\\":\\"0vz8720\\"},{\\"grid_class\\":\\"col4-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"mod_settings\\":{\\"style_image\\":\\"image-top\\",\\"url_image\\":\\"http:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/builder-layouts\\\\/files\\\\/2014\\\\/06\\\\/125312654.jpg\\",\\"appearance_image\\":\\"rounded\\",\\"width_image\\":\\"300\\",\\"height_image\\":\\"300\\",\\"param_image\\":\\"|\\",\\"caption_image\\":\\"Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus.\\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"m51i770\\"},{\\"mod_name\\":\\"image\\",\\"mod_settings\\":{\\"style_image\\":\\"image-top\\",\\"url_image\\":\\"http:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/builder-layouts\\\\/files\\\\/2014\\\\/06\\\\/123528979.jpg\\",\\"appearance_image\\":\\"rounded\\",\\"width_image\\":\\"300\\",\\"height_image\\":\\"220\\",\\"param_image\\":\\"|\\",\\"caption_image\\":\\"Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero.\\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"0f3j703\\"}],\\"element_id\\":\\"hy2y370\\"},{\\"grid_class\\":\\"col4-1 last\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"mod_settings\\":{\\"style_image\\":\\"image-top\\",\\"url_image\\":\\"http:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/builder-layouts\\\\/files\\\\/2014\\\\/06\\\\/134399270.jpg\\",\\"appearance_image\\":\\"rounded\\",\\"width_image\\":\\"300\\",\\"height_image\\":\\"240\\",\\"param_image\\":\\"|\\",\\"caption_image\\":\\"Sed sagittis, elit egestas rutrum vehicula.\\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"52az013\\"},{\\"mod_name\\":\\"image\\",\\"mod_settings\\":{\\"style_image\\":\\"image-top\\",\\"url_image\\":\\"http:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/builder-layouts\\\\/files\\\\/2014\\\\/06\\\\/123612559.jpg\\",\\"appearance_image\\":\\"rounded\\",\\"width_image\\":\\"300\\",\\"height_image\\":\\"240\\",\\"param_image\\":\\"|\\",\\"caption_image\\":\\"Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero.\\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"udz0007\\"}],\\"element_id\\":\\"wfup131\\"}],\\"styling\\":{\\"row_width\\":\\"\\",\\"animation_effect\\":\\"fade-in\\",\\"background_image\\":\\"\\",\\"background_repeat\\":\\"\\",\\"background_video\\":\\"\\",\\"background_color\\":\\"000000\\",\\"font_family\\":\\"default\\",\\"font_color\\":\\"a8a8a8\\",\\"font_size\\":\\"\\",\\"font_size_unit\\":\\"\\",\\"line_height\\":\\"\\",\\"line_height_unit\\":\\"\\",\\"link_color\\":\\"ffffff\\",\\"text_decoration\\":\\"\\",\\"padding_top\\":\\"60\\",\\"padding_right\\":\\"\\",\\"padding_bottom\\":\\"60\\",\\"padding_left\\":\\"\\",\\"margin_top\\":\\"\\",\\"margin_right\\":\\"\\",\\"margin_bottom\\":\\"\\",\\"margin_left\\":\\"\\",\\"border_top_color\\":\\"\\",\\"border_top_width\\":\\"\\",\\"border_top_style\\":\\"\\",\\"border_right_color\\":\\"\\",\\"border_right_width\\":\\"\\",\\"border_right_style\\":\\"\\",\\"border_bottom_color\\":\\"\\",\\"border_bottom_width\\":\\"\\",\\"border_bottom_style\\":\\"\\",\\"border_left_color\\":\\"\\",\\"border_left_width\\":\\"\\",\\"border_left_style\\":\\"\\",\\"custom_css_row\\":\\"\\"},\\"element_id\\":\\"wjxc750\\"},{\\"cols\\":[{\\"grid_class\\":\\"col-full first\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2 style=\\\\\\"text-align: center;\\\\\\"><span style=\\\\\\"color: #ffe72e;\\\\\\">Hire Me<\\\\/span><\\\\/h2>\\\\n<h3 style=\\\\\\"text-align: center;\\\\\\"><span style=\\\\\\"color: #ffe72e;\\\\\\">I\\\'m available for hire<\\\\/span><\\\\/h3>\\\\n<p style=\\\\\\"text-align: center;\\\\\\">[themify_button link=\\\\\\"http:\\\\/\\\\/themify.me\\\\\\" style=\\\\\\"large yellow rounded flat\\\\\\"]More Info[\\\\/themify_button]<\\\\/p>\\\\n\\",\\"font_family\\":\\"default\\",\\"font_size\\":\\"1.2\\",\\"font_size_unit\\":\\"em\\"},\\"element_id\\":\\"decr307\\"}],\\"element_id\\":\\"3i22355\\"}],\\"styling\\":{\\"row_width\\":\\"\\",\\"animation_effect\\":\\"\\",\\"background_image\\":\\"http:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/builder-layouts\\\\/files\\\\/2014\\\\/06\\\\/122935597.jpg\\",\\"background_repeat\\":\\"fullcover\\",\\"background_video\\":\\"\\",\\"background_color\\":\\"000000\\",\\"font_family\\":\\"default\\",\\"font_color\\":\\"ffffff\\",\\"font_size\\":\\"\\",\\"font_size_unit\\":\\"\\",\\"line_height\\":\\"\\",\\"line_height_unit\\":\\"\\",\\"link_color\\":\\"ffffff\\",\\"text_decoration\\":\\"\\",\\"padding_top\\":\\"80\\",\\"padding_right\\":\\"\\",\\"padding_bottom\\":\\"80\\",\\"padding_left\\":\\"\\",\\"margin_top\\":\\"\\",\\"margin_right\\":\\"\\",\\"margin_bottom\\":\\"\\",\\"margin_left\\":\\"\\",\\"border_top_color\\":\\"\\",\\"border_top_width\\":\\"\\",\\"border_top_style\\":\\"\\",\\"border_right_color\\":\\"\\",\\"border_right_width\\":\\"\\",\\"border_right_style\\":\\"\\",\\"border_bottom_color\\":\\"\\",\\"border_bottom_width\\":\\"\\",\\"border_bottom_style\\":\\"\\",\\"border_left_color\\":\\"\\",\\"border_left_width\\":\\"\\",\\"border_left_style\\":\\"\\",\\"custom_css_row\\":\\"\\"},\\"element_id\\":\\"2n8s707\\"},{\\"cols\\":[{\\"grid_class\\":\\"col-full first last\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2 style=\\\\\\"text-align: center;\\\\\\">Services<\\\\/h2><h3 style=\\\\\\"text-align: center;\\\\\\">Get in touch now<\\\\/h3>\\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"4plu434\\"}],\\"element_id\\":\\"od88250\\"}],\\"styling\\":{\\"row_width\\":\\"\\",\\"animation_effect\\":\\"\\",\\"background_image\\":\\"\\",\\"background_repeat\\":\\"\\",\\"background_video\\":\\"\\",\\"background_color\\":\\"\\",\\"font_family\\":\\"default\\",\\"font_color\\":\\"\\",\\"font_size\\":\\"\\",\\"font_size_unit\\":\\"\\",\\"line_height\\":\\"\\",\\"line_height_unit\\":\\"\\",\\"link_color\\":\\"\\",\\"text_decoration\\":\\"\\",\\"padding_top\\":\\"70\\",\\"padding_right\\":\\"\\",\\"padding_bottom\\":\\"\\",\\"padding_left\\":\\"\\",\\"margin_top\\":\\"\\",\\"margin_right\\":\\"\\",\\"margin_bottom\\":\\"\\",\\"margin_left\\":\\"\\",\\"border_top_color\\":\\"\\",\\"border_top_width\\":\\"\\",\\"border_top_style\\":\\"\\",\\"border_right_color\\":\\"\\",\\"border_right_width\\":\\"\\",\\"border_right_style\\":\\"\\",\\"border_bottom_color\\":\\"\\",\\"border_bottom_width\\":\\"\\",\\"border_bottom_style\\":\\"\\",\\"border_left_color\\":\\"\\",\\"border_left_width\\":\\"\\",\\"border_left_style\\":\\"\\",\\"custom_css_row\\":\\"\\"},\\"element_id\\":\\"fuyn701\\"},{\\"cols\\":[{\\"grid_class\\":\\"col3-1 first\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"mod_settings\\":{\\"style_image\\":\\"image-left\\",\\"url_image\\":\\"http:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/builder-layouts\\\\/files\\\\/2014\\\\/06\\\\/icon-video.png\\",\\"appearance_image\\":\\"|\\",\\"width_image\\":\\"60\\",\\"height_image\\":\\"60\\",\\"title_image\\":\\"Video\\",\\"param_image\\":\\"|\\",\\"caption_image\\":\\"Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero. \\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"pros700\\"}],\\"element_id\\":\\"fn4g763\\"},{\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"mod_settings\\":{\\"style_image\\":\\"image-left\\",\\"url_image\\":\\"http:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/builder-layouts\\\\/files\\\\/2014\\\\/06\\\\/icon-slider.png\\",\\"appearance_image\\":\\"|\\",\\"width_image\\":\\"60\\",\\"height_image\\":\\"60\\",\\"title_image\\":\\"Slideshow\\",\\"param_image\\":\\"|\\",\\"caption_image\\":\\"Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero. \\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"lx6r375\\"}],\\"element_id\\":\\"ovec503\\"},{\\"grid_class\\":\\"col3-1 last\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"mod_settings\\":{\\"style_image\\":\\"image-left\\",\\"url_image\\":\\"http:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/builder-layouts\\\\/files\\\\/2014\\\\/06\\\\/icon-image.png\\",\\"appearance_image\\":\\"|\\",\\"width_image\\":\\"60\\",\\"height_image\\":\\"60\\",\\"title_image\\":\\"Gallery\\",\\"param_image\\":\\"|\\",\\"caption_image\\":\\"Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero. \\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"mmiq377\\"}],\\"element_id\\":\\"lkaw353\\"}],\\"styling\\":{\\"row_width\\":\\"\\",\\"animation_effect\\":\\"slide-up\\",\\"background_image\\":\\"\\",\\"background_repeat\\":\\"\\",\\"background_video\\":\\"\\",\\"background_color\\":\\"\\",\\"font_family\\":\\"default\\",\\"font_color\\":\\"\\",\\"font_size\\":\\"\\",\\"font_size_unit\\":\\"\\",\\"line_height\\":\\"\\",\\"line_height_unit\\":\\"\\",\\"link_color\\":\\"\\",\\"text_decoration\\":\\"\\",\\"padding_top\\":\\"\\",\\"padding_right\\":\\"\\",\\"padding_bottom\\":\\"30\\",\\"padding_left\\":\\"\\",\\"margin_top\\":\\"\\",\\"margin_right\\":\\"\\",\\"margin_bottom\\":\\"\\",\\"margin_left\\":\\"\\",\\"border_top_color\\":\\"\\",\\"border_top_width\\":\\"\\",\\"border_top_style\\":\\"\\",\\"border_right_color\\":\\"\\",\\"border_right_width\\":\\"\\",\\"border_right_style\\":\\"\\",\\"border_bottom_color\\":\\"\\",\\"border_bottom_width\\":\\"\\",\\"border_bottom_style\\":\\"\\",\\"border_left_color\\":\\"\\",\\"border_left_width\\":\\"\\",\\"border_left_style\\":\\"\\",\\"custom_css_row\\":\\"\\"},\\"element_id\\":\\"wxd1057\\"},{\\"cols\\":[{\\"grid_class\\":\\"col3-1 first\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"mod_settings\\":{\\"style_image\\":\\"image-left\\",\\"url_image\\":\\"http:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/builder-layouts\\\\/files\\\\/2014\\\\/06\\\\/icon-map.png\\",\\"appearance_image\\":\\"|\\",\\"width_image\\":\\"60\\",\\"height_image\\":\\"60\\",\\"title_image\\":\\"Location\\",\\"param_image\\":\\"|\\",\\"caption_image\\":\\"Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero. \\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"gvxo576\\"}],\\"element_id\\":\\"6gv9355\\"},{\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"mod_settings\\":{\\"style_image\\":\\"image-left\\",\\"url_image\\":\\"http:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/builder-layouts\\\\/files\\\\/2014\\\\/06\\\\/icon-portfolio.png\\",\\"appearance_image\\":\\"|\\",\\"width_image\\":\\"60\\",\\"height_image\\":\\"60\\",\\"title_image\\":\\"Portfolio\\",\\"param_image\\":\\"|\\",\\"caption_image\\":\\"Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero. \\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"3pbn377\\"}],\\"element_id\\":\\"x1uk788\\"},{\\"grid_class\\":\\"col3-1 last\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"mod_settings\\":{\\"style_image\\":\\"image-left\\",\\"url_image\\":\\"http:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/builder-layouts\\\\/files\\\\/2014\\\\/06\\\\/icon-callout.png\\",\\"appearance_image\\":\\"|\\",\\"width_image\\":\\"60\\",\\"height_image\\":\\"60\\",\\"title_image\\":\\"Callout\\",\\"param_image\\":\\"|\\",\\"caption_image\\":\\"Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero. \\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"logo047\\"}],\\"element_id\\":\\"6fte700\\"}],\\"styling\\":{\\"row_width\\":\\"\\",\\"animation_effect\\":\\"slide-up\\",\\"background_image\\":\\"\\",\\"background_repeat\\":\\"\\",\\"background_video\\":\\"\\",\\"background_color\\":\\"ffffff\\",\\"font_family\\":\\"default\\",\\"font_color\\":\\"\\",\\"font_size\\":\\"\\",\\"font_size_unit\\":\\"\\",\\"line_height\\":\\"\\",\\"line_height_unit\\":\\"\\",\\"link_color\\":\\"\\",\\"text_decoration\\":\\"\\",\\"padding_top\\":\\"\\",\\"padding_right\\":\\"\\",\\"padding_bottom\\":\\"30\\",\\"padding_left\\":\\"\\",\\"margin_top\\":\\"\\",\\"margin_right\\":\\"\\",\\"margin_bottom\\":\\"\\",\\"margin_left\\":\\"\\",\\"border_top_color\\":\\"\\",\\"border_top_width\\":\\"\\",\\"border_top_style\\":\\"\\",\\"border_right_color\\":\\"\\",\\"border_right_width\\":\\"\\",\\"border_right_style\\":\\"\\",\\"border_bottom_color\\":\\"\\",\\"border_bottom_width\\":\\"\\",\\"border_bottom_style\\":\\"\\",\\"border_left_color\\":\\"\\",\\"border_left_width\\":\\"\\",\\"border_left_style\\":\\"\\",\\"custom_css_row\\":\\"\\"},\\"element_id\\":\\"bgri504\\"},{\\"cols\\":[{\\"grid_class\\":\\"col-full first last\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"mod_settings\\":{\\"content_text\\":\\"<p style=\\\\\\"text-align: center;\\\\\\">[themify_button link=\\\\\\"http:\\\\/\\\\/themify.me\\\\\\" style=\\\\\\"large blue rounded flat\\\\\\"]More Info[\\\\/themify_button] [themify_button link=\\\\\\"http:\\\\/\\\\/themify.me\\\\\\" style=\\\\\\"large blue rounded flat\\\\\\"]Buy Now[\\\\/themify_button]<\\\\/p>\\\\n\\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"vqqp337\\"}],\\"element_id\\":\\"ord2740\\"}],\\"element_id\\":\\"kcmy753\\"}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
  ),
  'thumb' => false,
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 313,
  'post_date' => '2014-06-20 22:33:10',
  'post_date_gmt' => '2014-06-20 22:33:10',
  'post_content' => '<!--themify_builder_static--><h1 style="text-align: center;">Welcome</h1><h4 style="text-align: center;">Vivamus imperdiet diam ac tortor tempus posuere. Curabitur at arcu id turpis posuere bibendum.</h4><p style="text-align: center;">[themify_button link="http://themify.me" style="large white outline rounded"]Demo[/themify_button] [themify_button link="http://themify.me" style="large white outline rounded"]Buy Now[/themify_button]</p>
<iframe title="Themify Builder Overview" width="1165" height="655" src="https://www.youtube.com/embed/A0JrDX8tpks?feature=oembed" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
<h1>Mobile Friendly</h1><h3>Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero. Nam risus velit, rhoncus eget consectetur id, posuere at ligula. Vivamus imperdiet diam ac tortor tempus posuere. Curabitur at arcu id turpis posuere bibendum. Sed commodo mauris eget diam pretium cursus.</h3>
<img src="http://themify.me/demo/themes/builder-layouts/files/2014/06/iphone-hand-white.png" width="500" alt="Product Landing 2" />
<img src="http://themify.me/demo/themes/builder-layouts/files/2014/06/apple-air.png" width="500" alt="Product Landing 2" />
<h1>Desktop</h1><h3>Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero. Nam risus velit, rhoncus eget consectetur id, posuere at ligula. Vivamus imperdiet diam ac tortor tempus posuere. Curabitur at arcu id turpis posuere bibendum. Sed commodo mauris eget diam pretium cursus.</h3>
<h2 style="text-align: center;">More Features</h2><h3 style="text-align: center;">Below are more mini wow features</h3>
<img src="http://themify.me/demo/themes/builder-layouts/files/2014/06/icon-map.png" width="60" height="60" title="Map" alt="Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero." /> <h3> Map </h3> Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero.
<img src="http://themify.me/demo/themes/builder-layouts/files/2014/06/icon-callout.png" width="60" height="60" title="Announcement" alt="Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero." /> <h3> Announcement </h3> Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero.
<img src="http://themify.me/demo/themes/builder-layouts/files/2014/06/icon-portfolio.png" width="60" height="60" title="Portfolio" alt="Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero." /> <h3> Portfolio </h3> Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero.
<img src="http://themify.me/demo/themes/builder-layouts/files/2014/06/icon-video.png" width="60" height="60" title="Video" alt="Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero." /> <h3> Video </h3> Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero.
<img src="http://themify.me/demo/themes/builder-layouts/files/2014/06/icon-slider.png" width="60" height="60" title="Slideshow" alt="Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero." /> <h3> Slideshow </h3> Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero.
<img src="http://themify.me/demo/themes/builder-layouts/files/2014/06/icon-image.png" width="60" height="60" title="Gallery" alt="Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero." /> <h3> Gallery </h3> Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero.
<h2 style="text-align: center;">Call of Action</h2><h3 style="text-align: center;">Buy this product now!</h3><p style="text-align: center;">[themify_button link="http://themify.me" style="xlarge blue outline rounded"]More Info[/themify_button] [themify_button link="http://themify.me" style="xlarge blue outline rounded"]Buy Now[/themify_button]</p><!--/themify_builder_static-->',
  'post_title' => 'Product Landing 2',
  'post_excerpt' => '',
  'post_name' => 'product-landing-2',
  'post_modified' => '2019-11-22 08:24:43',
  'post_modified_gmt' => '2019-11-22 08:24:43',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'http://themify.me/demo/themes/builder-layouts/tbuilder-layout/product-landing-copy/',
  'menu_order' => 0,
  'post_type' => 'tbuilder_layout',
  'meta_input' => 
  array (
    '_themify_builder_settings_json' => '[{\\"row_order\\":\\"0\\",\\"cols\\":[{\\"grid_class\\":\\"col-full first\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"mod_settings\\":{\\"content_text\\":\\"<h1 style=\\\\\\"text-align: center;\\\\\\">Welcome<\\\\/h1><h4 style=\\\\\\"text-align: center;\\\\\\">Vivamus imperdiet diam ac tortor tempus posuere. Curabitur at arcu id turpis posuere bibendum.<\\\\/h4><p style=\\\\\\"text-align: center;\\\\\\">[themify_button link=\\\\\\"http:\\\\/\\\\/themify.me\\\\\\" style=\\\\\\"large white outline rounded\\\\\\"]Demo[\\\\/themify_button] [themify_button link=\\\\\\"http:\\\\/\\\\/themify.me\\\\\\" style=\\\\\\"large white outline rounded\\\\\\"]Buy Now[\\\\/themify_button]<\\\\/p>\\",\\"font_family\\":\\"default\\",\\"padding_bottom\\":\\"30\\"},\\"element_id\\":\\"jlfp569\\"},{\\"mod_name\\":\\"video\\",\\"mod_settings\\":{\\"style_video\\":\\"video-top\\",\\"url_video\\":\\"https:\\\\/\\\\/www.youtube.com\\\\/watch?v=A0JrDX8tpks\\",\\"unit_video\\":\\"px\\",\\"font_family\\":\\"default\\",\\"padding_right\\":\\"50\\",\\"padding_left\\":\\"50\\"},\\"element_id\\":\\"pvk9306\\"}],\\"element_id\\":\\"tzg5005\\"}],\\"styling\\":{\\"row_width\\":\\"\\",\\"animation_effect\\":\\"fade-in\\",\\"background_image\\":\\"http:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/builder-layouts\\\\/files\\\\/2014\\\\/06\\\\/897938491.jpg\\",\\"background_repeat\\":\\"builder-parallax-scrolling\\",\\"background_video\\":\\"\\",\\"background_color\\":\\"ffffff\\",\\"font_family\\":\\"default\\",\\"font_color\\":\\"ffffff\\",\\"font_size\\":\\"\\",\\"font_size_unit\\":\\"\\",\\"line_height\\":\\"\\",\\"line_height_unit\\":\\"\\",\\"link_color\\":\\"ffffff\\",\\"text_decoration\\":\\"\\",\\"padding_top\\":\\"\\",\\"padding_right\\":\\"\\",\\"padding_bottom\\":\\"0\\",\\"padding_left\\":\\"\\",\\"margin_top\\":\\"\\",\\"margin_right\\":\\"\\",\\"margin_bottom\\":\\"\\",\\"margin_left\\":\\"\\",\\"border_top_color\\":\\"\\",\\"border_top_width\\":\\"\\",\\"border_top_style\\":\\"\\",\\"border_right_color\\":\\"\\",\\"border_right_width\\":\\"\\",\\"border_right_style\\":\\"\\",\\"border_bottom_color\\":\\"\\",\\"border_bottom_width\\":\\"\\",\\"border_bottom_style\\":\\"\\",\\"border_left_color\\":\\"\\",\\"border_left_width\\":\\"\\",\\"border_left_style\\":\\"\\",\\"custom_css_row\\":\\"\\"},\\"element_id\\":\\"qr9p430\\"},{\\"row_order\\":\\"1\\",\\"cols\\":[{\\"grid_class\\":\\"col4-2 first\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"mod_settings\\":{\\"content_text\\":\\"<h1>Mobile Friendly<\\\\/h1><h3>Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero. Nam risus velit, rhoncus eget consectetur id, posuere at ligula. Vivamus imperdiet diam ac tortor tempus posuere. Curabitur at arcu id turpis posuere bibendum. Sed commodo mauris eget diam pretium cursus.<\\\\/h3>\\",\\"font_family\\":\\"default\\",\\"padding_top\\":\\"80\\",\\"padding_bottom\\":\\"60\\"},\\"element_id\\":\\"vpfz006\\"}],\\"element_id\\":\\"d4fe033\\"},{\\"grid_class\\":\\"col4-2 last\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"mod_settings\\":{\\"style_image\\":\\"image-top\\",\\"url_image\\":\\"http:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/builder-layouts\\\\/files\\\\/2014\\\\/06\\\\/iphone-hand-white.png\\",\\"appearance_image\\":\\"|\\",\\"width_image\\":\\"500\\",\\"param_image\\":\\"|\\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"1ztl550\\"}],\\"element_id\\":\\"roti366\\"}],\\"styling\\":{\\"row_width\\":\\"\\",\\"animation_effect\\":\\"slide-up\\",\\"background_image\\":\\"\\",\\"background_repeat\\":\\"\\",\\"background_video\\":\\"\\",\\"background_color\\":\\"\\",\\"font_family\\":\\"default\\",\\"font_color\\":\\"\\",\\"font_size\\":\\"\\",\\"font_size_unit\\":\\"\\",\\"line_height\\":\\"\\",\\"line_height_unit\\":\\"\\",\\"link_color\\":\\"\\",\\"text_decoration\\":\\"\\",\\"padding_top\\":\\"70\\",\\"padding_right\\":\\"\\",\\"padding_bottom\\":\\"\\",\\"padding_left\\":\\"\\",\\"margin_top\\":\\"\\",\\"margin_right\\":\\"\\",\\"margin_bottom\\":\\"\\",\\"margin_left\\":\\"\\",\\"border_top_color\\":\\"\\",\\"border_top_width\\":\\"\\",\\"border_top_style\\":\\"\\",\\"border_right_color\\":\\"\\",\\"border_right_width\\":\\"\\",\\"border_right_style\\":\\"\\",\\"border_bottom_color\\":\\"ebebeb\\",\\"border_bottom_width\\":\\"1\\",\\"border_bottom_style\\":\\"solid\\",\\"border_left_color\\":\\"\\",\\"border_left_width\\":\\"\\",\\"border_left_style\\":\\"\\",\\"custom_css_row\\":\\"\\"},\\"element_id\\":\\"tlhl030\\"},{\\"row_order\\":\\"2\\",\\"cols\\":[{\\"grid_class\\":\\"col4-2 first\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"mod_settings\\":{\\"style_image\\":\\"image-top\\",\\"url_image\\":\\"http:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/builder-layouts\\\\/files\\\\/2014\\\\/06\\\\/apple-air.png\\",\\"appearance_image\\":\\"|\\",\\"width_image\\":\\"500\\",\\"param_image\\":\\"|\\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"88zn666\\"}],\\"element_id\\":\\"z30n630\\"},{\\"grid_class\\":\\"col4-2 last\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"mod_settings\\":{\\"content_text\\":\\"<h1>Desktop<\\\\/h1><h3>Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero. Nam risus velit, rhoncus eget consectetur id, posuere at ligula. Vivamus imperdiet diam ac tortor tempus posuere. Curabitur at arcu id turpis posuere bibendum. Sed commodo mauris eget diam pretium cursus.<\\\\/h3>\\",\\"font_family\\":\\"default\\",\\"padding_top\\":\\"80\\",\\"padding_bottom\\":\\"60\\"},\\"element_id\\":\\"189s596\\"}],\\"element_id\\":\\"8vro090\\"}],\\"styling\\":{\\"row_width\\":\\"\\",\\"animation_effect\\":\\"slide-up\\",\\"background_image\\":\\"\\",\\"background_repeat\\":\\"\\",\\"background_video\\":\\"\\",\\"background_color\\":\\"\\",\\"font_family\\":\\"default\\",\\"font_color\\":\\"\\",\\"font_size\\":\\"\\",\\"font_size_unit\\":\\"\\",\\"line_height\\":\\"\\",\\"line_height_unit\\":\\"\\",\\"link_color\\":\\"\\",\\"text_decoration\\":\\"\\",\\"padding_top\\":\\"70\\",\\"padding_right\\":\\"\\",\\"padding_bottom\\":\\"\\",\\"padding_left\\":\\"\\",\\"margin_top\\":\\"\\",\\"margin_right\\":\\"\\",\\"margin_bottom\\":\\"\\",\\"margin_left\\":\\"\\",\\"border_top_color\\":\\"\\",\\"border_top_width\\":\\"\\",\\"border_top_style\\":\\"\\",\\"border_right_color\\":\\"\\",\\"border_right_width\\":\\"\\",\\"border_right_style\\":\\"\\",\\"border_bottom_color\\":\\"ebebeb\\",\\"border_bottom_width\\":\\"1\\",\\"border_bottom_style\\":\\"solid\\",\\"border_left_color\\":\\"\\",\\"border_left_width\\":\\"\\",\\"border_left_style\\":\\"\\",\\"custom_css_row\\":\\"\\"},\\"element_id\\":\\"q1y8005\\"},{\\"row_order\\":\\"3\\",\\"cols\\":[{\\"grid_class\\":\\"col-full first\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2 style=\\\\\\"text-align: center;\\\\\\">More Features<\\\\/h2><h3 style=\\\\\\"text-align: center;\\\\\\">Below are more mini wow features<\\\\/h3>\\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"77gb557\\"}],\\"element_id\\":\\"qh5h045\\"}],\\"styling\\":{\\"animation_effect\\":\\"\\",\\"background_image\\":\\"\\",\\"background_repeat\\":\\"\\",\\"background_video\\":\\"\\",\\"background_color\\":\\"\\",\\"font_family\\":\\"default\\",\\"font_color\\":\\"\\",\\"font_size\\":\\"\\",\\"font_size_unit\\":\\"\\",\\"line_height\\":\\"\\",\\"line_height_unit\\":\\"\\",\\"link_color\\":\\"\\",\\"text_decoration\\":\\"\\",\\"padding_top\\":\\"\\",\\"padding_right\\":\\"\\",\\"padding_bottom\\":\\"\\",\\"padding_left\\":\\"\\",\\"margin_top\\":\\"\\",\\"margin_right\\":\\"\\",\\"margin_bottom\\":\\"\\",\\"margin_left\\":\\"\\",\\"border_top_color\\":\\"\\",\\"border_top_width\\":\\"\\",\\"border_top_style\\":\\"\\",\\"border_right_color\\":\\"\\",\\"border_right_width\\":\\"\\",\\"border_right_style\\":\\"\\",\\"border_bottom_color\\":\\"\\",\\"border_bottom_width\\":\\"\\",\\"border_bottom_style\\":\\"\\",\\"border_left_color\\":\\"\\",\\"border_left_width\\":\\"\\",\\"border_left_style\\":\\"\\",\\"custom_css_row\\":\\"\\"},\\"element_id\\":\\"rj3m036\\"},{\\"row_order\\":\\"4\\",\\"cols\\":[{\\"grid_class\\":\\"col3-1 first\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"mod_settings\\":{\\"style_image\\":\\"image-left\\",\\"url_image\\":\\"http:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/builder-layouts\\\\/files\\\\/2014\\\\/06\\\\/icon-map.png\\",\\"appearance_image\\":\\"|\\",\\"width_image\\":\\"60\\",\\"height_image\\":\\"60\\",\\"title_image\\":\\"Map\\",\\"param_image\\":\\"|\\",\\"caption_image\\":\\"Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero. \\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"00el090\\"}],\\"element_id\\":\\"7pin790\\"},{\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"mod_settings\\":{\\"style_image\\":\\"image-left\\",\\"url_image\\":\\"http:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/builder-layouts\\\\/files\\\\/2014\\\\/06\\\\/icon-callout.png\\",\\"appearance_image\\":\\"|\\",\\"width_image\\":\\"60\\",\\"height_image\\":\\"60\\",\\"title_image\\":\\"Announcement\\",\\"param_image\\":\\"|\\",\\"caption_image\\":\\"Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero. \\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"7v3s115\\"}],\\"element_id\\":\\"wzml036\\"},{\\"grid_class\\":\\"col3-1 last\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"mod_settings\\":{\\"style_image\\":\\"image-left\\",\\"url_image\\":\\"http:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/builder-layouts\\\\/files\\\\/2014\\\\/06\\\\/icon-portfolio.png\\",\\"appearance_image\\":\\"|\\",\\"width_image\\":\\"60\\",\\"height_image\\":\\"60\\",\\"title_image\\":\\"Portfolio\\",\\"param_image\\":\\"|\\",\\"caption_image\\":\\"Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero. \\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"k6sv598\\"}],\\"element_id\\":\\"hu3h909\\"}],\\"styling\\":{\\"row_width\\":\\"\\",\\"animation_effect\\":\\"fade-in\\",\\"background_image\\":\\"\\",\\"background_repeat\\":\\"\\",\\"background_video\\":\\"\\",\\"background_color\\":\\"\\",\\"font_family\\":\\"default\\",\\"font_color\\":\\"\\",\\"font_size\\":\\"\\",\\"font_size_unit\\":\\"\\",\\"line_height\\":\\"\\",\\"line_height_unit\\":\\"\\",\\"link_color\\":\\"\\",\\"text_decoration\\":\\"\\",\\"padding_top\\":\\"\\",\\"padding_right\\":\\"\\",\\"padding_bottom\\":\\"\\",\\"padding_left\\":\\"\\",\\"margin_top\\":\\"\\",\\"margin_right\\":\\"\\",\\"margin_bottom\\":\\"\\",\\"margin_left\\":\\"\\",\\"border_top_color\\":\\"\\",\\"border_top_width\\":\\"\\",\\"border_top_style\\":\\"\\",\\"border_right_color\\":\\"\\",\\"border_right_width\\":\\"\\",\\"border_right_style\\":\\"\\",\\"border_bottom_color\\":\\"\\",\\"border_bottom_width\\":\\"\\",\\"border_bottom_style\\":\\"\\",\\"border_left_color\\":\\"\\",\\"border_left_width\\":\\"\\",\\"border_left_style\\":\\"\\",\\"custom_css_row\\":\\"\\"},\\"element_id\\":\\"n0aw070\\"},{\\"row_order\\":\\"5\\",\\"cols\\":[{\\"grid_class\\":\\"col3-1 first\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"mod_settings\\":{\\"style_image\\":\\"image-left\\",\\"url_image\\":\\"http:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/builder-layouts\\\\/files\\\\/2014\\\\/06\\\\/icon-video.png\\",\\"appearance_image\\":\\"|\\",\\"width_image\\":\\"60\\",\\"height_image\\":\\"60\\",\\"title_image\\":\\"Video\\",\\"param_image\\":\\"|\\",\\"caption_image\\":\\"Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero. \\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"srv7009\\"}],\\"element_id\\":\\"fwov968\\"},{\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"mod_settings\\":{\\"style_image\\":\\"image-left\\",\\"url_image\\":\\"http:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/builder-layouts\\\\/files\\\\/2014\\\\/06\\\\/icon-slider.png\\",\\"appearance_image\\":\\"|\\",\\"width_image\\":\\"60\\",\\"height_image\\":\\"60\\",\\"title_image\\":\\"Slideshow\\",\\"param_image\\":\\"|\\",\\"caption_image\\":\\"Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero. \\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"w5e8933\\"}],\\"element_id\\":\\"xm37990\\"},{\\"grid_class\\":\\"col3-1 last\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"mod_settings\\":{\\"style_image\\":\\"image-left\\",\\"url_image\\":\\"http:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/builder-layouts\\\\/files\\\\/2014\\\\/06\\\\/icon-image.png\\",\\"appearance_image\\":\\"|\\",\\"width_image\\":\\"60\\",\\"height_image\\":\\"60\\",\\"title_image\\":\\"Gallery\\",\\"param_image\\":\\"|\\",\\"caption_image\\":\\"Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero. \\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"qk2a599\\"}],\\"element_id\\":\\"bpso156\\"}],\\"styling\\":{\\"row_width\\":\\"\\",\\"animation_effect\\":\\"fade-in\\",\\"background_image\\":\\"\\",\\"background_repeat\\":\\"\\",\\"background_video\\":\\"\\",\\"background_color\\":\\"ffffff\\",\\"font_family\\":\\"default\\",\\"font_color\\":\\"000000\\",\\"font_size\\":\\"\\",\\"font_size_unit\\":\\"\\",\\"line_height\\":\\"\\",\\"line_height_unit\\":\\"\\",\\"link_color\\":\\"000000\\",\\"text_decoration\\":\\"\\",\\"padding_top\\":\\"\\",\\"padding_right\\":\\"\\",\\"padding_bottom\\":\\"50\\",\\"padding_left\\":\\"\\",\\"margin_top\\":\\"\\",\\"margin_right\\":\\"\\",\\"margin_bottom\\":\\"\\",\\"margin_left\\":\\"\\",\\"border_top_color\\":\\"\\",\\"border_top_width\\":\\"\\",\\"border_top_style\\":\\"\\",\\"border_right_color\\":\\"\\",\\"border_right_width\\":\\"\\",\\"border_right_style\\":\\"\\",\\"border_bottom_color\\":\\"\\",\\"border_bottom_width\\":\\"\\",\\"border_bottom_style\\":\\"\\",\\"border_left_color\\":\\"\\",\\"border_left_width\\":\\"\\",\\"border_left_style\\":\\"\\",\\"custom_css_row\\":\\"\\"},\\"element_id\\":\\"lgaa356\\"},{\\"row_order\\":\\"6\\",\\"cols\\":[{\\"grid_class\\":\\"col-full first last\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2 style=\\\\\\"text-align: center;\\\\\\">Call of Action<\\\\/h2><h3 style=\\\\\\"text-align: center;\\\\\\">Buy this product now!<\\\\/h3><p style=\\\\\\"text-align: center;\\\\\\">[themify_button link=\\\\\\"http:\\\\/\\\\/themify.me\\\\\\" style=\\\\\\"xlarge blue outline rounded\\\\\\"]More Info[\\\\/themify_button] [themify_button link=\\\\\\"http:\\\\/\\\\/themify.me\\\\\\" style=\\\\\\"xlarge blue outline rounded\\\\\\"]Buy Now[\\\\/themify_button]<\\\\/p>\\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"uak7000\\"}],\\"element_id\\":\\"apvj303\\"}],\\"styling\\":{\\"row_width\\":\\"\\",\\"animation_effect\\":\\"\\",\\"background_image\\":\\"\\",\\"background_repeat\\":\\"\\",\\"background_video\\":\\"\\",\\"background_color\\":\\"f7f7f7\\",\\"font_family\\":\\"default\\",\\"font_color\\":\\"000000\\",\\"font_size\\":\\"\\",\\"font_size_unit\\":\\"\\",\\"line_height\\":\\"\\",\\"line_height_unit\\":\\"\\",\\"link_color\\":\\"000000\\",\\"text_decoration\\":\\"\\",\\"padding_top\\":\\"40\\",\\"padding_right\\":\\"\\",\\"padding_bottom\\":\\"40\\",\\"padding_left\\":\\"\\",\\"margin_top\\":\\"\\",\\"margin_right\\":\\"\\",\\"margin_bottom\\":\\"\\",\\"margin_left\\":\\"\\",\\"border_top_color\\":\\"\\",\\"border_top_width\\":\\"\\",\\"border_top_style\\":\\"\\",\\"border_right_color\\":\\"\\",\\"border_right_width\\":\\"\\",\\"border_right_style\\":\\"\\",\\"border_bottom_color\\":\\"\\",\\"border_bottom_width\\":\\"\\",\\"border_bottom_style\\":\\"\\",\\"border_left_color\\":\\"\\",\\"border_left_width\\":\\"\\",\\"border_left_style\\":\\"\\",\\"custom_css_row\\":\\"\\"},\\"element_id\\":\\"g767990\\"}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
  ),
  'thumb' => false,
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 312,
  'post_date' => '2014-06-17 23:11:13',
  'post_date_gmt' => '2014-06-17 23:11:13',
  'post_content' => '<!--themify_builder_static--><h1>Welcome</h1><h4>Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero. Nam risus velit, rhoncus eget consectetur id, posuere at ligula. Vivamus imperdiet diam ac tortor tempus posuere. Curabitur at arcu id turpis posuere bibendum. Sed commodo mauris eget diam pretium cursus.</h4><p>[themify_button link="http://themify.me" style="large white outline rounded"]More Info[/themify_button]</p>
<img src="http://themify.me/demo/themes/builder-layouts/files/2014/06/ipad-image.png" width="480" alt="Product Landing" />
<h2 style="text-align: center;">Featured</h2><h3 style="text-align: center;">Our products have featured on...</h3>
<ul data-id="tb_bi1o000" data-visible="5" data-mob-visible="" data-scroll="1" data-auto-scroll="4" data-speed="1" data-wrap="yes" data-arrow="no" data-pagination="no" data-effect="continuously" data-height="variable" data-pause-on-hover="resume" data-horizontal="" > 
 <li> <img src="http://themify.me/demo/themes/builder-layouts/files/2014/06/logo1.png" width="140" alt="Product Landing" /> </li> <li> <img src="http://themify.me/demo/themes/builder-layouts/files/2014/06/logo2.png" width="140" alt="Product Landing" /> </li> <li> <img src="http://themify.me/demo/themes/builder-layouts/files/2014/06/logo3.png" width="140" alt="Product Landing" /> </li> <li> <img src="http://themify.me/demo/themes/builder-layouts/files/2014/06/logo4.png" width="140" alt="Product Landing" /> </li> <li> <img src="http://themify.me/demo/themes/builder-layouts/files/2014/06/logo5.png" width="140" alt="Product Landing" /> </li> <li> <img src="http://themify.me/demo/themes/builder-layouts/files/2014/06/logo6.png" width="140" alt="Product Landing" /> </li> </ul>
<img src="http://themify.me/demo/themes/builder-layouts/files/2014/06/icon-map.png" width="60" height="60" title="Map" alt="Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero." /> <h3> Map </h3> Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero.
<img src="http://themify.me/demo/themes/builder-layouts/files/2014/06/icon-video.png" width="60" height="60" title="Video" alt="Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero." /> <h3> Video </h3> Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero.
<img src="http://themify.me/demo/themes/builder-layouts/files/2014/06/icon-callout.png" width="60" height="60" title="Announcement" alt="Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero." /> <h3> Announcement </h3> Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero.
<img src="http://themify.me/demo/themes/builder-layouts/files/2014/06/icon-slider.png" width="60" height="60" title="Slideshow" alt="Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero." /> <h3> Slideshow </h3> Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero.
<img src="http://themify.me/demo/themes/builder-layouts/files/2014/06/icon-portfolio.png" width="60" height="60" title="Portfolio" alt="Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero." /> <h3> Portfolio </h3> Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero.
<img src="http://themify.me/demo/themes/builder-layouts/files/2014/06/icon-image.png" width="60" height="60" title="Gallery" alt="Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero." /> <h3> Gallery </h3> Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero.
<h2 style="text-align: center;">Call of Action</h2><h3 style="text-align: center;">Buy this product now!</h3><p style="text-align: center;">[themify_button link="http://themify.me" style="large white outline rounded"]More Info[/themify_button] [themify_button link="http://themify.me" style="large white outline rounded"]Buy Now[/themify_button]</p>
<h2 style="text-align: center;">FAQs</h2>
<h3>What is your pricing structure?</h3><p>Fusce augue velit, vulputate elementum semper congue, rhoncus adipiscing nisl. Curabitur vel risus eros, sed eleifend arcu. Donec porttitor hendrerit diam et blandit.</p>
<h3>Do you do custom design?</h3><p>Curabitur vel risus eros, sed eleifend arcu. Donec porttitor hendrerit diam et blandit. Curabitur vitae velit ligula, vitae lobortis massa. Fusce augue velit, vulputate elementum semper congue, rhoncus adipiscing nisl. </p>
<h3>Are your products refundable?</h3><p>Fusce augue velit, vulputate elementum semper congue, rhoncus adipiscing nisl. Curabitur vel risus eros, sed eleifend arcu. Donec porttitor hendrerit diam et blandit. Curabitur vitae velit ligula, vitae lobortis massa.</p>
<h3>Where can I see your work?</h3><p>Fusce augue velit, vulputate elementum semper congue, rhoncus adipind arcu. Donec porttitor hendrerit diam et blandit. Curabitur vitae velit ligula, vitae lobortis massa.</p>
<h3>What is the delivery charge?</h3><p>Cunec porttitor hendrerit diam et blandit. Curabitur vitae velit ligula, vitae lobortis massa. Fusce augue velit, vulputate elementum semper congue, rhoncus adipiscing nisl. </p>
<h3>May I drop by your showrooms?</h3><p>Tulputate elementum semper congue, rhoncus adipiscing nisl. Curabitur vel risus eros, sed eleifend arcu. Donec porttitor hendrerit diam et blandit. Curabitur vitae velit ligula, vitae lobortis massa.</p><!--/themify_builder_static-->',
  'post_title' => 'Product Landing',
  'post_excerpt' => '',
  'post_name' => 'product-landing',
  'post_modified' => '2019-11-23 11:01:26',
  'post_modified_gmt' => '2019-11-23 11:01:26',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'http://themify.me/demo/themes/builder-layouts/?post_type=tbuilder_layout&amp;p=6',
  'menu_order' => 0,
  'post_type' => 'tbuilder_layout',
  'meta_input' => 
  array (
    '_themify_builder_settings_json' => '[{\\"row_order\\":\\"0\\",\\"cols\\":[{\\"grid_class\\":\\"col4-2 first\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"mod_settings\\":{\\"content_text\\":\\"<h1>Welcome<\\\\/h1><h4>Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero. Nam risus velit, rhoncus eget consectetur id, posuere at ligula. Vivamus imperdiet diam ac tortor tempus posuere. Curabitur at arcu id turpis posuere bibendum. Sed commodo mauris eget diam pretium cursus.<\\\\/h4><p>[themify_button link=\\\\\\"http:\\\\/\\\\/themify.me\\\\\\" style=\\\\\\"large white outline rounded\\\\\\"]More Info[\\\\/themify_button]<\\\\/p>\\",\\"font_family\\":\\"default\\",\\"padding_top\\":\\"80\\",\\"padding_bottom\\":\\"50\\"},\\"element_id\\":\\"s01q302\\"}],\\"element_id\\":\\"5nab029\\"},{\\"grid_class\\":\\"col4-2 last\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"mod_settings\\":{\\"style_image\\":\\"image-top\\",\\"url_image\\":\\"http:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/builder-layouts\\\\/files\\\\/2014\\\\/06\\\\/ipad-image.png\\",\\"appearance_image\\":\\"rounded\\",\\"width_image\\":\\"480\\",\\"param_image\\":\\"|\\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"rkuv020\\"}],\\"element_id\\":\\"16pi300\\"}],\\"styling\\":{\\"row_width\\":\\"\\",\\"animation_effect\\":\\"fly-in\\",\\"background_image\\":\\"http:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/builder-layouts\\\\/files\\\\/2014\\\\/06\\\\/bg-1.jpg\\",\\"background_color\\":\\"6f94a3\\",\\"background_repeat\\":\\"builder-parallax-scrolling\\",\\"font_family\\":\\"default\\",\\"font_color\\":\\"ffffff\\",\\"font_size\\":\\"\\",\\"font_size_unit\\":\\"\\",\\"line_height\\":\\"\\",\\"line_height_unit\\":\\"\\",\\"link_color\\":\\"\\",\\"text_decoration\\":\\"\\",\\"padding_top\\":\\"80\\",\\"padding_right\\":\\"\\",\\"padding_bottom\\":\\"80\\",\\"padding_left\\":\\"\\",\\"margin_top\\":\\"\\",\\"margin_right\\":\\"\\",\\"margin_bottom\\":\\"\\",\\"margin_left\\":\\"\\",\\"border_top_color\\":\\"\\",\\"border_top_width\\":\\"\\",\\"border_top_style\\":\\"\\",\\"border_right_color\\":\\"\\",\\"border_right_width\\":\\"\\",\\"border_right_style\\":\\"\\",\\"border_bottom_color\\":\\"\\",\\"border_bottom_width\\":\\"\\",\\"border_bottom_style\\":\\"\\",\\"border_left_color\\":\\"\\",\\"border_left_width\\":\\"\\",\\"border_left_style\\":\\"\\",\\"custom_css_row\\":\\"\\"},\\"element_id\\":\\"u9xc088\\"},{\\"row_order\\":\\"1\\",\\"cols\\":[{\\"grid_class\\":\\"col-full first\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2 style=\\\\\\"text-align: center;\\\\\\">Featured<\\\\/h2><h3 style=\\\\\\"text-align: center;\\\\\\">Our products have featured on...<\\\\/h3>\\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"te0r303\\"},{\\"mod_name\\":\\"slider\\",\\"mod_settings\\":{\\"layout_display_slider\\":\\"image\\",\\"blog_category_slider\\":\\"|single\\",\\"slider_category_slider\\":\\"|single\\",\\"portfolio_category_slider\\":\\"|single\\",\\"testimonial_category_slider\\":\\"|single\\",\\"display_slider\\":\\"content\\",\\"img_content_slider\\":[{\\"img_url_slider\\":\\"http:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/builder-layouts\\\\/files\\\\/2014\\\\/06\\\\/logo1.png\\"},{\\"img_url_slider\\":\\"http:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/builder-layouts\\\\/files\\\\/2014\\\\/06\\\\/logo2.png\\"},{\\"img_url_slider\\":\\"http:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/builder-layouts\\\\/files\\\\/2014\\\\/06\\\\/logo3.png\\"},{\\"img_url_slider\\":\\"http:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/builder-layouts\\\\/files\\\\/2014\\\\/06\\\\/logo4.png\\"},{\\"img_url_slider\\":\\"http:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/builder-layouts\\\\/files\\\\/2014\\\\/06\\\\/logo5.png\\"},{\\"img_url_slider\\":\\"http:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/builder-layouts\\\\/files\\\\/2014\\\\/06\\\\/logo6.png\\"}],\\"layout_slider\\":\\"slider-default\\",\\"img_w_slider\\":\\"140\\",\\"visible_opt_slider\\":\\"5\\",\\"auto_scroll_opt_slider\\":\\"4\\",\\"scroll_opt_slider\\":\\"1\\",\\"speed_opt_slider\\":\\"normal\\",\\"effect_slider\\":\\"continuously\\",\\"pause_on_hover_slider\\":\\"resume\\",\\"wrap_slider\\":\\"yes\\",\\"show_nav_slider\\":\\"no\\",\\"show_arrow_slider\\":\\"no\\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"bi1o000\\"}],\\"element_id\\":\\"567l043\\"}],\\"styling\\":{\\"row_width\\":\\"\\",\\"animation_effect\\":\\"\\",\\"background_image\\":\\"\\",\\"background_color\\":\\"ffffff\\",\\"background_repeat\\":\\"\\",\\"font_family\\":\\"default\\",\\"font_color\\":\\"000000\\",\\"font_size\\":\\"\\",\\"font_size_unit\\":\\"\\",\\"line_height\\":\\"\\",\\"line_height_unit\\":\\"\\",\\"link_color\\":\\"\\",\\"text_decoration\\":\\"\\",\\"padding_top\\":\\"80\\",\\"padding_right\\":\\"\\",\\"padding_bottom\\":\\"80\\",\\"padding_left\\":\\"\\",\\"margin_top\\":\\"\\",\\"margin_right\\":\\"\\",\\"margin_bottom\\":\\"\\",\\"margin_left\\":\\"\\",\\"border_top_color\\":\\"\\",\\"border_top_width\\":\\"\\",\\"border_top_style\\":\\"\\",\\"border_right_color\\":\\"\\",\\"border_right_width\\":\\"\\",\\"border_right_style\\":\\"\\",\\"border_bottom_color\\":\\"\\",\\"border_bottom_width\\":\\"\\",\\"border_bottom_style\\":\\"\\",\\"border_left_color\\":\\"\\",\\"border_left_width\\":\\"\\",\\"border_left_style\\":\\"\\",\\"custom_css_row\\":\\"\\"},\\"element_id\\":\\"u3lz033\\"},{\\"row_order\\":\\"2\\",\\"cols\\":[{\\"grid_class\\":\\"col3-1 first\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"mod_settings\\":{\\"style_image\\":\\"image-left\\",\\"url_image\\":\\"http:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/builder-layouts\\\\/files\\\\/2014\\\\/06\\\\/icon-map.png\\",\\"appearance_image\\":\\"|\\",\\"width_image\\":\\"60\\",\\"height_image\\":\\"60\\",\\"title_image\\":\\"Map\\",\\"param_image\\":\\"|\\",\\"caption_image\\":\\"Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero. \\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"70ej993\\"},{\\"mod_name\\":\\"image\\",\\"mod_settings\\":{\\"style_image\\":\\"image-left\\",\\"url_image\\":\\"http:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/builder-layouts\\\\/files\\\\/2014\\\\/06\\\\/icon-video.png\\",\\"appearance_image\\":\\"|\\",\\"width_image\\":\\"60\\",\\"height_image\\":\\"60\\",\\"title_image\\":\\"Video\\",\\"param_image\\":\\"|\\",\\"caption_image\\":\\"Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero. \\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"8ejo033\\"}],\\"element_id\\":\\"to0e303\\"},{\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"mod_settings\\":{\\"style_image\\":\\"image-left\\",\\"url_image\\":\\"http:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/builder-layouts\\\\/files\\\\/2014\\\\/06\\\\/icon-callout.png\\",\\"appearance_image\\":\\"|\\",\\"width_image\\":\\"60\\",\\"height_image\\":\\"60\\",\\"title_image\\":\\"Announcement\\",\\"param_image\\":\\"|\\",\\"caption_image\\":\\"Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero. \\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"2tuc013\\"},{\\"mod_name\\":\\"image\\",\\"mod_settings\\":{\\"style_image\\":\\"image-left\\",\\"url_image\\":\\"http:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/builder-layouts\\\\/files\\\\/2014\\\\/06\\\\/icon-slider.png\\",\\"appearance_image\\":\\"|\\",\\"width_image\\":\\"60\\",\\"height_image\\":\\"60\\",\\"title_image\\":\\"Slideshow\\",\\"param_image\\":\\"|\\",\\"caption_image\\":\\"Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero. \\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"xtbq330\\"}],\\"element_id\\":\\"qapl009\\"},{\\"grid_class\\":\\"col3-1 last\\",\\"modules\\":[{\\"mod_name\\":\\"image\\",\\"mod_settings\\":{\\"style_image\\":\\"image-left\\",\\"url_image\\":\\"http:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/builder-layouts\\\\/files\\\\/2014\\\\/06\\\\/icon-portfolio.png\\",\\"appearance_image\\":\\"|\\",\\"width_image\\":\\"60\\",\\"height_image\\":\\"60\\",\\"title_image\\":\\"Portfolio\\",\\"param_image\\":\\"|\\",\\"caption_image\\":\\"Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero. \\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"wr1a399\\"},{\\"mod_name\\":\\"image\\",\\"mod_settings\\":{\\"style_image\\":\\"image-left\\",\\"url_image\\":\\"http:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/builder-layouts\\\\/files\\\\/2014\\\\/06\\\\/icon-image.png\\",\\"appearance_image\\":\\"|\\",\\"width_image\\":\\"60\\",\\"height_image\\":\\"60\\",\\"title_image\\":\\"Gallery\\",\\"param_image\\":\\"|\\",\\"caption_image\\":\\"Sed sagittis, elit egestas rutrum vehicula, neque dolor fringilla lacus, ut rhoncus turpis augue vitae libero. \\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"zf3d033\\"}],\\"element_id\\":\\"rgr0393\\"}],\\"styling\\":{\\"row_width\\":\\"\\",\\"animation_effect\\":\\"slide-up\\",\\"background_image\\":\\"http:\\\\/\\\\/themify.me\\\\/demo\\\\/themes\\\\/builder-layouts\\\\/files\\\\/2014\\\\/06\\\\/71222191.jpg\\",\\"background_repeat\\":\\"builder-parallax-scrolling\\",\\"background_video\\":\\"\\",\\"background_color\\":\\"99c8cf\\",\\"font_family\\":\\"default\\",\\"font_color\\":\\"000000\\",\\"font_size\\":\\"\\",\\"font_size_unit\\":\\"\\",\\"line_height\\":\\"\\",\\"line_height_unit\\":\\"\\",\\"link_color\\":\\"000000\\",\\"text_decoration\\":\\"\\",\\"padding_top\\":\\"80\\",\\"padding_right\\":\\"\\",\\"padding_bottom\\":\\"80\\",\\"padding_left\\":\\"\\",\\"margin_top\\":\\"\\",\\"margin_right\\":\\"\\",\\"margin_bottom\\":\\"\\",\\"margin_left\\":\\"\\",\\"border_top_color\\":\\"\\",\\"border_top_width\\":\\"\\",\\"border_top_style\\":\\"\\",\\"border_right_color\\":\\"\\",\\"border_right_width\\":\\"\\",\\"border_right_style\\":\\"\\",\\"border_bottom_color\\":\\"\\",\\"border_bottom_width\\":\\"\\",\\"border_bottom_style\\":\\"\\",\\"border_left_color\\":\\"\\",\\"border_left_width\\":\\"\\",\\"border_left_style\\":\\"\\",\\"custom_css_row\\":\\"\\"},\\"element_id\\":\\"8ull000\\"},{\\"row_order\\":\\"3\\",\\"cols\\":[{\\"grid_class\\":\\"col-full first\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2 style=\\\\\\"text-align: center;\\\\\\">Call of Action<\\\\/h2><h3 style=\\\\\\"text-align: center;\\\\\\">Buy this product now!<\\\\/h3><p style=\\\\\\"text-align: center;\\\\\\">[themify_button link=\\\\\\"http:\\\\/\\\\/themify.me\\\\\\" style=\\\\\\"large white outline rounded\\\\\\"]More Info[\\\\/themify_button] [themify_button link=\\\\\\"http:\\\\/\\\\/themify.me\\\\\\" style=\\\\\\"large white outline rounded\\\\\\"]Buy Now[\\\\/themify_button]<\\\\/p>\\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"c7ik333\\"}],\\"element_id\\":\\"xqg6020\\"}],\\"styling\\":{\\"row_width\\":\\"\\",\\"animation_effect\\":\\"\\",\\"background_image\\":\\"\\",\\"background_color\\":\\"6fc7d9\\",\\"background_repeat\\":\\"\\",\\"font_family\\":\\"default\\",\\"font_color\\":\\"ffffff\\",\\"font_size\\":\\"\\",\\"font_size_unit\\":\\"\\",\\"line_height\\":\\"\\",\\"line_height_unit\\":\\"\\",\\"link_color\\":\\"fff3cc\\",\\"text_decoration\\":\\"\\",\\"padding_top\\":\\"80\\",\\"padding_right\\":\\"\\",\\"padding_bottom\\":\\"80\\",\\"padding_left\\":\\"\\",\\"margin_top\\":\\"\\",\\"margin_right\\":\\"\\",\\"margin_bottom\\":\\"\\",\\"margin_left\\":\\"\\",\\"border_top_color\\":\\"\\",\\"border_top_width\\":\\"\\",\\"border_top_style\\":\\"\\",\\"border_right_color\\":\\"\\",\\"border_right_width\\":\\"\\",\\"border_right_style\\":\\"\\",\\"border_bottom_color\\":\\"\\",\\"border_bottom_width\\":\\"\\",\\"border_bottom_style\\":\\"\\",\\"border_left_color\\":\\"\\",\\"border_left_width\\":\\"\\",\\"border_left_style\\":\\"\\",\\"custom_css_row\\":\\"\\"},\\"element_id\\":\\"u5ov339\\"},{\\"row_order\\":\\"4\\",\\"cols\\":[{\\"grid_class\\":\\"col-full first last\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"mod_settings\\":{\\"content_text\\":\\"<h2 style=\\\\\\"text-align: center;\\\\\\">FAQs<\\\\/h2>\\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"pxfh023\\"}],\\"element_id\\":\\"nit4006\\"}],\\"styling\\":{\\"row_width\\":\\"\\",\\"animation_effect\\":\\"\\",\\"background_image\\":\\"\\",\\"background_repeat\\":\\"\\",\\"background_video\\":\\"\\",\\"background_color\\":\\"\\",\\"font_family\\":\\"default\\",\\"font_color\\":\\"\\",\\"font_size\\":\\"\\",\\"font_size_unit\\":\\"\\",\\"line_height\\":\\"\\",\\"line_height_unit\\":\\"\\",\\"link_color\\":\\"\\",\\"text_decoration\\":\\"\\",\\"padding_top\\":\\"\\",\\"padding_right\\":\\"\\",\\"padding_bottom\\":\\"\\",\\"padding_left\\":\\"\\",\\"margin_top\\":\\"60\\",\\"margin_right\\":\\"\\",\\"margin_bottom\\":\\"40\\",\\"margin_left\\":\\"\\",\\"border_top_color\\":\\"\\",\\"border_top_width\\":\\"\\",\\"border_top_style\\":\\"\\",\\"border_right_color\\":\\"\\",\\"border_right_width\\":\\"\\",\\"border_right_style\\":\\"\\",\\"border_bottom_color\\":\\"\\",\\"border_bottom_width\\":\\"\\",\\"border_bottom_style\\":\\"\\",\\"border_left_color\\":\\"\\",\\"border_left_width\\":\\"\\",\\"border_left_style\\":\\"\\",\\"custom_css_row\\":\\"\\"},\\"element_id\\":\\"kdqw343\\"},{\\"row_order\\":\\"5\\",\\"cols\\":[{\\"grid_class\\":\\"col3-1 first\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>What is your pricing structure?<\\\\/h3><p>Fusce augue velit, vulputate elementum semper congue, rhoncus adipiscing nisl. Curabitur vel risus eros, sed eleifend arcu. Donec porttitor hendrerit diam et blandit.<\\\\/p>\\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"j3qb031\\"}],\\"element_id\\":\\"yrnf392\\"},{\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>Do you do custom design?<\\\\/h3><p>Curabitur vel risus eros, sed eleifend arcu. Donec porttitor hendrerit diam et blandit. Curabitur vitae velit ligula, vitae lobortis massa. Fusce augue velit, vulputate elementum semper congue, rhoncus adipiscing nisl. <\\\\/p>\\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"8qv7333\\"}],\\"element_id\\":\\"xtoy333\\"},{\\"grid_class\\":\\"col3-1 last\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>Are your products refundable?<\\\\/h3><p>Fusce augue velit, vulputate elementum semper congue, rhoncus adipiscing nisl. Curabitur vel risus eros, sed eleifend arcu. Donec porttitor hendrerit diam et blandit. Curabitur vitae velit ligula, vitae lobortis massa.<\\\\/p>\\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"r5qy333\\"}],\\"element_id\\":\\"cesd443\\"}],\\"styling\\":{\\"row_width\\":\\"\\",\\"animation_effect\\":\\"slide-up\\",\\"background_image\\":\\"\\",\\"background_repeat\\":\\"\\",\\"background_video\\":\\"\\",\\"background_color\\":\\"\\",\\"font_family\\":\\"default\\",\\"font_color\\":\\"\\",\\"font_size\\":\\"\\",\\"font_size_unit\\":\\"\\",\\"line_height\\":\\"\\",\\"line_height_unit\\":\\"\\",\\"link_color\\":\\"\\",\\"text_decoration\\":\\"\\",\\"padding_top\\":\\"\\",\\"padding_right\\":\\"\\",\\"padding_bottom\\":\\"\\",\\"padding_left\\":\\"\\",\\"margin_top\\":\\"\\",\\"margin_right\\":\\"\\",\\"margin_bottom\\":\\"30\\",\\"margin_left\\":\\"\\",\\"border_top_color\\":\\"\\",\\"border_top_width\\":\\"\\",\\"border_top_style\\":\\"\\",\\"border_right_color\\":\\"\\",\\"border_right_width\\":\\"\\",\\"border_right_style\\":\\"\\",\\"border_bottom_color\\":\\"\\",\\"border_bottom_width\\":\\"\\",\\"border_bottom_style\\":\\"\\",\\"border_left_color\\":\\"\\",\\"border_left_width\\":\\"\\",\\"border_left_style\\":\\"\\",\\"custom_css_row\\":\\"\\"},\\"element_id\\":\\"osn2393\\"},{\\"row_order\\":\\"6\\",\\"cols\\":[{\\"grid_class\\":\\"col3-1 first\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>Where can I see your work?<\\\\/h3><p>Fusce augue velit, vulputate elementum semper congue, rhoncus adipind arcu. Donec porttitor hendrerit diam et blandit. Curabitur vitae velit ligula, vitae lobortis massa.<\\\\/p>\\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"3mwb933\\"}],\\"element_id\\":\\"vi61333\\"},{\\"grid_class\\":\\"col3-1\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>What is the delivery charge?<\\\\/h3><p>Cunec porttitor hendrerit diam et blandit. Curabitur vitae velit ligula, vitae lobortis massa. Fusce augue velit, vulputate elementum semper congue, rhoncus adipiscing nisl. <\\\\/p>\\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"6dmh300\\"}],\\"element_id\\":\\"zkho339\\"},{\\"grid_class\\":\\"col3-1 last\\",\\"modules\\":[{\\"mod_name\\":\\"text\\",\\"mod_settings\\":{\\"content_text\\":\\"<h3>May I drop by your showrooms?<\\\\/h3><p>Tulputate elementum semper congue, rhoncus adipiscing nisl. Curabitur vel risus eros, sed eleifend arcu. Donec porttitor hendrerit diam et blandit. Curabitur vitae velit ligula, vitae lobortis massa.<\\\\/p>\\",\\"font_family\\":\\"default\\"},\\"element_id\\":\\"g56z304\\"}],\\"element_id\\":\\"ruim433\\"}],\\"element_id\\":\\"padp963\\"}]',
    'themify_used_global_styles' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
  ),
  'thumb' => false,
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 147,
  'post_date' => '2016-02-20 02:56:16',
  'post_date_gmt' => '2016-02-20 02:56:16',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '147',
  'post_modified' => '2016-02-23 19:03:03',
  'post_modified_gmt' => '2016-02-23 19:03:03',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/simple/?p=147',
  'menu_order' => 1,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '90',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-menu',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 156,
  'post_date' => '2016-02-23 19:03:03',
  'post_date_gmt' => '2016-02-23 19:03:03',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '156',
  'post_modified' => '2016-02-23 19:03:03',
  'post_modified_gmt' => '2016-02-23 19:03:03',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/simple/?p=156',
  'menu_order' => 2,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '154',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-menu',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$post = array (
  'ID' => 146,
  'post_date' => '2016-02-20 02:56:16',
  'post_date_gmt' => '2016-02-20 02:56:16',
  'post_content' => ' ',
  'post_title' => '',
  'post_excerpt' => '',
  'post_name' => '146',
  'post_modified' => '2016-02-23 19:03:03',
  'post_modified_gmt' => '2016-02-23 19:03:03',
  'post_content_filtered' => '',
  'post_parent' => 0,
  'guid' => 'https://themify.me/demo/themes/simple/?p=146',
  'menu_order' => 3,
  'post_type' => 'nav_menu_item',
  'xfn' => '',
  'meta_input' => 
  array (
    '_menu_item_type' => 'post_type',
    '_menu_item_menu_item_parent' => '0',
    '_menu_item_object_id' => '144',
    '_menu_item_object' => 'page',
    '_menu_item_classes' => 
    array (
      0 => '',
    ),
  ),
  'tax_input' => 
  array (
    'nav_menu' => 'main-menu',
  ),
);
Themify_Import_Helper::process_post_import( $post );


$widgets = get_option( "widget_search" );
$widgets[1002] = array (
  'title' => '',
);
update_option( "widget_search", $widgets );

$widgets = get_option( "widget_recent-posts" );
$widgets[1003] = array (
  'title' => '',
  'number' => 5,
);
update_option( "widget_recent-posts", $widgets );

$widgets = get_option( "widget_recent-comments" );
$widgets[1004] = array (
  'title' => '',
  'number' => 5,
);
update_option( "widget_recent-comments", $widgets );

$widgets = get_option( "widget_archives" );
$widgets[1005] = array (
  'title' => '',
  'count' => 0,
  'dropdown' => 0,
);
update_option( "widget_archives", $widgets );

$widgets = get_option( "widget_categories" );
$widgets[1006] = array (
  'title' => '',
  'count' => 0,
  'hierarchical' => 0,
  'dropdown' => 0,
);
update_option( "widget_categories", $widgets );

$widgets = get_option( "widget_meta" );
$widgets[1007] = array (
  'title' => '',
);
update_option( "widget_meta", $widgets );

$widgets = get_option( "widget_themify-social-links" );
$widgets[1008] = array (
  'title' => '',
  'show_link_name' => NULL,
  'open_new_window' => NULL,
  'icon_size' => 'icon-medium',
  'orientation' => 'horizontal',
);
update_option( "widget_themify-social-links", $widgets );

$widgets = get_option( "widget_themify-social-links" );
$widgets[1009] = array (
  'title' => '',
  'show_link_name' => NULL,
  'open_new_window' => NULL,
  'icon_size' => 'icon-large',
  'orientation' => 'horizontal',
);
update_option( "widget_themify-social-links", $widgets );



$sidebars_widgets = array (
  'sidebar-main' => 
  array (
    0 => 'search-1002',
    1 => 'recent-posts-1003',
    2 => 'recent-comments-1004',
    3 => 'archives-1005',
    4 => 'categories-1006',
    5 => 'meta-1007',
  ),
  'social-widget' => 
  array (
    0 => 'themify-social-links-1008',
  ),
  'footer-social-widget' => 
  array (
    0 => 'themify-social-links-1009',
  ),
); 
update_option( "sidebars_widgets", $sidebars_widgets );

$homepage = get_posts( array( 'name' => 'home', 'post_type' => 'page' ) );
			if( is_array( $homepage ) && ! empty( $homepage ) ) {
				update_option( 'show_on_front', 'page' );
				update_option( 'page_on_front', $homepage[0]->ID );
			}
			$themify_data = array (
  'setting-webfonts_list' => 'recommended',
  'setting-default_layout' => 'sidebar-none',
  'setting-default_post_layout' => 'list-post',
  'setting-default_layout_display' => 'content',
  'setting-default_more_text' => 'More',
  'setting-index_orderby' => 'date',
  'setting-index_order' => 'DESC',
  'setting-default_media_position' => 'above',
  'setting-image_post_feature_size' => 'blank',
  'setting-default_page_post_layout' => 'sidebar-none',
  'setting-image_post_single_feature_size' => 'blank',
  'setting-default_page_layout' => 'sidebar-none',
  'setting-customizer_responsive_design_tablet_landscape' => '1280',
  'setting-customizer_responsive_design_tablet' => '768',
  'setting-customizer_responsive_design_mobile' => '680',
  'setting-mobile_menu_trigger_point' => '1200',
  'setting-gallery_lightbox' => 'lightbox',
  'setting-entries_nav' => 'numbered',
  'setting-footer_widgets' => 'footerwidget-3col',
  'setting-img_php_base_size' => 'large',
  'setting-global_feature_size' => 'blank',
  'setting-link_icon_type' => 'font-icon',
  'setting-link_type_themify-link-0' => 'image-icon',
  'setting-link_title_themify-link-0' => 'Twitter',
  'setting-link_img_themify-link-0' => 'https://themify.me/demo/themes/simple/wp-content/themes/themify-simple/themify/img/social/twitter.png',
  'setting-link_type_themify-link-1' => 'image-icon',
  'setting-link_title_themify-link-1' => 'Facebook',
  'setting-link_img_themify-link-1' => 'https://themify.me/demo/themes/simple/wp-content/themes/themify-simple/themify/img/social/facebook.png',
  'setting-link_type_themify-link-2' => 'image-icon',
  'setting-link_title_themify-link-2' => 'Google+',
  'setting-link_img_themify-link-2' => 'https://themify.me/demo/themes/simple/wp-content/themes/themify-simple/themify/img/social/google-plus.png',
  'setting-link_type_themify-link-3' => 'image-icon',
  'setting-link_title_themify-link-3' => 'YouTube',
  'setting-link_img_themify-link-3' => 'https://themify.me/demo/themes/simple/wp-content/themes/themify-simple/themify/img/social/youtube.png',
  'setting-link_type_themify-link-4' => 'image-icon',
  'setting-link_title_themify-link-4' => 'Pinterest',
  'setting-link_img_themify-link-4' => 'https://themify.me/demo/themes/simple/wp-content/themes/themify-simple/themify/img/social/pinterest.png',
  'setting-link_type_themify-link-6' => 'font-icon',
  'setting-link_title_themify-link-6' => 'Facebook',
  'setting-link_link_themify-link-6' => 'https://www.facebook.com/themify',
  'setting-link_ficon_themify-link-6' => 'fa-facebook',
  'setting-link_type_themify-link-5' => 'font-icon',
  'setting-link_title_themify-link-5' => 'Twitter',
  'setting-link_link_themify-link-5' => 'https://twitter.com/themify',
  'setting-link_ficon_themify-link-5' => 'fa-twitter',
  'setting-link_type_themify-link-7' => 'font-icon',
  'setting-link_title_themify-link-7' => 'Google+',
  'setting-link_ficon_themify-link-7' => 'fa-google-plus',
  'setting-link_type_themify-link-8' => 'font-icon',
  'setting-link_title_themify-link-8' => 'YouTube',
  'setting-link_link_themify-link-8' => 'https://www.youtube.com/user/themifyme/',
  'setting-link_ficon_themify-link-8' => 'fa-youtube',
  'setting-link_type_themify-link-9' => 'font-icon',
  'setting-link_title_themify-link-9' => 'Pinterest',
  'setting-link_ficon_themify-link-9' => 'fa-pinterest',
  'setting-link_field_ids' => '{"themify-link-0":"themify-link-0","themify-link-1":"themify-link-1","themify-link-2":"themify-link-2","themify-link-3":"themify-link-3","themify-link-4":"themify-link-4","themify-link-6":"themify-link-6","themify-link-5":"themify-link-5","themify-link-7":"themify-link-7","themify-link-8":"themify-link-8","themify-link-9":"themify-link-9"}',
  'setting-link_field_hash' => '10',
  'setting-page_builder_is_active' => 'enable',
  'setting-page_builder_animation_appearance' => 'none',
  'setting-page_builder_animation_parallax_bg' => 'none',
  'setting-page_builder_animation_scroll_effect' => 'none',
  'setting-page_builder_animation_sticky_scroll' => 'none',
  'setting-page_builder_cache' => 'on',
  'setting-page_builder_expiry' => '2',
  'import_images' => 'on',
);
themify_set_data( $themify_data );
$theme = get_option( 'stylesheet' );
$theme_mods = array (
  0 => false,
  'main_nav_link_hover_color' => '{"color":"ff0000","opacity":"1.00"}',
  'custom_css_post_id' => -1,
);
update_option( "theme_mods_{$theme}", $theme_mods );
$menu_locations = array();
$menu = get_terms( "nav_menu", array( "slug" => "main-menu" ) );
if( is_array( $menu ) && ! empty( $menu ) ) $menu_locations["main-nav"] = $menu[0]->term_id;
set_theme_mod( "nav_menu_locations", $menu_locations );



}
